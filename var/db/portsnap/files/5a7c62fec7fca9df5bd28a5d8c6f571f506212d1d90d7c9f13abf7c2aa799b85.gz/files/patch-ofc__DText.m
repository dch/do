--- ./ofc/DText.m.orig	2008-08-05 18:29:04.000000000 +0200
+++ ./ofc/DText.m	2014-08-29 08:27:25.604995394 +0200
@@ -29,6 +29,7 @@
 #include <string.h>
 #include <ctype.h>
 #include <stdlib.h>
+#include <stdarg.h>
 #include <errno.h>
 #include <stdio.h>
 
