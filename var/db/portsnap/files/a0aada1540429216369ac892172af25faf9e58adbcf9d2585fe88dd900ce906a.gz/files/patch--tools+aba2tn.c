--- ../tools/aba2tn.cc.orig	Sat Jul 12 16:05:32 2003
+++ ../tools/aba2tn.cc	Sat Jul 12 16:08:10 2003
@@ -1,5 +1,7 @@
-#include <fstream.h>
-#include <iostream.h>
+#include <fstream>
+#include <iostream>
+using std::cout;
+using std::cin;
 #include <string.h>
 #include <stdio.h>
 #include <stdlib.h>
