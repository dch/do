--- tochnog.h.orig	2013-10-12 05:33:16.000000000 +0200
+++ tochnog.h	2014-03-09 18:16:04.000000000 +0100
@@ -58,6 +58,8 @@
   MVERSION              // maximum number of versions, this must be the last item
 }; 
 
+#define TOCHNOG_VERSION "Latest-jan-2014"
+
   // constants
 #define MCHAR 100  // maximum length of names
 #define MDIM 3 // maximum number of space dimensions
