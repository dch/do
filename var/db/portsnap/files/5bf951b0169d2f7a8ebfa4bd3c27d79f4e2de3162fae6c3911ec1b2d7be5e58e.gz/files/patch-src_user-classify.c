--- src/user-classify.c.orig	2014-03-15 15:09:59.000000000 +0100
+++ src/user-classify.c	2014-03-15 15:11:06.000000000 +0100
@@ -44,6 +44,7 @@
         "nobody4",
         "noaccess",
         "postgres",
+        "pgsql",
         "pvm",
         "rpm",
         "nfsnobody",
@@ -53,6 +54,7 @@
         "games",
         "man",
         "at",
+        "saned",
         "gdm",
         "gnome-initial-setup"
 };
