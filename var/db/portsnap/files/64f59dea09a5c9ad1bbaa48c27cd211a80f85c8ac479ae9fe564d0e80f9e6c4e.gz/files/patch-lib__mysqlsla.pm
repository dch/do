--- ./lib/mysqlsla.pm.orig	2014-09-19 23:35:02.701375256 +0400
+++ ./lib/mysqlsla.pm	2014-09-19 23:35:46.694100925 +0400
@@ -6,6 +6,8 @@
 
 __END__
 
+=encoding utf8
+
 =head1 NAME
 
 mysqlsla - Parse, filter, analyze and sort MySQL slow, general and binary logs
