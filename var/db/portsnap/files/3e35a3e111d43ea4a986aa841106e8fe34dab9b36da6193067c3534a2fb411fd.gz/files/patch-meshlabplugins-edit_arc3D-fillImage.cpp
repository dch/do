--- meshlabplugins/edit_arc3D/fillImage.cpp.orig	2013-10-31 10:47:05.000000000 +0100
+++ meshlabplugins/edit_arc3D/fillImage.cpp	2013-10-31 10:52:27.000000000 +0100
@@ -22,6 +22,7 @@
 ****************************************************************************/
 
 #include "fillImage.h"
+#include <cstdlib>
 #include <cmath>
 #include <limits>
 
