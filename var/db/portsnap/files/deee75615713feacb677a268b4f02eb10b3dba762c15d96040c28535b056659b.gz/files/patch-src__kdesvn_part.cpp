--- src/kdesvn_part.cpp.old	2013-07-07 17:37:41.415664472 +0200
+++ src/kdesvn_part.cpp	2013-07-07 17:37:53.484512746 +0200
@@ -174,7 +174,6 @@
     about.addAuthor(ki18n("Rajko Albrecht"), ki18n("Original author and maintainer"), "ral@alwins-world.de" );
     about.setOtherText(m_Extratext);
     about.setHomepage("http://kdesvn.alwins-world.de/");
-    about.setBugAddress("kdesvn-bugs@alwins-world.de");
     about.setProgramIconName("kdesvn");
     about.setTranslator(ki18n("kdesvn: NAME OF TRANSLATORS\\nYour names"),
         ki18n("kdesvn: EMAIL OF TRANSLATORS\\nYour emails"));
