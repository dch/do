--- src/ghostess.c.orig	2006-11-28 06:39:41.000000000 +0100
+++ src/ghostess.c	2008-07-23 01:33:28.000000000 +0200
@@ -56,6 +56,7 @@
 #include <dirent.h>
 #include <pthread.h>
 #include <math.h>
+#include <errno.h>
 
 #include <gtk/gtk.h>
 
