--- src/libwsmake/wsLoader.h.orig	2008-06-03 21:00:24.000000000 +0200
+++ src/libwsmake/wsLoader.h	2008-06-03 21:00:19.000000000 +0200
@@ -26,6 +26,7 @@
 #include <list>
 #include <string>
 #include <stdio.h>
+using namespace std;
 
 namespace wsmake
 {
