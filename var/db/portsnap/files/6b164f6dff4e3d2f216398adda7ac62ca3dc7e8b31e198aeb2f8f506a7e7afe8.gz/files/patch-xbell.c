--- xbell.c.orig	2002-10-26 20:26:48.000000000 -0400
+++ xbell.c	2014-08-16 14:05:35.000000000 -0400
@@ -38,8 +38,7 @@
 #include    <sysexits.h>
 
 #ifndef lint
-static const char   rcsid[] =
-	"$Id: xbell.c,v 1.1 2002/10/27 00:26:48 sethk Exp $";
+__RCSID("$Id: xbell.c,v 1.1 2002/10/27 00:26:48 sethk Exp $");
 #endif /* !lint */
 
 int
