--- include/qpdf/QUtil.hh.orig	2013-10-22 10:53:22.013499403 +0400
+++ include/qpdf/QUtil.hh	2013-10-22 10:53:41.216497407 +0400
@@ -14,6 +14,7 @@
 #include <list>
 #include <stdexcept>
 #include <stdio.h>
+#include <ctime>
 
 namespace QUtil
 {
