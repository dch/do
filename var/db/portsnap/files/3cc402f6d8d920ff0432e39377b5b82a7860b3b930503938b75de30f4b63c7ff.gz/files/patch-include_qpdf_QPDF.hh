--- include/qpdf/QPDF.hh.orig	2013-10-22 10:30:42.941592225 +0400
+++ include/qpdf/QPDF.hh	2013-10-22 10:30:54.303595364 +0400
@@ -16,6 +16,7 @@
 #include <map>
 #include <list>
 #include <iostream>
+#include <ctime>
 
 #include <qpdf/QPDFObjGen.hh>
 #include <qpdf/QPDFXRefEntry.hh>
