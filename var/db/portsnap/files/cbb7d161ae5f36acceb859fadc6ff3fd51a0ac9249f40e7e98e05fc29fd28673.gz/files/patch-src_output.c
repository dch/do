--- src/output.c.orig	Tue Jul 19 12:24:27 2005
+++ src/output.c	Tue Jul 19 12:24:35 2005
@@ -11,7 +11,6 @@
 #ifdef HAVE_STDLIB_H

 #endif
-#include <malloc.h>
 #include <math.h>
 #include <string.h>
 #include <sys/types.h>
