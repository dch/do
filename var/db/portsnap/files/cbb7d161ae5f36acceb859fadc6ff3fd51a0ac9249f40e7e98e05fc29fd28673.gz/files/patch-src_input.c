--- src/input.c.orig	Tue Jul 19 12:24:11 2005
+++ src/input.c	Tue Jul 19 12:24:18 2005
@@ -16,7 +16,6 @@
 */

 #include <stdio.h>
-#include <malloc.h>
 #include <math.h>
 #include "nrutil.h"
 #include "yagi.h"
