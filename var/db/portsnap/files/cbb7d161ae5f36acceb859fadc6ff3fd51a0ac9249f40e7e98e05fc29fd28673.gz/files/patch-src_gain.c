--- src/gain.c.orig	Tue Jul 19 12:24:45 2005
+++ src/gain.c	Tue Jul 19 12:24:50 2005
@@ -3,7 +3,6 @@
 #endif
 #include <stdio.h>
 #include <math.h>
-#include <malloc.h>
 #include <errno.h>
 #include "yagi.h"
 #define TINY 1e-10
