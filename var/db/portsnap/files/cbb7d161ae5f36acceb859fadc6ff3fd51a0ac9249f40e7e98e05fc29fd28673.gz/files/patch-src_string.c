--- src/string.c.orig	Tue Jul 19 12:23:46 2005
+++ src/string.c	Tue Jul 19 12:23:56 2005
@@ -2,7 +2,6 @@
 #include <stdlib.h>
 #endif
 #include <stdio.h>
-#include <malloc.h>
 #include "yagi.h"


