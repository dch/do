--- src/random.c.orig	Tue Jul 19 12:36:04 2005
+++ src/random.c	Tue Jul 19 12:36:13 2005
@@ -42,7 +42,6 @@
 #endif


-#include <values.h>
 #include "yagi.h"

 double randreal(void)
