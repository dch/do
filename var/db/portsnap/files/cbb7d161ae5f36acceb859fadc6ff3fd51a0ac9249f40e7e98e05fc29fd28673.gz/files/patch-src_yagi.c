--- src/yagi.c.orig	Tue Jul 19 12:23:10 2005
+++ src/yagi.c	Tue Jul 19 12:23:33 2005
@@ -19,7 +19,7 @@


 #include <stdio.h>
-#include <malloc.h>
+#include <stdlib.h>
 #include <math.h>
 #include <errno.h>
 #include "yagi.h"
