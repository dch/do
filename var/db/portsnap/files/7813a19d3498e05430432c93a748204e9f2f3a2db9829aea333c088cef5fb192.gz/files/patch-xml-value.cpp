--- ./xml-value.cpp.orig	2014-08-01 13:41:29.000000000 -0400
+++ ./xml-value.cpp	2014-08-01 13:41:47.000000000 -0400
@@ -26,6 +26,7 @@
 #include <ctype.h>
 #include <errno.h>
 #include <string.h>
+#include <stdlib.h>
 #include <algorithm>
 #include <functional>
 
