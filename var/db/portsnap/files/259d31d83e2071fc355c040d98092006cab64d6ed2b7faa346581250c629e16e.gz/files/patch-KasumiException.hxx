--- KasumiException.hxx.orig	Fri Jan  7 23:18:09 2005
+++ KasumiException.hxx	Sun May 22 19:58:45 2005
@@ -5,6 +5,8 @@
 #include "config.h"
 #endif
 
+#include <string>
+
 using namespace std;
 
 class KasumiDicExaminationException{
