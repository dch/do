--- batt.h.orig	Wed May 14 04:58:17 1997
+++ batt.h	Fri Feb  2 04:18:06 2001
@@ -2,7 +2,7 @@
  * batt.h     Part of the SEABATTLE game by Vince Weaver                 *
  ************************************************************************/
 
-#include <curses.h>     /* Slang support is good for rxvt in linux */
+#include <ncurses.h>     /* Slang support is good for rxvt in linux */
 #include <stdio.h>
 #include <ctype.h>
 #include <stdlib.h>
