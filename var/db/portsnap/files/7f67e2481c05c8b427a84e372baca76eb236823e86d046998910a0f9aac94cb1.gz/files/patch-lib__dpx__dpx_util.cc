--- ./lib/dpx/dpx_util.cc.orig	2013-10-12 18:55:34.000000000 +0200
+++ ./lib/dpx/dpx_util.cc	2013-10-12 18:55:55.000000000 +0200
@@ -57,6 +57,7 @@
 #include <stdio.h>
 
 #include <string.h>
+#include <stdlib.h>
 
 namespace ctl {
 
