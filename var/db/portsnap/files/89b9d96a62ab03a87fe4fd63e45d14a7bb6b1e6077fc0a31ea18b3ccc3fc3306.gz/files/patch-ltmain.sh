--- ltmain.sh.orig	Sun Jan 20 16:11:07 2002
+++ ltmain.sh	Tue Jan 22 13:34:20 2002
@@ -1060,6 +1060,7 @@
 
       -module)
 	module=yes
+	build_old_libs=no
 	continue
 	;;
 
