--- mymath.c.orig	1997-12-30 19:30:25.000000000 +0900
+++ mymath.c	2012-10-17 01:08:29.000000000 +0900
@@ -1,3 +1,4 @@
+#include <string.h>
 #include <math.h>
 
 #include "configure.h"
