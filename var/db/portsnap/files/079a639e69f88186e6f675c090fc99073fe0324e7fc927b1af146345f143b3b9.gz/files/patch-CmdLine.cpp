--- CmdLine.cpp.orig	2015-03-27 03:02:22.542305000 +0300
+++ CmdLine.cpp	2015-03-27 03:02:46.761263000 +0300
@@ -32,6 +32,7 @@
 // if you're using MFC, you'll need to un-comment this line
 // #include "stdafx.h"
 
+#include <string.h>
 #include "CmdLine.h"
 
 /*------------------------------------------------------
