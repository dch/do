--- ogdf/internal/cluster/basics.h.orig	2014-10-01 10:12:06.000000000 +0200
+++ ogdf/internal/cluster/basics.h	2014-10-01 10:12:37.000000000 +0200
@@ -47,6 +47,7 @@
 #define OGDF_CPLANAR_BASICS_H
 
 #include <abacus/master.h>
+#include <abacus/constraint.h>
 #include <ogdf/basic/Graph_d.h>
 #include <ogdf/cluster/ClusterGraph.h>
 #include <ogdf/cluster/ClusterGraphAttributes.h>
