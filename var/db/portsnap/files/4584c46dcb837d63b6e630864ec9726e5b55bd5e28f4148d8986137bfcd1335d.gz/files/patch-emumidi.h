--- emumidi.h.orig	Sun May 11 23:26:36 1997
+++ emumidi.h	Mon Nov 17 22:05:20 2003
@@ -17,7 +17,6 @@
 #ifdef linux
 #include <linux/ultrasound.h>
 #else
-#include <machine/ultrasound.h>
 #endif
 
 /*
