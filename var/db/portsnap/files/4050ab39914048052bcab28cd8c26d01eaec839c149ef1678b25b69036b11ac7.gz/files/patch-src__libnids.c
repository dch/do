--- ./src/libnids.c.orig	2010-03-01 21:13:25.000000000 +0000
+++ ./src/libnids.c	2014-02-03 14:04:04.000000000 +0000
@@ -14,7 +14,6 @@
 #include <stdlib.h>
 #include <string.h>
 #include <syslog.h>
-#include <alloca.h>
 #include <pcap.h>
 #include <errno.h>
 #include <config.h>
