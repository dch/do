--- gck/gck.h.orig	2015-04-17 11:20:36.392953000 +0200
+++ gck/gck.h	2015-04-17 11:21:07.941440000 +0200
@@ -388,7 +388,6 @@
  */
 typedef struct _GckSlot GckSlot;
 typedef struct _GckModule GckModule;
-typedef struct _GckSession GckSession;
 typedef struct _GckObject GckObject;
 typedef struct _GckObjectCache GckObjectCache;
 typedef struct _GckEnumerator GckEnumerator;
