--- VTparse.h.orig	Wed Nov 13 23:56:22 2002
+++ VTparse.h	Wed Nov 13 01:07:07 2002
@@ -118,3 +118,4 @@
 #define CASE_SCS_STATE 77
 #define CASE_GSET_VERSION_STATE 78
 #define CASE_GSET_VERSION 79
+#define CASE_ECH 80
