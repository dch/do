--- src/lib/math/symmetry/pointgrp.cc.orig	Wed Feb 21 20:52:39 2001
+++ src/lib/math/symmetry/pointgrp.cc	Fri Apr 27 15:28:50 2001
@@ -54,6 +54,7 @@
 #include <string.h>
 #include <ctype.h>
 #include <math.h>
+#include <float.h>

 #include <util/misc/formio.h>
 #include <util/state/stateio.h>
