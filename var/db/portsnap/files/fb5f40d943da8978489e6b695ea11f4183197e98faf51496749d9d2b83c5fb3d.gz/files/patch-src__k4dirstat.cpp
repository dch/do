--- src/k4dirstat.cpp.orig
+++ src/k4dirstat.cpp
@@ -14,6 +14,7 @@
 //#include "k4dirstatview.h"
 #include "settings.h"
 
+#include <unistd.h>
 #include <QtGui/QDropEvent>
 #include <QtGui/QPainter>
 #include <QtGui/QPrinter>\
