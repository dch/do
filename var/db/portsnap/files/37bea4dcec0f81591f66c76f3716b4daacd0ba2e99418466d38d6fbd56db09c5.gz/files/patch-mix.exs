--- mix.exs.orig	2015-07-20 14:01:37 UTC
+++ mix.exs
@@ -6,7 +6,6 @@ defmodule OAuth2.Mixfile do
       app: :oauth2,
       version: "0.2.0",
       elixir: "~> 1.0",
-      deps: deps,
       package: package,
       name: "OAuth2",
       description: "An Elixir OAuth 2.0 Client Library",
