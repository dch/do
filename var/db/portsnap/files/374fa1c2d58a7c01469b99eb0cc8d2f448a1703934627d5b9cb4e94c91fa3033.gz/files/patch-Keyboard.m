--- Modules/Keyboard/Keyboard.m.orig	2002-06-08 10:29:36.000000000 +0200
+++ Modules/Keyboard/Keyboard.m	2010-05-22 11:24:43.000000000 +0200
@@ -37,6 +37,7 @@
 #import <AppKit/NSButton.h>
 #import <AppKit/NSNibLoading.h>
 #import <AppKit/NSOpenPanel.h>
+#import <Foundation/NSUserDefaults.h>
 
 #import "Keyboard.h"
 #import "KeyboardView.h"
