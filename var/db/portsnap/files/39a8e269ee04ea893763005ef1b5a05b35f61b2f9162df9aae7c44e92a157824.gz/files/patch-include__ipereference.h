--- include/ipereference.h.orig
+++ include/ipereference.h
@@ -33,6 +33,7 @@
 #define IPEREF_H
 
 #include "ipeobject.h"
+#include <sys/types.h>
 
 // --------------------------------------------------------------------
 
