--- ipecairo/ipestdfonts.cpp.orig
+++ ipecairo/ipestdfonts.cpp
@@ -30,6 +30,7 @@
 */
 
 #include "ipebase.h"
+#include <sys/types.h>
 
 using namespace ipe;
 
