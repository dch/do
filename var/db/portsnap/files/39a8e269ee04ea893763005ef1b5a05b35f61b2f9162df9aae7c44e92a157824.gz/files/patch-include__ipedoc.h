--- include/ipedoc.h.orig
+++ include/ipedoc.h
@@ -37,6 +37,7 @@
 #include "ipeimage.h"
 #include "ipestyle.h"
 #include "ipefontpool.h"
+#include <sys/types.h>
 
 // --------------------------------------------------------------------
 
