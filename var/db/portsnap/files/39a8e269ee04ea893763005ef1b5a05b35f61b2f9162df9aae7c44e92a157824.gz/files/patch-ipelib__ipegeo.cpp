--- ipelib/ipegeo.cpp.orig
+++ ipelib/ipegeo.cpp
@@ -38,6 +38,8 @@
 */
 
 #include "ipegeo.h"
+#include <cstdlib>
+#include <sys/types.h>
 
 using namespace ipe;
 
