--- ipelib/ipelatex.cpp.orig
+++ ipelib/ipelatex.cpp
@@ -35,6 +35,8 @@
 #include "ipefontpool.h"
 #include "ipelatex.h"
 
+#include <cstdlib>
+
 using namespace ipe;
 
 /*! \class ipe::Latex
