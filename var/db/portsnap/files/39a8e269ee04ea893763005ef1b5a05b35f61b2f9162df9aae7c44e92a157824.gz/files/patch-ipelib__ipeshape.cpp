--- ipelib/ipeshape.cpp.orig
+++ ipelib/ipeshape.cpp
@@ -30,6 +30,7 @@
 
 #include "ipeshape.h"
 #include "ipepainter.h"
+#include <sys/types.h>
 
 using namespace ipe;
 
