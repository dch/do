--- include/ipebase.h.orig	2013-09-13 12:51:35.422094300 +0400
+++ include/ipebase.h	2013-09-13 12:52:10.808993351 +0400
@@ -38,6 +38,8 @@
 #include <map>
 #include <list>
 #include <algorithm>
+#include <cstdlib>
+#include <sys/types.h>                                                                                                                                                                       
 
 // --------------------------------------------------------------------
 
