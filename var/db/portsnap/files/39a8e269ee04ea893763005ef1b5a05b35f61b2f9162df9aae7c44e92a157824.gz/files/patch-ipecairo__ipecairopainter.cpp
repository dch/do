--- ipecairo/ipecairopainter.cpp.orig
+++ ipecairo/ipecairopainter.cpp
@@ -32,6 +32,7 @@
 #include "ipepdfparser.h"
 #include "ipecairopainter.h"
 #include "ipefonts.h"
+#include <sys/types.h>
 
 using namespace ipe;
 
