--- graph_gen.cpp.orig	Sat Nov 25 20:51:17 2006
+++ graph_gen.cpp	Wed Jan 10 22:31:44 2007
@@ -5,6 +5,7 @@
 
 #include <fstream>
 #include <iostream>
+#include <stdlib.h>
 #include <ctime>
 
 using namespace std;
