--- twofishmodule.c.orig	Wed Oct 15 06:46:16 2003
+++ twofishmodule.c	Wed Oct 15 06:46:30 2003
@@ -489,7 +489,7 @@
 Functions:\n\
 new() -- return a new twofish object.\n\
 \n\
-Special Objects: 
+Special Objects: \n\
 \n\
 TwoFishType -- type object for TwoFish objects. \n";
 
