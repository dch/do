--- xmi2mid.cpp.orig	2015-03-19 18:36:34 UTC
+++ xmi2mid.cpp
@@ -27,6 +27,7 @@ SOFTWARE.
 #include <iterator>
 #include <new>
 #include <vector>
+#include <cstdlib>
 
 #include <stdint.h>
 
