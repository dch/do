--- README.md.orig	2014-06-18 22:56:41.000000000 +0900
+++ README.md	2014-06-18 22:56:52.000000000 +0900
@@ -24,7 +24,7 @@
 (setq migemo-options '("-q" "--emacs"))
 
 ;; Set your installed path
-(setq migemo-dictionary "/usr/local/share/migemo/utf-8/migemo-dict")
+(setq migemo-dictionary "/usr/local/share/cmigemo/utf-8/migemo-dict")
 
 (setq migemo-user-dictionary nil)
 (setq migemo-regex-dictionary nil)
