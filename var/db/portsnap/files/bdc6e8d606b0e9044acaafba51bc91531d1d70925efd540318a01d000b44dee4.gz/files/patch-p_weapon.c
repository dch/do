--- ./p_weapon.c.orig	Wed Mar  4 18:51:16 1998
+++ ./p_weapon.c	Wed Jan 10 19:05:28 2007
@@ -4,7 +4,7 @@
 #include "m_player.h"
 
 
-static qboolean	is_quad;
+qboolean	is_quad;
 static byte		is_silenced;
 
 
