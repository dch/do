--- ./tests/test_connect_delay.cpp.orig	2013-07-19 13:30:55.436108722 +0400
+++ ./tests/test_connect_delay.cpp	2013-07-19 13:30:59.430156726 +0400
@@ -22,6 +22,7 @@
 #include <stdlib.h>
 #include <string.h>
 #include <unistd.h>
+#include <time.h>
 #include <string>
 
 #undef NDEBUG
