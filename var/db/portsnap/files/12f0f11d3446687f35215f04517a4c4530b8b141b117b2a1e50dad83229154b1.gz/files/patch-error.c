--- error.c	2008-11-16 02:18:14.000000000 +0200
+++ error.c	2009-02-18 00:27:40.000000000 +0200
@@ -11,7 +11,6 @@
  
 #include "test.h"
 #include "config.h"
-#include <sys/io.h>
 #include "dmi.h"
 
 extern int test_ticks, nticks, beepmode;
