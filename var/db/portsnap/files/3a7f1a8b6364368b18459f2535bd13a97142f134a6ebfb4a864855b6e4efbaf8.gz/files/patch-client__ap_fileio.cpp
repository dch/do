--- ap_fileio.cpp.orig	2012-02-28 00:01:04.000000000 +0100
+++ ap_fileio.cpp	2013-08-05 22:45:10.000000000 +0200
@@ -22,6 +22,7 @@
 #include "windows.h"
 #endif
 
+#include <cmath>
 #include <cstdio>
 #include <cstdlib>
 #include <vector>
