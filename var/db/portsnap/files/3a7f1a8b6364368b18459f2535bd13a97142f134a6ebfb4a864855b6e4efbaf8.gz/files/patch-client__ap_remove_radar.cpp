--- ap_remove_radar.cpp.orig	2012-01-26 07:53:16.000000000 +0100
+++ ap_remove_radar.cpp	2012-08-12 00:14:40.000000000 +0200
@@ -1,5 +1,4 @@
 #include "astropulse.h"
-#include "ap_graphics.h"
 #include "fftw3.h"
 #include "sbtf.h"
 #include "ap_debug.h"
