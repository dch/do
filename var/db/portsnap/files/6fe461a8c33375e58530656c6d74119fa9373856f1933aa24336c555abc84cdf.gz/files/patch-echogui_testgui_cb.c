--- echogui/testgui_cb.c.orig	2011-09-06 14:20:54.000000000 +0200
+++ echogui/testgui_cb.c	2011-09-06 14:20:57.000000000 +0200
@@ -14,7 +14,7 @@
 #include <linux/soundcard.h>
 #include <sys/ioctl.h>
 #include <fcntl.h>
-#include <X11/forms.h>
+#include <forms.h>
 #include <math.h>
 #include <signal.h>
 #include <pthread.h>
