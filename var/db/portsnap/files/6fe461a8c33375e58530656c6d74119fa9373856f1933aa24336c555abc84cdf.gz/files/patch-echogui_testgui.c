--- echogui/testgui.c.orig	2011-09-06 14:21:37.000000000 +0200
+++ echogui/testgui.c	2011-09-06 14:21:42.000000000 +0200
@@ -1,6 +1,6 @@
 /* Form definition file generated with fdesign. */
 
-#include <X11/forms.h>
+#include <forms.h>
 #include <stdlib.h>
 #include "testgui.h"
 
