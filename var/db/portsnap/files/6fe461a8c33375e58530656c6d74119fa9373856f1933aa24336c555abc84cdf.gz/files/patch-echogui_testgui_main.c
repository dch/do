--- echogui/testgui_main.c.orig	2011-09-06 14:19:54.000000000 +0200
+++ echogui/testgui_main.c	2011-09-06 14:20:09.000000000 +0200
@@ -16,7 +16,7 @@
 #include <linux/soundcard.h>
 #include <sys/ioctl.h>
 #include <fcntl.h>
-#include <X11/forms.h>
+#include <forms.h>
 #include <string.h>
 #include <math.h>
 #include <pthread.h>
