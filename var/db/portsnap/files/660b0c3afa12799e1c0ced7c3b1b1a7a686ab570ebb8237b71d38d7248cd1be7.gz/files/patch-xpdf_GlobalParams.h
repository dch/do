Index: xpdf/GlobalParams.h
@@ -132,6 +132,8 @@
 #define xpdfKeyCodeDown           0x100d
 #define xpdfKeyCodeF1             0x1100
 #define xpdfKeyCodeF35            0x1122
+#define xpdfKeyPlus               0x1200
+#define xpdfKeyMinus	           0x1201
 #define xpdfKeyCodeMousePress1    0x2001
 #define xpdfKeyCodeMousePress2    0x2002
 #define xpdfKeyCodeMousePress3    0x2003
