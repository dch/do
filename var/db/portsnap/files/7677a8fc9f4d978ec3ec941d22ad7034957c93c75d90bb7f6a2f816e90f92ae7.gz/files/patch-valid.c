*** valid.c~	Tue Jun  3 12:09:49 1997
--- valid.c	Tue Sep 29 15:26:39 1998
***************
*** 4,7 ****
--- 4,8 ----
  # include	<stdlib.h>
  # include	<string.h>
+ # include	<sys/types.h>
  # include	"pager.h"
  # include	"valid.h"
