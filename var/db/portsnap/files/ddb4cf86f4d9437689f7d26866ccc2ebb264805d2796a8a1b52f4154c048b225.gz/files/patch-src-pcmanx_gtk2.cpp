--- src/pcmanx_gtk2.cpp.orig	2012-01-26 22:31:52.000000000 +0800
+++ src/pcmanx_gtk2.cpp	2012-05-01 00:36:00.000000000 +0800
@@ -35,6 +35,8 @@
 #include <cstring>
 #include <ltdl.h>
 
+#include <libintl.h> 
+
 #include "mainframe.h"
 #include "appconfig.h"
 #include "telnetcon.h"
