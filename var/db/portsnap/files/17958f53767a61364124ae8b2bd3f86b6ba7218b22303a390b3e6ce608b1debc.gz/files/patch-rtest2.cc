--- rtest2.cc.orig	Thu Oct  8 03:12:09 1998
+++ rtest2.cc	Wed Mar 31 20:13:32 2004
@@ -3,7 +3,8 @@
 
 #include <stdio.h>
 #include <stdlib.h>
-#include <iostream.h>
+#include <iostream>
+using namespace std;
 #include "strip.h"
 #include "interface.h"
 
