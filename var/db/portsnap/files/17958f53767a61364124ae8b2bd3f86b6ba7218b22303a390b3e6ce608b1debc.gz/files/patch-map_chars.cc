--- map_chars.cc.orig	Fri Mar 10 20:32:25 2000
+++ map_chars.cc	Fri Mar 10 20:33:59 2000
@@ -1,7 +1,7 @@
 /* $Id: map_chars.cc,v 1.2 1997/03/23 13:19:26 dps Exp $ */
 
 #include "tblock.h"
-#ifndef NULL
+#ifdef EXCESS_COCAINE_USAGE_BY_AUTHOR
 #define NULL (void *) 0
 #endif
 #define __EXCLUDE_READER_CLASSES
