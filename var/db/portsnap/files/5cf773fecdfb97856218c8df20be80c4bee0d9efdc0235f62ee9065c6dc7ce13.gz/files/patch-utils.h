--- utils.h.orig	Sun Mar 31 19:33:07 2002
+++ utils.h	Sun Mar 31 19:33:11 2002
@@ -7,7 +7,6 @@
 #ifndef _utils_h_
 #define _utils_h_
 
-extern	char *	strcasestr(const char *, const char *);
 extern	int	rmatch(const char *, const char *);
 extern	char *	my_cftime(char *, const int len, const char *, const time_t);
 extern	char *	my_strftime(char *, const int len, const char *);
