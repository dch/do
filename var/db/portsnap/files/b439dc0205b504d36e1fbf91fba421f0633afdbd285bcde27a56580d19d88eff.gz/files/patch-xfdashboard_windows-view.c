--- xfdashboard/windows-view.c.orig	2015-03-17 21:31:03 UTC
+++ xfdashboard/windows-view.c
@@ -128,7 +128,7 @@ static void _xfdashboard_windows_view_se
 /* IMPLEMENTATION: Private variables and methods */
 #define SCROLL_EVENT_CHANGES_WORKSPACE_XFCONF_PROP		"/components/windows-view/scroll-event-changes-workspace"
 
-#define DEFAULT_VIEW_ICON								"gtk-fullscreen"
+#define DEFAULT_VIEW_ICON								"view-fullscreen"
 #define DEFAULT_DRAG_HANDLE_SIZE						32.0f
 
 /* Stage interface has changed monitor */
