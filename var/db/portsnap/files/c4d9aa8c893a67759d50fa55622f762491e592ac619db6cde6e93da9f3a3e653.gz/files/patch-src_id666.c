--- src/id666.c.orig	Sat Jun 11 14:13:07 2005
+++ src/id666.c	Sat Jun 11 14:13:27 2005
@@ -100,6 +100,7 @@
 					break;
 
 			default:	/* Who knows. Ignore it. */
+					break;
 		}
 	}
 	
