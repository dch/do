--- toycars/src/MyFisix/Convex.h.orig	2008-09-09 10:14:27.000000000 +0000
+++ toycars/src/MyFisix/Convex.h
@@ -21,6 +21,7 @@
 #include "config.h"
 #endif
 
+#include <unistd.h>
 #include <list>
 using namespace std;
 
