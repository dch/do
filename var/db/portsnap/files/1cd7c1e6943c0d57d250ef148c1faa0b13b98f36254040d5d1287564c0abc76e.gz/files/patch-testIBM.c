--- testIBM.c.orig	Tue Apr 17 17:49:02 2001
+++ testIBM.c	Wed Aug 28 14:32:32 2002
@@ -1,6 +1,6 @@
 #include <stdio.h>
 #include <winscard.h>
-#include <configfile.h>
+
 #include <stdlib.h>  
 #include "commands.h"
 int testIBM(int argc,char** argv ) {
