--- testB.c.orig	Tue Apr 17 17:49:01 2001
+++ testB.c	Wed Aug 28 14:32:32 2002
@@ -1,6 +1,6 @@
 #include <stdio.h>
 #include <winscard.h>
-#include <configfile.h>
+
 #include <stdlib.h>  
 #include "commands.h"
 testB(int argc,char** argv ) {
