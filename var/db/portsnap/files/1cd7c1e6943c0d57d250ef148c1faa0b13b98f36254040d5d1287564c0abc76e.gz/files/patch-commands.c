--- commands.c.orig	Tue Apr 17 17:49:02 2001
+++ commands.c	Wed Aug 28 14:32:32 2002
@@ -1,7 +1,7 @@
 
 #include <stdio.h>
 #include <winscard.h>
-#include <configfile.h>
+
 #include <stdlib.h>  
 #include <stdarg.h>  
 #include "commands.h"
