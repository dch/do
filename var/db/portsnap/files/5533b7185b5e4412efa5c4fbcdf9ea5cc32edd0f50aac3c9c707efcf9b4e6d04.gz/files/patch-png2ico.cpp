--- png2ico.cpp.orig	2002-12-07 22:37:58 UTC
+++ png2ico.cpp
@@ -33,6 +33,8 @@ Notes about transparent and inverted pix
 
 
 #include <cstdio>
+#include <cstring>
+#include <cstdlib>
 #include <vector>
 #include <climits>
 
