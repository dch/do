--- lbreakout/breakout.cpp	2000/10/20 07:01:37	1.1
+++ lbreakout/breakout.cpp	2000/10/20 07:02:11
@@ -19,6 +19,7 @@
 #include "level.h"
 #include <stdlib.h>
 #include <stdio.h>
+#include <sys/types.h>
 #include <sys/timeb.h>
 #include <string.h>
 #include <math.h>
