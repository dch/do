--- lib/spandsp/src/spandsp/t4.h.orig	2007-10-05 20:00:19.000000000 -0400
+++ lib/spandsp/src/spandsp/t4.h	2007-11-06 23:57:56.000000000 -0500
@@ -27,6 +27,8 @@
 
 /*! \file */
 
+#include <time.h>
+
 #if !defined(_SPANDSP_T4_H_)
 #define _SPANDSP_T4_H_
 
