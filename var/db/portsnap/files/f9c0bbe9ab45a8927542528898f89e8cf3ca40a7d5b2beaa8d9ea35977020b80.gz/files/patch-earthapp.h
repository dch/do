--- earthapp.h.orig	1999-12-06 08:14:23.000000000 -0800
+++ earthapp.h	2011-01-18 14:22:52.000000000 -0800
@@ -54,6 +54,8 @@
 #define _EARTHAPP_H
 
 #include <qapplication.h>
+#include <QApplication>
+#include <QDesktopWidget>
 #include <qtimer.h>
 #include <qsize.h>
 #include <qstring.h>
