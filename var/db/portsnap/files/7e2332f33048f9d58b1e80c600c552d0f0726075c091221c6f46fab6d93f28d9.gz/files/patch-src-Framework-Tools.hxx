--- Framework/Tools.hxx.orig	Sun Nov  3 12:12:32 2002
+++ Framework/Tools.hxx	Sun Nov  3 12:13:28 2002
@@ -18,6 +18,7 @@
 #define TOOLS_HXX
 
 #include <string>
+#include <ctype.h>
 
 #ifdef USE_STD
   using namespace std;
