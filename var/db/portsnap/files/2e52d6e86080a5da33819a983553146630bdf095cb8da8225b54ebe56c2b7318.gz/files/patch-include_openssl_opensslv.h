--- include/openssl/opensslv.h.orig	2015-07-26 14:58:42 UTC
+++ include/openssl/opensslv.h
@@ -7,7 +7,7 @@
 #define LIBRESSL_VERSION_TEXT	"LibreSSL 2.2.2"
 
 /* These will never change */
-#define OPENSSL_VERSION_NUMBER	0x20000000L
+#define OPENSSL_VERSION_NUMBER	0x1000107fL
 #define OPENSSL_VERSION_TEXT	LIBRESSL_VERSION_TEXT
 #define OPENSSL_VERSION_PTEXT	" part of " OPENSSL_VERSION_TEXT
 
