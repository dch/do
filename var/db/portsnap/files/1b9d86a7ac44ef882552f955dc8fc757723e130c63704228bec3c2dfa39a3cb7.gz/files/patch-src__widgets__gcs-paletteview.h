--- src/widgets/gcs-paletteview.h.orig
+++ src/widgets/gcs-paletteview.h
@@ -40,6 +40,7 @@
 #include "core/gcs-types.h"
 #include "core/gcs-color.h"
 #include "paletteparser/palette.h"
+#include "palettetreemodel.h"
 #include "palette-selector.h"
 
 using namespace Gnome;
