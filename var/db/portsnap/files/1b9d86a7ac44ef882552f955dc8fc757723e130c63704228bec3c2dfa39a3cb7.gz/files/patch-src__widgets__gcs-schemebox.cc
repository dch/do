--- src/widgets/gcs-schemebox.cc.orig
+++ src/widgets/gcs-schemebox.cc
@@ -45,7 +45,7 @@
 
         SchemeBox::SchemeBox(Scheme schm)
         {
-            SchemeBox::SchemeBox();
+            SchemeBox();
             set_scheme(schm);
         }
 
