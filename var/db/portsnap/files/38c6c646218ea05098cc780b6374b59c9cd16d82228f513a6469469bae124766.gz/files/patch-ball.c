--- ball.c.old	Mon Sep 23 12:48:00 2002
+++ ball.c	Mon Sep 23 12:48:09 2002
@@ -50,7 +50,7 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
-#include <values.h>
+#include <limits.h>
 #include <xpm.h>
 #include <X11/Xos.h>
 
