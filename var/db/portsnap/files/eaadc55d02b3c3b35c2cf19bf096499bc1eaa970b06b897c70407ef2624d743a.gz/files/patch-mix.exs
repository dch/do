--- mix.exs.orig	2015-07-14 14:40:25 UTC
+++ mix.exs
@@ -6,8 +6,7 @@ defmodule Calecto.Mixfile do
      version: "0.3.5",
      elixir: "~> 1.0",
      package: package,
-     description: description,
-     deps: deps]
+     description: description]
   end
 
   def application do
