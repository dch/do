--- smbval/rfcnb-util.inc.c.orig	Wed Sep 26 12:46:02 2007
+++ smbval/rfcnb-util.inc.c	Wed Sep 26 12:47:13 2007
@@ -21,7 +21,7 @@
  * 675 Mass Ave, Cambridge, MA 02139, USA. */
 
 #include <string.h>
-#include <malloc.h>
+#include <stdlib.h>
 
 #include "std-includes.h"
 #include "rfcnb-priv.h"
