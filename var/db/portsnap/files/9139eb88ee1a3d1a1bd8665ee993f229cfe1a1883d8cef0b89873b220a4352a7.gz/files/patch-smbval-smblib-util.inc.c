--- smbval/smblib-util.inc.c.orig	Wed Sep 26 12:47:37 2007
+++ smbval/smblib-util.inc.c	Wed Sep 26 12:47:57 2007
@@ -21,7 +21,7 @@
  * 675 Mass Ave, Cambridge, MA 02139, USA. */
 
 #include "smblib-priv.h"
-#include <malloc.h>
+#include <stdlib.h>
 
 #include "rfcnb.h"
 
