--- asrun/config.py.orig	2013-01-08 09:55:52.000000000 +0100
+++ asrun/config.py	2013-03-17 17:38:29.000000000 +0100
@@ -44,8 +44,8 @@
     'SRCHIST'         : ['histor'],
     # name of "binaries" (as results of a make)
     'MAKE'            : ['debug nodebug'],
-    'BIN_NODBG'       : ['asteru.exe'],
-    'BIN_DBG'         : ['asterd.exe'],
+    'BIN_NODBG'       : ['asteru'],
+    'BIN_DBG'         : ['asterd'],
     'BINCMDE'         : ['commande'],
     'BINELE'          : ['elements'],
     'BINPICKLED'      : ['cata_ele.pickled'],
