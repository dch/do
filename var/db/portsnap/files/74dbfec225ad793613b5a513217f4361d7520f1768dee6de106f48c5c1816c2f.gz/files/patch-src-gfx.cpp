--- src/gfx.cpp.orig	Tue Sep 12 18:28:52 2006
+++ src/gfx.cpp	Tue Sep 12 18:29:04 2006
@@ -7,7 +7,7 @@
  ***************************************************************************/
 
 #include <string.h>
-#include <malloc.h>
+#include <stdlib.h>
 
 
 #include "SDL.h"
