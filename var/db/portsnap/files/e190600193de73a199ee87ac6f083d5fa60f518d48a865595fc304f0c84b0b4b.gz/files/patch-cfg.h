--- cfg.h.orig	2010-07-20 12:04:52.252243199 +0200
+++ cfg.h	2010-07-20 13:51:34.642563477 +0200
@@ -59,3 +59,4 @@
  *
  *   #define LEVELS_PATH     "/usr/local/share/games/oldrunner/levels"
  */
+#define LEVELS_PATH "/usr/local/share/oldrunner"
