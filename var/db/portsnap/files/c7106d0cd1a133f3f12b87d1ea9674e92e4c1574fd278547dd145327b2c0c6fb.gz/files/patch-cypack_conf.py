--- cypack/conf.py.bak	2011-02-12 21:07:24.000000000 +0100
+++ cypack/conf.py	2011-02-12 21:08:05.000000000 +0100
@@ -17,7 +17,7 @@
 # exit the player soon after you start it, it may hang for about 10 seconds
 # trying to access the url.. In that case it's safe to hit ctrl-c because
 # scores and data are already saved. TODO I'll try to do a timeout in next Cy 
-check_for_updates   = 1
+check_for_updates   = 0
 ConfirmDelete       = 1
 play_on_start       = 1   
 score_increment     = 7
