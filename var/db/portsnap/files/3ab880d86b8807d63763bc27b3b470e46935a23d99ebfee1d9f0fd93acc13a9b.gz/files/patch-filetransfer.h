--- ../../include/licq/icq/filetransfer.h.orig	2013-08-25 11:45:17.000000000 +0200
+++ ../../include/licq/icq/filetransfer.h	2014-02-13 21:38:18.000000000 +0100
@@ -76,6 +76,7 @@
 #include <cstring>
 #include <list>
 #include <string>
+#include <time.h>
 
 #include <licq/userid.h>
 
