--- avida-core/source/tools/tArray.h.orig
+++ avida-core/source/tools/tArray.h
@@ -23,6 +23,7 @@
 #ifndef tArray_h
 #define tArray_h
 
+#include <cstdlib>
 #include <cassert>
 
 #ifndef NULL
