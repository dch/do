--- rand.h.orig 2009-08-21 18:45:50.068536643 +0000
+++ rand.h      2009-08-21 18:45:58.564755017 +0000
@@ -1,11 +1,11 @@
 #ifndef RAND_H
 #define RAND_H
 
-using namespace std;
 #include "port.h"
 #include <stdio.h>
 #include <stdlib.h>
 #include <string>
+using namespace std;
 
 class Rand
 {
