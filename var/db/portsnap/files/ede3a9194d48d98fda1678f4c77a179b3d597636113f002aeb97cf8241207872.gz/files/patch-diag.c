--- diag.c.orig	Sun Dec  1 16:11:28 2002
+++ diag.c	Sun Dec  1 16:11:33 2002
@@ -125,8 +125,8 @@
 extern struct st_host_info hinfo[];
 extern int initial_diagnostics;
 extern int screen;
-extern int sys_nerr;
 #if !defined(__FreeBSD__) && !defined(__NetBSD__) && !defined(__GNU_LIBRARY__) && !defined(__GLIBC__) && !defined(__EMX__)
+extern int sys_nerr;
 extern char *sys_errlist[];
 #endif
 
