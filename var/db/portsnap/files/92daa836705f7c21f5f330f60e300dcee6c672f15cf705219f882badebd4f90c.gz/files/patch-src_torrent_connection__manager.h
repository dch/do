--- src/torrent/connection_manager.h
+++ src/torrent/connection_manager.h
@@ -42,6 +42,7 @@
 
 #include <list>
 #include <arpa/inet.h>
+#include <sys/types.h>
 #include <netinet/in.h>
 #include <netinet/in_systm.h>
 #include <netinet/ip.h>
