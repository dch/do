--- test/simple_test.c.old	Fri Feb  3 19:18:27 2006
+++ test/simple_test.c	Fri Feb  3 19:18:48 2006
@@ -47,7 +47,7 @@
 #include <unistd.h>
 #include <ctype.h>
 #include <fcntl.h>
-
+#include <sys/time.h>
 #include <event.h>
 
 #include "dnsres.h"
