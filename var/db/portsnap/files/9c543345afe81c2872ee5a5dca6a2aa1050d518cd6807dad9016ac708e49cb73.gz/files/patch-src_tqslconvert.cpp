--- src/tqslconvert.cpp.orig	2013-10-20 19:33:20.000000000 -0500
+++ src/tqslconvert.cpp	2013-12-07 20:54:11.000000000 -0500
@@ -23,7 +23,7 @@
 #include <vector>
 #include <ctype.h>
 #include <set>
-#include <db.h>
+#include <db5/db.h>
 
 #include <locale.h>
 //#include <iostream>
