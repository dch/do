--- ./utilities.cpp.orig	2014-08-03 12:33:22.000000000 +0200
+++ ./utilities.cpp	2014-08-03 12:33:32.000000000 +0200
@@ -5,6 +5,7 @@
 #include <stdio.h>
 #include <string.h>
 #include <strings.h>
+#include <unistd.h>
 #include <memory>
 
 #include "ioparport.h"
