--- operon.py.orig	2013-09-13 00:49:22.000000000 +0200
+++ operon.py	2014-04-23 12:21:26.430626881 +0200
@@ -1,4 +1,4 @@
-#!/usr/bin/python
+#!/usr/bin/env python
 # Copyright 2012,2013 Christoph Reiter
 #
 # This program is free software; you can redistribute it and/or modify
