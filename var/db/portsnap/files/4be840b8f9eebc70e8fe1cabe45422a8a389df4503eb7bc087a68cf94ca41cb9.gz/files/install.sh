export PATH=/usr/local/zpu/bin:$PATH
cd gccbuild
%%MAKE_CMD%% install
