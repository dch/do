--- irc.c.orig	2014-05-17 02:34:33.000000000 +0900
+++ irc.c	2014-05-17 02:34:43.000000000 +0900
@@ -30,7 +30,9 @@
  *
  */
 
+#if 0
 static const char rcsid[] = "$Id: irc.c,v 1.13 2004/11/18 21:14:28 dhartmei Exp $";
+#endif
 
 #include <stdarg.h>
 #include <stdio.h>
