--- src/readConfig.cpp.orig	Mon May 24 09:11:26 2004
+++ src/readConfig.cpp	Mon May 24 09:11:45 2004
@@ -2,6 +2,7 @@
 #include <fstream>
 #include <sstream>
 #include <string>
+#include <clocale>
 using namespace std;
 
 #include "body.h"
