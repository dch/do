--- ggz-txt/loop.c.orig	Mon May 17 23:20:01 2004
+++ ggz-txt/loop.c	Sun Jul 18 20:25:18 2004
@@ -32,6 +32,7 @@
 #include <ggz.h>
 #include <unistd.h>
 #include <stdlib.h>
+#include <string.h>
 #include <sys/time.h>
 #include <sys/types.h>
 
