--- tttxt/main.c.orig	Mon May 17 23:21:10 2004
+++ tttxt/main.c	Sun Jul 18 20:32:02 2004
@@ -24,6 +24,7 @@
 #include <fcntl.h>
 #include <errno.h>
 #include <string.h>
+#include <sys/time.h>
 
 #include <ggz_common.h>
 #include <ggzmod.h>
