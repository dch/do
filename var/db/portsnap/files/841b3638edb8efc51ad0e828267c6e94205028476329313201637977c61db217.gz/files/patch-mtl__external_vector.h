--- mtl/external_vector.h.orig	2007-04-10 16:03:10.000000000 -0400
+++ mtl/external_vector.h	2012-01-01 03:59:14.000000000 -0500
@@ -3,6 +3,7 @@
 
 #include "mtl/mtl_iterator.h"
 #include "mtl/mtl_exception.h"
+#include <cstddef>
 
 namespace mtl {
 
