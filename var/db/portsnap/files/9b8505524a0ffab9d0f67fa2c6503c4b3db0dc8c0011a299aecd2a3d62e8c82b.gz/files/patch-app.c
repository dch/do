--- app.c.orig	Wed Nov 26 11:50:10 2003
+++ app.c	Wed Nov 26 11:50:23 2003
@@ -18,6 +18,7 @@
  */
 
 
+#include <sys/types.h>
 #include "common.h"
 #include <string.h>
 
