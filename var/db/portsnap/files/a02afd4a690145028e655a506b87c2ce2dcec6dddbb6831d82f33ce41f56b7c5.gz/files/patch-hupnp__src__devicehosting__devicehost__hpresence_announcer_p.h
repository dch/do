--- ./hupnp/src/devicehosting/devicehost/hpresence_announcer_p.h.orig	2012-01-24 10:41:39.103825710 +0100
+++ ./hupnp/src/devicehosting/devicehost/hpresence_announcer_p.h	2012-01-24 10:42:13.739148738 +0100
@@ -31,6 +31,7 @@
 //
 
 #include "hserverdevicecontroller_p.h"
+#include "hdevicehost_ssdp_handler_p.h"
 
 #include "../../general/hupnp_global_p.h"
 #include "../../devicemodel/hdevicestatus.h"
