--- sizes.h.orig	1995-07-13 16:14:05.000000000 +0400
+++ sizes.h	2014-08-09 11:16:01.638794330 +0400
@@ -21,12 +21,12 @@
 #ifndef DOUBLE
 #define TEXTWIDTH 8
 #define TEXTHEIGHT 8
-#define FONT1 "5x8"
+#define FONT1 "-misc-fixed-*-r-*-*-8-*-*-*-*-*-*-*"
 #define FONT2 "5x7"
 #else
 #define TEXTWIDTH 8
 #define TEXTHEIGHT 16
-#define FONT1 "8x16"
+#define FONT1 "-misc-fixed-*-r-*-*-18-*-*-*-*-*-*-*"
 #define FONT2 "7x14"
 #endif
 //#define PFONT "clR6x8.fb"/*clR8x8" "6x10"*/
