--- src/queue_cond.cc.orig	2013-03-22 15:35:15.000000000 +0900
+++ src/queue_cond.cc	2014-01-22 18:55:04.861289350 +0900
@@ -10,6 +10,7 @@
 #include <string>
 #include <iostream>
 #endif
+#include "queue_config.h"
 #include "queue_cond.h"
 
 using namespace std;
