--- src/skyrocket_sound.cpp.orig	2009-04-22 09:41:23.000000000 +0900
+++ src/skyrocket_sound.cpp	2009-05-21 18:07:02.000000000 +0900
@@ -25,6 +25,7 @@
 #include <AL/al.h>
 #include <AL/alut.h>
 
+#include <cstdlib>
 #include <list>
 
 #include "loadTexture.h"
