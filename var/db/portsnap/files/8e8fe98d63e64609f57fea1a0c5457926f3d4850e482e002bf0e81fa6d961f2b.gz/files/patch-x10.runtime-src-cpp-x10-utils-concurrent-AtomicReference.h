--- ../x10.runtime/src-cpp/x10/util/concurrent/AtomicReference.h.orig	2014-03-09 15:50:47.000000000 +0100
+++ ../x10.runtime/src-cpp/x10/util/concurrent/AtomicReference.h	2014-03-09 15:51:15.000000000 +0100
@@ -15,6 +15,7 @@
 #include <x10aux/config.h>
 #include <x10aux/ref.h>
 #include <x10aux/RTT.h>
+#include <x10aux/basic_functions.h>
 #include <x10aux/string_utils.h>
 #include <x10aux/atomic_ops.h>
 

