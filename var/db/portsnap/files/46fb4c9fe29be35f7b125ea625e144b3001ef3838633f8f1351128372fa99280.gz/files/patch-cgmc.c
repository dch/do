--- cgmc.c.orig	Fri Sep 13 02:57:25 1991
+++ cgmc.c	Sat Jun 16 02:06:22 2007
@@ -3,6 +3,7 @@
 #include <ctype.h>
 #include <math.h>
 #include <stdio.h>
+#include <string.h>
 #include "defs.h"
 #include "ccdefs.h"
 #define byte_size 8
