--- header.h.orig	Sun Jun 28 00:54:48 1998
+++ header.h	Sun Jun 28 00:58:25 1998
@@ -68,7 +68,7 @@
 /*   out a block of definitions like those below.)                           */
 /* ------------------------------------------------------------------------- */
 
-/* #define UNIX */
+#define UNIX
 
 /* ------------------------------------------------------------------------- */
 /*   The first task is to include the ANSI header files, and typedef         */
