--- ./filesnarf.c.orig	2001-03-15 09:33:03.000000000 +0100
+++ ./filesnarf.c	2014-07-22 13:20:14.000000000 +0200
@@ -134,8 +134,8 @@
 	int fd;
 
 	warnx("%s.%d > %s.%d: %s (%d@%d)",
-	      libnet_host_lookup(addr->daddr, 0), addr->dest,
-	      libnet_host_lookup(addr->saddr, 0), addr->source,
+	      libnet_addr2name4(addr->daddr, LIBNET_DONT_RESOLVE), addr->dest,
+	      libnet_addr2name4(addr->saddr, LIBNET_DONT_RESOLVE), addr->source,
 	      ma->filename, len, ma->offset);
 	
 	if ((fd = open(ma->filename, O_WRONLY|O_CREAT, 0644)) >= 0) {
@@ -353,7 +353,7 @@
 }
 
 static void
-decode_udp_nfs(struct libnet_ip_hdr *ip)
+decode_udp_nfs(struct libnet_ipv4_hdr *ip)
 {
 	static struct tuple4 addr;
 	struct libnet_udp_hdr *udp;
