--- ./codeconv.c.orig	2000-01-26 14:38:51.000000000 +0100
+++ ./codeconv.c	2014-05-18 20:48:26.000000000 +0200
@@ -31,6 +31,7 @@
  */
 
 #include <stdio.h>
+#include <string.h>
 #include "namazu.h"
 
 uchar kanji2nd;
