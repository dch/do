--- src/fileRepository.h.orig	2010-05-30 19:11:10.000000000 +0000
+++ src/fileRepository.h
@@ -23,6 +23,7 @@
 #define FILEREPOSITORY_H_
 
 #include <stdio.h>
+#include <unistd.h>
 
 #include "definition.h"
 #include "mediaRepository.h"
