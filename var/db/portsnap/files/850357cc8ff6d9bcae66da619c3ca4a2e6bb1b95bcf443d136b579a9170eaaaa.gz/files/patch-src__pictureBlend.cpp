--- src/pictureBlend.cpp.orig
+++ src/pictureBlend.cpp
@@ -9,6 +9,8 @@
 // Copyright: See COPYING file that comes with this distribution
 //
 //
+#include <string>
+
 #include "pictureBlend.h"
 #include "exception.h"
 
