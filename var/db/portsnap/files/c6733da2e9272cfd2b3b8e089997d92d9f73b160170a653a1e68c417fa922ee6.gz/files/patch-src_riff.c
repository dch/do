--- src/riff.c.orig	Mon Nov  9 08:22:55 1998
+++ src/riff.c	Fri Jun 30 19:49:19 2000
@@ -33,7 +33,7 @@
 
 #ifdef linux
 #include <endian.h>
-#elif defined (FreeBSD)
+#elif defined (__FreeBSD__)
 #include <machine/endian.h>
 #elif defined (sgi)
 #include <sys/endian.h>
