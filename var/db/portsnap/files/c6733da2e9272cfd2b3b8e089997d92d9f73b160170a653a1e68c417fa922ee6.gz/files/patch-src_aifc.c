--- src/aifc.c.orig	Mon Nov  9 08:22:55 1998
+++ src/aifc.c	Fri Jun 30 19:49:15 2000
@@ -9,7 +9,7 @@
 
 #ifdef linux
 #include <endian.h>
-#elif defined (FreeBSD)
+#elif defined (__FreeBSD__)
 #include <machine/endian.h>
 #elif defined (sgi)
 #include <sys/endian.h>
