--- default.c.orig	2015-05-13 16:16:24 UTC
+++ default.c
@@ -447,7 +447,7 @@ static const char *default_variables[] =
     "OBJC", "gcc",
 #else
     "CC", "cc",
-    "CXX", "g++",
+    "CXX", "c++",
     "OBJC", "cc",
 #endif
 
