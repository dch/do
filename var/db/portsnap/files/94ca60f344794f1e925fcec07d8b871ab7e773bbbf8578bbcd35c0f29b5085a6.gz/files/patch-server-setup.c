--- server/setup.c.orig
+++ server/setup.c
@@ -2,6 +2,7 @@
  *  $Id: setup.c,v 1.2 2005/05/09 20:22:29 lordjaxom Exp $
  */
  
+#include <stdint.h>
 #include <vdr/menuitems.h>
 
 #include "server/setup.h"
