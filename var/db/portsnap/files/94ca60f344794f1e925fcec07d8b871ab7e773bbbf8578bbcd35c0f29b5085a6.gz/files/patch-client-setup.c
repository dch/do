--- client/setup.c.orig
+++ client/setup.c
@@ -2,6 +2,7 @@
  *  $Id: setup.c,v 1.2 2005/02/08 15:34:38 lordjaxom Exp $
  */
  
+#include <stdint.h>
 #include <vdr/menuitems.h>
 
 #include "client/setup.h"
