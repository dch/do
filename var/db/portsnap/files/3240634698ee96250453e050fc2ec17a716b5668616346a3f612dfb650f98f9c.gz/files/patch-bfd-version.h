--- ./bfd/version.h.orig	2011-11-21 09:29:28.000000000 +0000
+++ ./bfd/version.h	2012-01-21 13:31:35.000000000 +0000
@@ -1,4 +1,4 @@
-#define BFD_VERSION_DATE 20111121
+#define BFD_VERSION_DATE (PSNPT 20120103)
 #define BFD_VERSION @bfd_version@
 #define BFD_VERSION_STRING  @bfd_version_package@ @bfd_version_string@
 #define REPORT_BUGS_TO @report_bugs_to@
