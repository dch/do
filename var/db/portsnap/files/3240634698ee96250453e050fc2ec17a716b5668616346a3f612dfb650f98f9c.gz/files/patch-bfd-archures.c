--- ./bfd/archures.c.orig	2011-08-01 23:04:19.000000000 +0000
+++ ./bfd/archures.c	2012-01-21 13:31:35.000000000 +0000
@@ -175,6 +175,7 @@
 .#define bfd_mach_mips_loongson_2f      3002
 .#define bfd_mach_mips_loongson_3a      3003
 .#define bfd_mach_mips_sb1              12310201 {* octal 'SB', 01 *}
+.#define bfd_mach_mips_allegrex         10111431 {* octal 'AL', 31 *}
 .#define bfd_mach_mips_octeon		6501
 .#define bfd_mach_mips_xlr              887682   {* decimal 'XLR'  *}
 .#define bfd_mach_mipsisa32             32
