<?php
/* This file was automatically created by the NfSen %%PORTVERSION%% install.pl script */

$COMMSOCKET = "%%PREFIX%%/var/nfsen/run/nfsen.comm";

$DEBUG=0;

?>
