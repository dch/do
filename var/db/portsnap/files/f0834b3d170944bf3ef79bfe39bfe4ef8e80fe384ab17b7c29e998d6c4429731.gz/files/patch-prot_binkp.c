--- bforce/prot_binkp.c.orig	Fri Aug 31 00:31:19 2001
+++ bforce/prot_binkp.c	Thu Jul 29 23:21:03 2004
@@ -181,7 +181,7 @@
 			break;
 
 		default:
-			/* Avoid warnings */
+			break;
 		}
 		
 		/*
@@ -318,7 +318,7 @@
 			break;
 
 		default:
-			/* Avoid warnings */
+			break;
 		}
 		
 		/*
