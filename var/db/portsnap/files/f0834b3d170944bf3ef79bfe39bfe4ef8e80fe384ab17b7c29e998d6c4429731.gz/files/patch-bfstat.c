--- bfutil/bfstat.c.orig	Thu Nov 21 23:23:00 2002
+++ bfutil/bfstat.c	Sat Aug  7 02:20:35 2004
@@ -17,6 +17,7 @@
 #include "logger.h"
 #include "util.h"
 #include "outbound.h"
+#include "session.h"
 
 /*
  * Command line options storage structure
