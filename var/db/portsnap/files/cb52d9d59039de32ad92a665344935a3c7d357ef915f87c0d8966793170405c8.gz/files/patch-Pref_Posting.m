--- Pref_Posting.m.orig	2004-03-03 00:58:37.000000000 +0100
+++ Pref_Posting.m	2010-05-23 08:54:51.000000000 +0200
@@ -5,6 +5,7 @@
 #include <Foundation/NSObject.h>
 #include <Foundation/NSString.h>
 #include <Foundation/NSUserDefaults.h>
+#include <Foundation/NSBundle.h>
 #include <GNUstepGUI/GSVbox.h>
 #include <GNUstepGUI/GSHbox.h>
 #include <AppKit/NSButton.h>
