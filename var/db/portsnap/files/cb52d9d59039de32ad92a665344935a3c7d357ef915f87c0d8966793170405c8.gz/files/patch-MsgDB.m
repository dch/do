--- MsgDB.m.orig	2004-03-03 00:58:37.000000000 +0100
+++ MsgDB.m	2008-05-03 09:39:45.000000000 +0200
@@ -18,6 +18,7 @@
 #include <Foundation/NSAutoreleasePool.h>
 #include <Foundation/NSNotification.h>
 #include <Foundation/NSData.h>
+#include <Foundation/NSDictionary.h>
 
 #include "MsgDB.h"
 
