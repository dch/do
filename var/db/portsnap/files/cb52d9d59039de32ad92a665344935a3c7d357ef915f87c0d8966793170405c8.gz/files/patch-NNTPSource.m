--- NNTPSource.m.orig	2004-03-03 00:58:37.000000000 +0100
+++ NNTPSource.m	2010-05-23 08:56:18.000000000 +0200
@@ -11,6 +11,7 @@
 #include <Foundation/NSException.h>
 
 #include <Foundation/NSBundle.h>
+#include <Foundation/NSDictionary.h>
 
 #include "MsgDB.h"
 
