--- asc85ec.c.orig	2013-04-27 23:43:09.000000000 +0900
+++ asc85ec.c	2013-04-27 23:43:22.000000000 +0900
@@ -2,6 +2,7 @@
 /* (C) Thomas Merz 1994-2002 */
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <fcntl.h>
 
 /* try to identify Mac compilers */
