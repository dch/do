--- mathmlps/main.cc.orig	2013-10-04 15:05:03.000000000 +0200
+++ mathmlps/main.cc	2013-10-04 15:05:17.000000000 +0200
@@ -18,6 +18,7 @@
 
 #include <config.h>
 
+#include <unistd.h>
 #include <cassert>
 #include <fstream>
 
