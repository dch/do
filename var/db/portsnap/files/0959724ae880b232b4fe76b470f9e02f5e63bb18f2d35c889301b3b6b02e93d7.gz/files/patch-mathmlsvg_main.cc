--- mathmlsvg/main.cc.orig	2013-10-04 15:04:01.000000000 +0200
+++ mathmlsvg/main.cc	2013-10-04 15:04:19.000000000 +0200
@@ -18,6 +18,7 @@
 
 #include <config.h>
 
+#include <unistd.h>
 #include <cassert>
 #include <fstream>
 
