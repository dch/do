--- kpathsea/config.h.orig	Fri Feb  6 04:59:31 1998
+++ kpathsea/config.h	Mon Jan 16 21:02:28 2006
@@ -20,6 +20,9 @@
 #ifndef KPATHSEA_CONFIG_H
 #define KPATHSEA_CONFIG_H
 
+/* For basename(3). */
+#include <libgen.h>
+
 /* System defines are for non-Unix systems only.  (Testing for all Unix
    variations should be done in configure.)  Presently the defines used
    are: AMIGA DOS OS2 VMCMS VMS WIN32.  I do not use any of these systems
