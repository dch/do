--- src/defines.h~
+++ src/defines.h
@@ -1,7 +1,7 @@
 #ifndef DEFINES_H
 #define DEFINES_H
 
-#if defined(__sparc__)
+#if 0 //defined(__sparc__)
 
 #define NL "\n"
 #define HAVE_ENCDEC 0
