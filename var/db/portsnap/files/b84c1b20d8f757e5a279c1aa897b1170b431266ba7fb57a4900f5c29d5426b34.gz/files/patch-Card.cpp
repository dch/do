--- ./Card.cpp.orig	2013-10-29 15:12:13.000000000 -0200
+++ ./Card.cpp	2013-10-29 15:12:13.000000000 -0200
@@ -25,6 +25,8 @@
 #include <iostream>
 #include "Card.h"
 
+using namespace std;
+
 //## Constructors
 
 Card::Card(int CardIndex)
