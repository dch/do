--- ./CaribbeanStud.cpp.orig	2013-10-29 15:12:43.000000000 -0200
+++ ./CaribbeanStud.cpp	2013-10-29 15:12:55.000000000 -0200
@@ -27,6 +27,8 @@
 #include "Player.h"
 #include "Table.h"
 
+using namespace std;
+
 
 int main(int argc, char ** argv)
 {
