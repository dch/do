--- src/synfig/transform.cpp.orig
+++ src/synfig/transform.cpp
@@ -31,6 +31,7 @@
 
 #include "transform.h"
 #include <algorithm>
+#include <cstdlib>
 
 #endif
 
