--- assa/Logger_Impl.cpp.orig	Thu Jul 20 06:30:54 2006
+++ assa/Logger_Impl.cpp	Wed Sep  6 16:20:05 2006
@@ -14,6 +14,7 @@
 
 #include <iostream>
 #include <iomanip>
+#include <cstdio>
 #include <string.h>				// strerror(3)
 
 #include "assa/TimeVal.h"
