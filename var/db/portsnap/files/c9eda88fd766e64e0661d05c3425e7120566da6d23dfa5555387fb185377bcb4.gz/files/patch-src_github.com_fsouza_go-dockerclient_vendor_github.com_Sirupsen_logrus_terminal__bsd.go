--- src/github.com/fsouza/go-dockerclient/external/github.com/Sirupsen/logrus/terminal_bsd.go.orig	2015-07-17 20:42:10 UTC
+++ src/github.com/fsouza/go-dockerclient/external/github.com/Sirupsen/logrus/terminal_bsd.go
@@ -1,4 +1,4 @@
-// +build darwin freebsd openbsd netbsd dragonfly
+// +build darwin openbsd netbsd dragonfly
 
 package logrus
 
