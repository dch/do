--- src/ffmpegsource_common.h.orig
+++ src/ffmpegsource_common.h
@@ -34,6 +34,7 @@
 
 #ifdef WITH_FFMS2
 #include <map>
+#include <string>
 
 #include <ffms.h>
 
