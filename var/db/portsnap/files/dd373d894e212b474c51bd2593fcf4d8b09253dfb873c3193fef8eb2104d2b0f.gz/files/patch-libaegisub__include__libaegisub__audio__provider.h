--- libaegisub/include/libaegisub/audio/provider.h.orig	2014-07-28 23:29:16.000000000 +0900
+++ libaegisub/include/libaegisub/audio/provider.h	2014-08-05 19:40:17.000000000 +0900
@@ -20,6 +20,7 @@
 #include <libaegisub/fs_fwd.h>
 
 #include <atomic>
+#include <memory>
 #include <vector>
 
 namespace agi {
