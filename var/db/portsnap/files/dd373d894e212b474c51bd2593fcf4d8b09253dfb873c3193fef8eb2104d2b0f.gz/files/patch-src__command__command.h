--- src/command/command.h.orig	2014-08-05 20:09:07.000000000 +0900
+++ src/command/command.h	2014-08-05 20:09:21.000000000 +0900
@@ -17,6 +17,7 @@
 /// @ingroup command
 
 #include <map>
+#include <memory>
 #include <string>
 #include <vector>
 
