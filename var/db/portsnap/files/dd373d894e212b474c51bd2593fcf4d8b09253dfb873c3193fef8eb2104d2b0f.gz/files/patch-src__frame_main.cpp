--- src/frame_main.cpp.orig
+++ src/frame_main.cpp
@@ -80,6 +80,7 @@
 #include <wx/msgdlg.h>
 #include <wx/statline.h>
 #include <wx/sysopt.h>
+#include <wx/toolbar.h>
 
 enum {
 	ID_APP_TIMER_STATUSCLEAR				= 12002
