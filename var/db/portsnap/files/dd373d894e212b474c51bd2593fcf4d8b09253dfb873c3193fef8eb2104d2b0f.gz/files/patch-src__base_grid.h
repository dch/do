--- src/base_grid.h.orig
+++ src/base_grid.h
@@ -39,6 +39,8 @@
 #include <map>
 #include <memory>
 #include <vector>
+#include <wx/brush.h>
+#include <wx/scrolbar.h>
 #include <wx/window.h>
 
 #include "selection_controller.h"
