--- src/video_frame.h.orig
+++ src/video_frame.h
@@ -15,6 +15,7 @@
 // Aegisub Project http://www.aegisub.org/
 
 #include <vector>
+#include <cstddef>
 
 class wxImage;
 
