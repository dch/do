--- cpp/Math/Segment2.h.orig	Sat Mar  3 10:07:34 2007
+++ cpp/Math/Segment2.h	Wed Apr 11 18:10:37 2007
@@ -8,7 +8,6 @@
 #ifndef SEGMENT2_H__
 #define SEGMENT2_H__
 
-#include <boost/python.hpp>
 
 
 #include <stdio.h>
@@ -17,6 +16,7 @@
 
 #include <Math/Point2.h>
 #include <Math/Vector2.h>
+#include <boost/python.hpp>
 
 
 
