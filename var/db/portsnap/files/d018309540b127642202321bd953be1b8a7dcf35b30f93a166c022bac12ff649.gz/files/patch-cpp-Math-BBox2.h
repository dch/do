--- cpp/Math/BBox2.h.orig	Sat Mar  3 10:31:14 2007
+++ cpp/Math/BBox2.h	Wed Apr 11 16:32:28 2007
@@ -8,7 +8,6 @@
 #ifndef BBOX2_H__
 #define BBOX2_H__
 
-#include <boost/python.hpp>
 
 
 
@@ -24,6 +23,7 @@
 #include <Math/Polygon2.h>
 #include <Math/Side.h>
 #include <Math/Axis.h>
+#include <boost/python.hpp>
 
 /*
 2D BOUNDING BOX
