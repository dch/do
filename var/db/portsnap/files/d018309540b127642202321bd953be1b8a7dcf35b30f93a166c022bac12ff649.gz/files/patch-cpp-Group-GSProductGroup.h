--- cpp/Group/GSProductGroup.h.orig	Sun May  6 11:48:08 2007
+++ cpp/Group/GSProductGroup.h	Fri Jul 13 00:53:37 2007
@@ -8,13 +8,13 @@
 #ifndef GSPRODUCTGROUP_H__
 #define GSPRODUCTGROUP_H__
 
-#include <boost/python.hpp>
 
 #include <Util/Array.h>
 
 #include <Model/GSProductModel.h>
 
 #include <Graphics/Region.h>
+#include <boost/python.hpp>
 
 
 
