--- cpp/Math/Vector2.h.orig	2008-12-30 23:41:26.000000000 +0900
+++ cpp/Math/Vector2.h	2012-03-06 22:15:22.000000000 +0900
@@ -8,6 +8,7 @@
 #ifndef VECTOR2_H__
 #define VECTOR2_H__
 
+#include <cstdio>
 #include <math.h>
 
 #include <algorithm>
