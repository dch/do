--- cpp/Model/GSProductModel.h.orig	Sun May  6 08:28:39 2007
+++ cpp/Model/GSProductModel.h	Thu Jul 12 23:09:13 2007
@@ -10,7 +10,6 @@
 
 #include <string>
 
-#include <boost/python.hpp>
 
 #include <Util/UniqueID.h>
 
@@ -26,6 +25,7 @@
 #include <Model/VisualPlane.h>
 
 #include <Product/GSProduct.h>
+#include <boost/python.hpp>
 
 
 
