--- cpp/Util/Pool.h.orig
+++ cpp/Util/Pool.h
@@ -8,6 +8,7 @@
 #ifndef POOL_H__
 #define POOL_H__
 
+#include <cstdlib>
 #include <memory.h>
 
 #include <Util/Array.h>
