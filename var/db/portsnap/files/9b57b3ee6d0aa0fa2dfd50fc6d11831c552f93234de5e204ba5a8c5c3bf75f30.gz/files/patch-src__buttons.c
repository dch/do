--- src/buttons.c.orig	2003-01-06 21:25:41.000000000 +0800
+++ src/buttons.c	2011-09-08 14:25:06.000000000 +0800
@@ -21,6 +21,8 @@
 
 #include "dat.h"
 #include "fns.h"
+#include <stdio.h>
+#include <string.h>
 #include <X11/cursorfont.h>
 
 void
