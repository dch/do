--- src/menu.c.orig	2003-01-06 21:27:35.000000000 +0800
+++ src/menu.c	2011-09-08 14:29:36.000000000 +0800
@@ -20,6 +20,7 @@
 /* $Id$ */
 #include "dat.h"
 #include "fns.h"
+#include <string.h>
 
 char * b2items[4] = 
 {
