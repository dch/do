--- src/wm.c.orig	2011-09-08 14:25:35.000000000 +0800
+++ src/wm.c	2011-09-08 14:25:46.000000000 +0800
@@ -19,6 +19,8 @@
 
 /* $Id: wm.c,v 1.1 2002/04/23 23:42:36 benj Exp $ */
 
+#include <stdio.h>
+#include <stdlib.h>
 #include <X11/Xlib.h>
 #include <X11/Xutil.h>
 
