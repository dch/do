--- Sources/Draw/SWFeatureLevel.h.orig	2014-06-23 15:55:03.000000000 +0400
+++ Sources/Draw/SWFeatureLevel.h	2014-07-31 00:18:47.036897321 +0400
@@ -55,6 +55,7 @@
 #endif
 
 #include <algorithm>
+#include <cmath>
 #include <Core/ConcurrentDispatch.h>
 #include <Core/Debug.h>
 
