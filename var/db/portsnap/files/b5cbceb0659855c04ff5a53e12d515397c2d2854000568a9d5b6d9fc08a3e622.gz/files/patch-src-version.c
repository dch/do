--- src/version.c.orig	2014-04-01 07:50:07.858192019 +0000
+++ src/version.c	2014-04-01 07:53:19.724326422 +0000
@@ -113,7 +113,7 @@
   "toot, Toby Verrall <to7@antipope.fsnet.co.uk>",
   "vx0, Mark Miller <mark@oc768.net>",
   "wiz, Jason Dambrosio <jason@wiz.cx>",
-  "Xride, S�ren Straarup <xride@x12.dk>",
+  "Xride, S\u00f8ren Straarup <xride@x12.dk>",
   "zb^3, Alfred Perlstein <alfred@freebsd.org>",
   "",
   "Others are welcome. Always. And if we left anyone off the above list,",
