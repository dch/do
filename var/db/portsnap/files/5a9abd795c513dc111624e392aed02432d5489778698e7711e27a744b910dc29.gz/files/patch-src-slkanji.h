--- src/slkanji.h.orig	Fri Apr  6 03:48:00 2007
+++ src/slkanji.h	Fri Apr  6 03:48:03 2007
@@ -48,7 +48,6 @@
 #define NULL 0
 #endif
 
-extern char *Kcode[];
 extern int	kSLfiAuto, SKanaToDKana;
 extern int	kSLcode;
 extern int	kSLfile_code, kSLinput_code, kSLdisplay_code, kSLsystem_code;
