--- ./setup.py.orig	2013-08-20 18:59:30.000000000 +0300
+++ ./setup.py	2013-11-11 16:18:52.782247350 +0200
@@ -27,7 +27,6 @@
     license="2-clause BSD",
     packages=["patsy"],
     url="https://github.com/pydata/patsy",
-    install_requires=["numpy"],
     classifiers =
       [ "Development Status :: 4 - Beta",
         "Intended Audience :: Developers",
