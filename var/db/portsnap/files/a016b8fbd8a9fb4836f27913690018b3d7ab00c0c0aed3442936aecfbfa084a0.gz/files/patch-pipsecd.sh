--- pipsecd.sh.orig	Thu Oct 14 12:58:43 1999
+++ pipsecd.sh	Thu Oct 14 13:00:38 1999
@@ -0,0 +1,2 @@
+#!/bin/sh
+cd /usr/local; [ -x sbin/pipsecd -a -f etc/ipsec/pipsecd.conf ] && sbin/pipsecd & && echo -n ' pipsecd'
