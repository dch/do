--- tetris.c.orig	2012-04-09 13:32:21.000000000 +0200
+++ tetris.c	2012-08-17 00:10:28.000000000 +0200
@@ -20,7 +20,6 @@
  * along with this program.  If not, see <http://www.gnu.org/licenses/>.
  */
  
-#include <malloc.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <time.h>
