--- utils/ResourceManager.cpp.orig
+++ utils/ResourceManager.cpp
@@ -12,6 +12,7 @@
 // ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 // FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details
 //
+#include <cstring>
 #include <iomanip>
 #include <sys/types.h>
 #include <sys/stat.h>
