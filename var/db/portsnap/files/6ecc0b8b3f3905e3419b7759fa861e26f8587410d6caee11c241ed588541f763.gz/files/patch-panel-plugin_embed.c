--- panel-plugin/embed.c.orig	2015-07-14 19:18:09 UTC
+++ panel-plugin/embed.c
@@ -49,7 +49,7 @@
 #define DEFAULT_LABEL_FONT   NULL
 #define DEFAULT_POLL_DELAY   0
 #define DEFAULT_MIN_SIZE     EMBED_MIN_SIZE_MATCH_WINDOW
-#define DEFAULT_EXPAND       TRUE
+#define DEFAULT_EXPAND       FALSE
 #define DEFAULT_SHOW_HANDLE  FALSE
 
 
