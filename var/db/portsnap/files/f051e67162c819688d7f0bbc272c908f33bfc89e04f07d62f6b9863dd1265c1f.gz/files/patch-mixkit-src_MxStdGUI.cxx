--- mixkit/src/MxStdGUI.cxx.orig	2011-09-06 14:12:15.000000000 +0200
+++ mixkit/src/MxStdGUI.cxx	2011-09-06 14:12:47.000000000 +0200
@@ -15,7 +15,7 @@
 #include "MxGLUtils.h"
 #include "MxSMF.h"
 #include <FL/Fl_Color_Chooser.H>
-#include <FL/fl_file_chooser.H>
+#include <FL/Fl_File_Chooser.H>
 #include <FL/filename.H>
 
 
