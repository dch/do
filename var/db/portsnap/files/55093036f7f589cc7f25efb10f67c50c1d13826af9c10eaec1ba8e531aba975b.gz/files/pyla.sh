#!/bin/sh

exec %%PYTHON_CMD%% %%PREFIX%%/lib/pyla/pyla.py
