--- src/Array.h.orig	Sat Aug 14 12:22:02 2004
+++ src/Array.h	Sat Aug 14 12:22:40 2004
@@ -19,6 +19,8 @@
  * Cambridge, MA 02139, USA.
  */
 
+#include <cassert>
+
 #ifndef _ARRAY_H
 #define _ARRAY_H
 
