--- remote.c.orig	Sat Sep  7 16:54:12 2002
+++ remote.c	Sat Sep  7 16:54:24 2002
@@ -65,7 +65,7 @@
 /*      ******************** Local defines                ************** */
 
 /*  FIXME: Remove this old code someday  */
-#ifdef 0
+#if 0
 #  define OLD_DEV_SYSMOUSE_STUFF
 #endif
 
