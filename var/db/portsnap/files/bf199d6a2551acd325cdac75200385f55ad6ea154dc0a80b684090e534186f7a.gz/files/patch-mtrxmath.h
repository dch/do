--- mtrxmath.h.orig	Tue Jan  9 20:33:48 2001
+++ mtrxmath.h	Tue Jan  9 20:35:02 2001
@@ -13,7 +13,6 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
-#include <malloc.h>
 #include <unistd.h>
 #include <getopt.h>
 
