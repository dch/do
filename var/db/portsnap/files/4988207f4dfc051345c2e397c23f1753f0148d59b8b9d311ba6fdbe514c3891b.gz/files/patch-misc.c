--- misc.c.ori	2006-08-18 16:37:02.000000000 +0200
+++ misc.c	2010-05-26 14:01:16.000000000 +0200
@@ -4,6 +4,7 @@
 #include <stdlib.h>
 #include <string.h>
 #include <ctype.h>
+#include <sys/types.h>
 #include "user_defines.h"
 #include "mysql_defines.h"
 #include "misc.h"
