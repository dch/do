--- par2cmdline.h.orig	2010-08-28 00:21:07.730518551 +0200
+++ par2cmdline.h	2010-08-28 00:21:42.779186595 +0200
@@ -428,6 +428,7 @@
 #include <vector>
 #include <map>
 #include <algorithm>
+#include <memory>
 
 #include <ctype.h>
 #include <iostream>
