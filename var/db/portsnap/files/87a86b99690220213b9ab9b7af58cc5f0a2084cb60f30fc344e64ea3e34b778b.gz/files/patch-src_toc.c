--- src/toc.c.orig	2008-06-04 00:20:25.000000000 +0200
+++ src/toc.c	2008-06-04 00:20:36.000000000 +0200
@@ -19,6 +19,7 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
+#include <sys/types.h>
 
 #include "wavbreaker.h"
 #include "sample.h"
