--- lib/bigBuffer.h.orig	2013-10-11 01:12:58.000000000 +0400
+++ lib/bigBuffer.h	2013-10-11 01:13:02.000000000 +0400
@@ -26,6 +26,7 @@
 #include <unistd.h>
 
 #include <vector>
+#include <string>
 
 #include "types.h"
 
