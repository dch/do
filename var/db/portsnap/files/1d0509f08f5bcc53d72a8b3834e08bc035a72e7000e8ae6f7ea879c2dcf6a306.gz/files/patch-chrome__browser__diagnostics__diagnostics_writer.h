--- chrome/browser/diagnostics/diagnostics_writer.h.orig	2014-10-10 08:54:10 UTC
+++ chrome/browser/diagnostics/diagnostics_writer.h
@@ -18,7 +18,7 @@
  public:
   // The type of formatting done by this writer.
   enum FormatType {
-    MACHINE,
+    THEMACHINE,
     LOG,
     HUMAN
   };
