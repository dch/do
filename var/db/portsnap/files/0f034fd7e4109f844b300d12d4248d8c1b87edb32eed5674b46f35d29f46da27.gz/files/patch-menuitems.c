--- menuitems.c.orig
+++ menuitems.c
@@ -7,6 +7,7 @@
  * $Id: menuitems.c 2.6 2010/02/16 14:44:35 kls Exp $
  */
 
+#include <stdint.h>
 #include "menuitems.h"
 #include <ctype.h>
 #include <math.h>
