--- src/videooptions.cpp.orig	2015-03-27 02:53:21.432311000 +0300
+++ src/videooptions.cpp	2015-03-27 02:53:29.960147000 +0300
@@ -1,5 +1,6 @@
 #include <vector>
 #include <sstream>
+#include <algorithm>
 
 #include <SDL/SDL.h>
 
