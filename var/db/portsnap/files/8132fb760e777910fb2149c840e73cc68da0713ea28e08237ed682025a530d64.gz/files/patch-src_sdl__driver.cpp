--- src/sdl_driver.cpp.orig	2007-09-14 09:43:03.000000000 +0400
+++ src/sdl_driver.cpp	2015-03-27 02:55:29.588996000 +0300
@@ -5,6 +5,7 @@
 #include <SDL/SDL.h>
 #include <SDL/SDL_ttf.h>
 #include <cstdio>
+#include <cstdlib>
 
 #include "sdl_driver.h"
 #include "canvas.h"
