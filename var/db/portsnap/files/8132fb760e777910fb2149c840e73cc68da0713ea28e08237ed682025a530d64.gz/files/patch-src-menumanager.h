--- src/menumanager.h.orig	Thu Sep 20 22:01:32 2007
+++ src/menumanager.h	Thu Sep 20 21:58:13 2007
@@ -7,6 +7,8 @@
 #ifndef MENUMANAGER_H
 #define MENUMANAGER_H
 
+#include "ui/menuaction.h"
+
 class Main;
 
 class ControlOptions;
