--- src/lisp/parser.cpp.orig	2007-09-14 09:43:03.000000000 +0400
+++ src/lisp/parser.cpp	2015-03-27 02:51:42.723015000 +0300
@@ -20,6 +20,7 @@
 #include <sstream>
 #include <stdexcept>
 #include <fstream>
+#include <cstring>
 
 #include <cassert>
 
