--- src/lisp/lisp.cpp.orig	2007-09-14 09:43:03.000000000 +0400
+++ src/lisp/lisp.cpp	2015-03-27 02:52:43.801343000 +0300
@@ -17,6 +17,8 @@
 //  You should have received a copy of the GNU General Public License
 //  along with this program; if not, write to the Free Software
 //  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
+#include <cstdio>
+
 #include "lisp.hpp"
 
 namespace lisp
