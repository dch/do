--- include/mdds/flat_segment_tree.hpp.orig	2015-06-11 23:53:55 UTC
+++ include/mdds/flat_segment_tree.hpp
@@ -32,7 +32,6 @@
 #include <sstream>
 #include <utility>
 #include <cassert>
-#include <limits>
 
 #include "mdds/node.hpp"
 #include "mdds/flat_segment_tree_itr.hpp"
