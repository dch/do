--- src/Core/OOMaths.h.orig	2014-06-30 08:50:36 UTC
+++ src/Core/OOMaths.h
@@ -48,7 +48,8 @@
 #endif
 
 #include "OOFunctionAttributes.h"
-#include <tgmath.h>
+#include <complex.h>
+#include <math.h>
 #include <stdbool.h>
 #include <stdlib.h>
 #include <stdint.h>
