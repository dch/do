--- src/Core/OOPointMaths.h.orig	2014-06-30 08:50:36 UTC
+++ src/Core/OOPointMaths.h
@@ -1,5 +1,6 @@
 #import "OOFunctionAttributes.h"
-#include <tgmath.h>
+#include <complex.h>
+#include <math.h>
 
 
 // Utilities for working with NSPoints as 2D vectors.
