--- nn.h.orig	2014-01-03 20:28:26.000000000 +0000
+++ nn.h	2014-01-03 20:29:08.000000000 +0000
@@ -31,7 +31,6 @@
 #include <stdint.h>
 #include <stdlib.h>
 #include <limits.h>
-#include <malloc.h>
 
 #include "helper.h"
 #include "rand.h"
