--- rand/internal_rand.h.orig	2014-01-03 20:32:30.000000000 +0000
+++ rand/internal_rand.h	2014-01-03 20:32:40.000000000 +0000
@@ -30,7 +30,6 @@
 
 #include <stdint.h>
 #include <stdlib.h>
-#include <malloc.h>
 
 #include "helper.h"
 #include "rand.h"
