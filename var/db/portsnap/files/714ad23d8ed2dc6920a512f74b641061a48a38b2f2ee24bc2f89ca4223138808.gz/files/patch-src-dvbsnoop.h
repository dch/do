--- src/dvbsnoop.h.orig	2005-09-09 10:20:30.000000000 -0400
+++ src/dvbsnoop.h	2009-01-12 18:05:11.000000000 -0500
@@ -112,6 +112,7 @@
 #include <string.h>
 #include <time.h>
 #include <ctype.h>
+#include <sys/types.h>
 
 #include "version.h"
 #include "misc/helper.h"
