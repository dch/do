--- version.cc.orig	Sat Jun 16 08:25:50 2007
+++ version.cc	Mon Jul 23 20:03:44 2007
@@ -1,4 +1,4 @@
-//bin/true; VERSION="7.6.2"; return 0
+//usr/bin/true; VERSION="7.6.2"; return 0
 // Above magic is for configure to get version number
 // Generate automatically from scripts/versions.cc.src
 char	version[] = "7.6.2";
