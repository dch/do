--- version.c.orig	Fri Sep 27 00:03:57 1996
+++ version.c Tue Jul 17 03:50:48 2001
@@ -21,6 +21,6 @@
 
 
 char progname[] = "dbview";
-char longname[] = "View dBase III files";
+char longname[] = "View dbf files";
 
-char version[] = "1.0.2";
+char version[] = "1.0.3.1";
