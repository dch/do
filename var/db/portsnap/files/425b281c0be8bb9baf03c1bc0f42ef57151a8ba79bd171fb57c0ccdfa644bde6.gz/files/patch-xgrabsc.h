--- xgrabsc.h.orig	2014-09-09 19:24:54 UTC
+++ xgrabsc.h
@@ -43,6 +43,7 @@
 #include "cmdopts.h"
 
 #include <stdio.h>
+#include <stdlib.h>
 
 #include <X11/Xos.h>
 #include <X11/Xlib.h>
