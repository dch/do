--- thot/UIcss.c.orig	Sat Aug 21 17:34:06 2004
+++ ../thot/UIcss.c	Sat Aug 21 17:34:27 2004
@@ -1117,6 +1117,7 @@
 #ifdef DEBUG_CSS
 	    fprintf (stderr, "CSSCallbackHandle: undefined button value.\n");
 #endif
+            break;
 	  }
       break;
 
