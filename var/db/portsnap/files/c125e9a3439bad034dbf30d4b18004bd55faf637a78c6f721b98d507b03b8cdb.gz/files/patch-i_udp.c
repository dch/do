--- i_udp.c.old Sun Oct 20 22:21:11 2002
+++ i_udp.c     Sun Oct 20 22:21:26 2002
@@ -31,7 +31,7 @@
 
 boolean server = 0;
 
-static int DOOMPORT = (IPPORT_USERRESERVED +0x1d );
+static int DOOMPORT = (5000 +0x1d );
 
 /* static int sendsocket; */
 /* static int insocket; */
