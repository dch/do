--- opengl/gl_fonts.c	Sun Jan 30 05:58:21 2000
+++ opengl/gl_fonts.c.new	Sun Feb 13 03:54:46 2000
@@ -1,5 +1,5 @@
 #include <stdio.h>
-#include <malloc.h>
+#include <stdlib.h>
 #include <string.h>
 #include <math.h>
 
