--- sndserv/soundsrv.c	Mon Mar 22 20:06:59 1999
+++ sndserv/soundsrv.c.new	Sun Feb 13 03:54:46 2000
@@ -43,7 +43,7 @@
 #include <sys/ioctl.h>
 #include <unistd.h>
 #include <stdlib.h>
-#include <malloc.h>
+#include <stdlib.h>
 #include <sys/stat.h>
 #include <sys/time.h>
 
