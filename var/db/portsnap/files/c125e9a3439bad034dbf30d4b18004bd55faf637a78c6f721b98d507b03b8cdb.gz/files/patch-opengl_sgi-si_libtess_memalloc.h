--- opengl/sgi-si/libtess/memalloc.h	Wed Jan 26 05:30:44 2000
+++ opengl/sgi-si/libtess/memalloc.h.new	Sun Feb 13 03:54:46 2000
@@ -42,7 +42,7 @@
 #ifndef __memalloc_simple_h_
 #define __memalloc_simple_h_
 
-#include <malloc.h>
+#include <stdlib.h>
 
 #define memRealloc	realloc
 #define memFree		free
