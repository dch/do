--- opengl/gl_struct.h.orig	Wed Jan 26 14:38:19 2000
+++ opengl/gl_struct.h	Sun Apr  2 16:43:51 2000
@@ -2,7 +2,7 @@
 #define __GL_STRUCT_H__
 
 #include <stdio.h>
-#include <malloc.h>
+#include <stdlib.h>
 #include <string.h>
 #include <GL/gl.h>
 #include <GL/glu.h>
