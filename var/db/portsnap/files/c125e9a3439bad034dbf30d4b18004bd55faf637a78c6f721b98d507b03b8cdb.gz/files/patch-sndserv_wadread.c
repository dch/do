--- sndserv/wadread.c	Thu Nov 25 05:24:49 1999
+++ sndserv/wadread.c.new	Sun Feb 13 03:54:46 2000
@@ -39,7 +39,7 @@
  */
 
 
-#include <malloc.h>
+#include <stdlib.h>
 #include <fcntl.h>
 #include <sys/stat.h>
 #include <stdio.h>
