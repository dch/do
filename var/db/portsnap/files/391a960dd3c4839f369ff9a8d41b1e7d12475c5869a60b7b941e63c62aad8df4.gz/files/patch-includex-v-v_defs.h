--- includex/v/v_defs.h.orig	Mon Apr 28 19:16:56 2003
+++ includex/v/v_defs.h	Thu Mar  9 19:03:12 2006
@@ -310,6 +310,7 @@
 #define notChk 0
 #define noSub 0
 #define notUsed 0
+#define notUsedVoid
 #define noIcon 0
 
     // standard menu definitions
