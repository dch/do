--- /dev/null	Sat Apr 28 14:15:01 2007
+++ anna.h	Sat Apr 28 14:16:47 2007
@@ -0,0 +1 @@
+struct pidfh *pfh;
