--- ./src/libs/vorbis/config.h.orig	2014-06-05 06:18:39.000000000 +0200
+++ ./src/libs/vorbis/config.h	2014-08-07 16:49:53.700302995 +0200
@@ -14,7 +14,7 @@
 
 /* Define to 1 if you have <alloca.h> and it should be used (not on Ultrix).
    */
-#define HAVE_ALLOCA_H 1
+/* #define HAVE_ALLOCA_H 1 */
 
 /* Define to 1 if you have the <dlfcn.h> header file. */
 #define HAVE_DLFCN_H 1
