--- src/pmsg.c.orig	Sat Oct  7 16:41:35 2006
+++ src/pmsg.c	Sat Oct  7 16:42:28 2006
@@ -774,7 +774,7 @@
  **                       **
  ***************************/
 
-#ifdef FAKEXDRFLOAT
+#if 0
 
 /*
 ** These two are missing on some machines.
