--- src/common/atomic.h.orig	2009-03-29 20:43:39.000000000 +0200
+++ src/common/atomic.h	2009-08-22 11:21:38.000000000 +0200
@@ -38,7 +38,7 @@
 #define CONFIG_SMP   /* ... the macro the kernel headers use */
 #endif
 
-#if defined(__linux__) || defined(WIN32) || defined(__APPLE__)
+#if defined(__linux__) || defined(WIN32) || defined(__APPLE__) || defined(__FreeBSD__)
 #ifdef _ARCH_PPC
 
 /*
