--- Strategy.c.orig	Wed Oct 30 22:23:48 2002
+++ Strategy.c	Wed Oct 30 22:24:07 2002
@@ -95,8 +95,8 @@
 #include <Xol/OpenLook.h>
 #include <Xol/StaticText.h>
 #else
-#include <X11/Xm/Xm.h>
-#include <X11/Xm/Label.h>
+#include <Xm/Xm.h>
+#include <Xm/Label.h>
 #include "Table.h"
 #endif
 #include "Assert.h"
