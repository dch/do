--- Draw.c.orig	Wed Oct 30 22:16:05 2002
+++ Draw.c	Wed Oct 30 22:34:05 2002
@@ -84,7 +84,7 @@
 #include <Xol/OpenLook.h>
 #else
 #include <X11/Xutil.h>
-#include <X11/Xm/Xm.h>
+#include <Xm/Xm.h>
 #endif
 #include "Assert.h"
 #include "Bitmaps.h"
