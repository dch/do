--- units.c.orig	Fri Sep 22 12:06:46 1995
+++ units.c	Mon Dec 23 08:38:17 2002
@@ -2,6 +2,7 @@
 #include <sys/types.h>
 #include <sys/stat.h>
 #include <stdio.h>
+#include "host.h"
 #include "ansi.h"
 #include "files.h"
 #include "units.h"
