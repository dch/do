--- cdep.c.orig	Fri May 19 19:19:36 1995
+++ cdep.c	Mon Dec 23 08:38:17 2002
@@ -12,6 +12,7 @@
 #include "cpp.h"
 #include "cpp_hide.h"
 #include "allocate.h"
+#include "host.h"
 
 #undef NULL
 #define NULL			0
