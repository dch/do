--- ./src/backends/R/rserver/rcallbacks.cpp.orig	2011-09-06 18:09:37.488660147 +0200
+++ ./src/backends/R/rserver/rcallbacks.cpp	2011-09-06 18:11:08.508602174 +0200
@@ -18,6 +18,8 @@
     Copyright (C) 2009 Alexander Rieder <alexanderrieder@gmail.com>
  */
 
+#include <iostream>
+
 #include "rcallbacks.h"
 
 #include "rserver.h"
