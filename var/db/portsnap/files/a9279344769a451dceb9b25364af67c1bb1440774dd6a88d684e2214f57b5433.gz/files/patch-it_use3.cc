--- it_use3.cc.orig
+++ it_use3.cc
@@ -15,6 +15,7 @@
 #include "it_use3.h"
 
 #include <string.h>
+#include <stdlib.h>
 
 #include "externs.h"
 
