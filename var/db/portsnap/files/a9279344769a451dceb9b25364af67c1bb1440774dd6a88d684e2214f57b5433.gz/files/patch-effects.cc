--- effects.cc.orig
+++ effects.cc
@@ -13,6 +13,7 @@
 
 #include <string.h>
 #include <stdio.h>
+#include <stdlib.h>
 
 #include "externs.h"
 
