--- a/src/tcpsocketimpl.h
+++ b/src/tcpsocketimpl.h
@@ -36,6 +36,7 @@
 #include <string>
 #include <sys/types.h>
 #include <sys/socket.h>
+#include <netinet/in.h>
 #include <sys/poll.h>
 #include <sys/time.h>
 #include <unistd.h>
