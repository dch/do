*** xrobots.h.orig	Fri Nov 17 14:37:40 1989
--- xrobots.h	Mon Jan  2 22:47:56 1995
***************
*** 146,154 ****
  		game_active,
  		sonic_used;
  
- #define MIN(a,b) ((a<b)?a:b)
- #define MAX(a,b) ((a>b)?a:b)
- 
  #define INXRANGE( _x_ )  (((_x_) >=0) && ((_x_)<MAXX))
  #define INYRANGE( _y_ )  (((_y_) >=0) && ((_y_)<MAXY))
  
--- 146,151 ----
