--- ./greektranslit.cc.orig	2010-12-28 11:54:33.498725323 +0300
+++ ./greektranslit.cc	2010-12-28 11:54:44.774724956 +0300
@@ -1,4 +1,4 @@
-﻿/* This file is (c) 2010 Jennie Petoumenou <epetoumenou@gmail.com>
+/* This file is (c) 2010 Jennie Petoumenou <epetoumenou@gmail.com>
  * Part of GoldenDict. Licensed under GPLv3 or later, see the LICENSE file */
 
 #include "greektranslit.hh"
