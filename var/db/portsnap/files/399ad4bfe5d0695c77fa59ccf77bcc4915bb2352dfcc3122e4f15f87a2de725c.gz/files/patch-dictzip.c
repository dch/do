--- ./dictzip.c.orig	2010-12-04 00:12:46.000000000 +0300
+++ ./dictzip.c	2010-12-28 11:46:37.205720708 +0300
@@ -23,6 +23,7 @@
  */
 
 #include <stdlib.h>
+#include <time.h>
 #include "dictzip.h"
 #include <limits.h>
 #include <stdarg.h>
