--- ./bgl_babylon.cc.orig	2010-12-04 00:12:46.000000000 +0300
+++ ./bgl_babylon.cc	2010-12-28 11:46:37.203723541 +0300
@@ -26,6 +26,7 @@
 #include<stdlib.h>
 #include<string.h>
 #include<stdio.h>
+#include<unistd.h>
 #include<iconv.h>
 #include <QTextDocument>
 
