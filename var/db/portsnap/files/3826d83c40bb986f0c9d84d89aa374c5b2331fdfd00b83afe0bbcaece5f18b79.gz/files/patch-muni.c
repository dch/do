--- muni.c.orig	2011-09-05 14:46:18.000000000 +0800
+++ muni.c	2011-09-05 14:46:29.000000000 +0800
@@ -26,6 +26,7 @@
  *	muni 1.0
  */
 
+#include <ctype.h>
 #include <stdio.h>
 #include <stdlib.h>
 
