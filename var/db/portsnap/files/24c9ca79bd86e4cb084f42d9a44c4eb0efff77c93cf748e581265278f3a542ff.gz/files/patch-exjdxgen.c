--- exjdxgen.c.orig	1998-05-24 08:43:37.000000000 -0700
+++ exjdxgen.c	2008-03-06 11:39:23.000000000 -0800
@@ -22,7 +22,7 @@
 #include <sys/stat.h>
 
 #include <stdio.h>
-/*#include <stdlib.h>*/
+#include <stdlib.h>
 #include <ctype.h>
 #include <string.h>
 #include "xjdic.h"
