--- setup.py.orig	2013-07-23 03:39:16.157592949 +0800
+++ setup.py	2013-07-23 03:39:30.392145219 +0800
@@ -88,5 +88,4 @@
             "Topic :: Software Development :: Testing :: Traffic Generation",
             "Topic :: Internet :: WWW/HTTP",
         ],
-        install_requires=["pyasn1>0.1.2", "pyopenssl>=0.12"],
 )
