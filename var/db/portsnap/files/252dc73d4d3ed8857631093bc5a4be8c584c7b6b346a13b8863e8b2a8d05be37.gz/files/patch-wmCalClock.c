--- wmCalClock.c.orig	Wed May 21 03:34:04 2003
+++ wmCalClock.c	Wed May 21 03:34:07 2003
@@ -299,7 +299,7 @@
     int			i, n, wid, extrady, extradx;
     int 		Year, Month, DayOfWeek, DayOfMonth, OldDayOfMonth;
     int			Hours, Mins, Secs, OldSecs, digit, xoff, D[10], xsize;
-    long		CurrentLocalTime;
+    time_t		CurrentLocalTime;
     double		UT, TU, TU2, TU3, T0, gmst, jd(), hour24();
 
 
