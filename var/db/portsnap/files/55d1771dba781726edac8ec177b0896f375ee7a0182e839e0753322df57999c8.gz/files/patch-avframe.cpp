--- src/avframe.cpp.orig	2013-06-16 09:57:51 UTC
+++ src/avframe.cpp
@@ -22,6 +22,7 @@
 #include <QImage>
 #include <cstdlib>
 #include <cstdio>
+#include <types.h>
 #include "avframe.h"
 
 #ifdef HAVE_LIB_SWSCALE
