from distutils.core import setup

setup(
    name = 'urlimport',
    version = "%%PORTVERSION%%",
    py_modules = ['urlimport'],
    )
