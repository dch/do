--- src/ref_gl/gl_local.h.orig	2006-06-10 12:22:27.000000000 +0200
+++ src/ref_gl/gl_local.h	2012-04-25 06:13:42.000000000 +0200
@@ -30,6 +30,7 @@
 #include <GL/glext.h>
 
 #include <png.h>
+#include <zlib.h>
 #include <jpeglib.h>
 
 #include "../client/ref.h"
