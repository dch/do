--- defs.c.orig
+++ defs.c
@@ -26,6 +26,7 @@
 #endif
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <ctype.h>
 #include "euc.h"
 #include "cmt.h"
