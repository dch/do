--- ./g_local.h.orig	Mon Nov 30 17:41:21 1998
+++ ./g_local.h	Sun Dec 17 17:16:36 2006
@@ -439,11 +439,6 @@
 extern	int	sm_meat_index;
 extern	int	snd_fry;
 
-extern	int	jacket_armor_index;
-extern	int	combat_armor_index;
-extern	int	body_armor_index;
-
-
 // means of death
 #define MOD_UNKNOWN			0
 #define MOD_BLASTER			1
