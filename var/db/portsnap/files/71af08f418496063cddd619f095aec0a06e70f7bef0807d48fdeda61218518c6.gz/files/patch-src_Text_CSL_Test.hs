--- src/Text/CSL/Test.hs.orig	2015-03-17 10:32:38 UTC
+++ src/Text/CSL/Test.hs
@@ -29,7 +29,6 @@ import Data.List
 import Data.Maybe (isJust)
 import Data.Time
 import System.Directory
-import System.Locale
 
 import Text.ParserCombinators.Parsec
 
