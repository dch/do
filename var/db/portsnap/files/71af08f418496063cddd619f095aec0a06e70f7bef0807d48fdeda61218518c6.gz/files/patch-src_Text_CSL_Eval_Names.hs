--- src/Text/CSL/Eval/Names.hs.orig	2015-03-17 10:32:38 UTC
+++ src/Text/CSL/Eval/Names.hs
@@ -1,4 +1,4 @@
-{-# LANGUAGE PatternGuards #-}
+{-# LANGUAGE PatternGuards, FlexibleContexts #-}
 -----------------------------------------------------------------------------
 -- |
 -- Module      :  Text.CSL.Eval.Names
