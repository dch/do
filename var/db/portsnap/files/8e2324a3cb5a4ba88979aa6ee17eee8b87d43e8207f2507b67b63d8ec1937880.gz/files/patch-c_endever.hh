--- c_endever.hh.orig	Sun Feb 27 12:21:09 2000
+++ c_endever.hh	Sun Feb 27 12:21:27 2000
@@ -35,7 +35,7 @@
   bool nomove() const {return (nomoveflag);}
   void setnomove(bool nm) {nomoveflag = nm;}
   static void seticon(const char *str);
-  static geticon_len();
+  static int geticon_len();
 private:
   int torpedoes;
   bool docked;			// whether docked to a base
