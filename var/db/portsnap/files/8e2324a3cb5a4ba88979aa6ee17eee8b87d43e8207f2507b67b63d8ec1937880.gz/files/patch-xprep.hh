--- xprep.hh.orig	Sun Feb 27 12:22:21 2000
+++ xprep.hh	Sun Feb 27 12:27:25 2000
@@ -194,7 +194,7 @@
     sizeof(Boolean),
     XtOffsetOf(AppData, nomouse),
     XtRString,
-    "False"
+    (XtPointer) "False"
   },
   {
     XtNrows,
@@ -365,7 +365,7 @@
     sizeof(Pixel),
     XtOffsetOf(AppData, foreground),
     XtRString,
-    XtDefaultForeground
+    (XtPointer) XtDefaultForeground
   },
   {
     XtNbackground,
@@ -374,7 +374,7 @@
     sizeof(Pixel),
     XtOffsetOf(AppData, background),
     XtRString,
-    XtDefaultBackground
+    (XtPointer) XtDefaultBackground
   },
   {
     XtNendeverColor,
@@ -383,7 +383,7 @@
     sizeof(Pixel),
     XtOffsetOf(AppData, endever_color),
     XtRString,
-    XtDefaultForeground
+    (XtPointer) XtDefaultForeground
   },
   {
     XtNendeverIcon,
@@ -401,7 +401,7 @@
     sizeof(Pixel),
     XtOffsetOf(AppData, jovian_color),
     XtRString,
-    XtDefaultForeground
+    (XtPointer) XtDefaultForeground
   },
   {
     XtNjovianIcon,
@@ -419,7 +419,7 @@
     sizeof(Pixel),
     XtOffsetOf(AppData, base_color),
     XtRString,
-    XtDefaultForeground
+    (XtPointer) XtDefaultForeground
   },
   {
     XtNbaseIcon,
@@ -437,7 +437,7 @@
     sizeof(Pixel),
     XtOffsetOf(AppData, star_color),
     XtRString,
-    XtDefaultForeground
+    (XtPointer) XtDefaultForeground
   },
   {
     XtNstarIcon,
@@ -455,7 +455,7 @@
     sizeof(Pixel),
     XtOffsetOf(AppData, blackhole_color),
     XtRString,
-    XtDefaultForeground
+    (XtPointer) XtDefaultForeground
   },
   {
     XtNblackholeIcon,
@@ -473,7 +473,7 @@
     sizeof(Pixel),
     XtOffsetOf(AppData, faser_color),
     XtRString,
-    XtDefaultForeground
+    (XtPointer) XtDefaultForeground
   },
   {
     XtNfaserWidth,
@@ -518,7 +518,7 @@
     sizeof(Pixel),
     XtOffsetOf(AppData, torpedo_color),
     XtRString,
-    XtDefaultForeground
+    (XtPointer) XtDefaultForeground
   },
   {
     XtNtorpedoWidth,
@@ -554,7 +554,7 @@
     sizeof(Pixel),
     XtOffsetOf(AppData, explosion_color),
     XtRString,
-    XtDefaultForeground
+    (XtPointer) XtDefaultForeground
   },
   {
     XtNexplosionSpeed,
