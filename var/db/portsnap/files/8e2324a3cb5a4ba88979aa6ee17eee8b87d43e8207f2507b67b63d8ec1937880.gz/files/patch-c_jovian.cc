--- c_jovian.cc.orig	Fri Dec 29 01:41:56 1995
+++ c_jovian.cc	Sun Feb 27 12:30:41 2000
@@ -22,10 +22,12 @@
 
 // these AI functions are kept in separate file c_jovian_ai.cc
 
+#if 0
 extern Action Jovian::pick_action();
 extern Direction Jovian::pick_direction();
 extern Ucoors Jovian::pick_sector();
 extern Point Jovian::pick_target();
+#endif
 
 
 Jovian::Jovian(): Combatant()
