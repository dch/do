#!/bin/sh
cd %%DATADIR%%
exec ./HoH
