--- OpenTypeUtilities.cpp.orig	2009-04-30 09:18:46.000000000 +0000
+++ OpenTypeUtilities.cpp
@@ -27,6 +27,7 @@
 
 #include <string.h>
 #include <vector>
+#include <cstddef>
 
 #ifndef _MSC_VER
 # include <stdint.h>
