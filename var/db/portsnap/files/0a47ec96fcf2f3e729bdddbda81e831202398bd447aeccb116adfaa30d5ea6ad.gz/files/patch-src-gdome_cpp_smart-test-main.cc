--- src/gdome_cpp_smart/test/main.cc.orig	Thu Jul 17 11:35:05 2003
+++ src/gdome_cpp_smart/test/main.cc	Thu Jul 17 11:36:16 2003
@@ -21,6 +21,7 @@
  * or send an email to <luca.padovani@cs.unibo.it>
  */
 
+#include <assert.h>
 #include <config.h>
 
 #include <gdome.h>
