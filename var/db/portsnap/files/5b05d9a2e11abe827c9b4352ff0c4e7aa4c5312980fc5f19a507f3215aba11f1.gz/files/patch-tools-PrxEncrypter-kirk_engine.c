--- tools/PrxEncrypter/kirk_engine.c.orig	2012-01-25 22:10:31.000000000 +0000
+++ tools/PrxEncrypter/kirk_engine.c	2012-01-25 22:10:49.000000000 +0000
@@ -8,7 +8,6 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <time.h>
-#include <malloc.h>
 #include "types.h"
 #include "kirk_engine.h"
 #include "crypto.h"
