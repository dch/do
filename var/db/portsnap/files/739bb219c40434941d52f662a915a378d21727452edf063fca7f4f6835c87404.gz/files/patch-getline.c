--- getline.c.orig	Sun Jul 18 13:44:44 2004
+++ getline.c	Sun Jul 18 13:44:49 2004
@@ -9045,8 +9045,8 @@
       return 1;
   };
   return 0;
-}
 #endif
+}
 
 #if defined(HAVE_SELECT)
 /*.......................................................................
