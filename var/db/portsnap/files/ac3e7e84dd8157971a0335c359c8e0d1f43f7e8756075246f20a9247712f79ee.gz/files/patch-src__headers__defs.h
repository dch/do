--- ./src/headers/defs.h.orig	2014-05-22 07:10:57.000000000 -0600
+++ ./src/headers/defs.h	2014-07-13 15:24:45.559389869 -0600
@@ -98,7 +98,7 @@
 #endif
 
 #ifndef DEFAULTDIR		
-	#define DEFAULTDIR	"/var/ossec"
+	#define DEFAULTDIR	"/usr/local/ossec-hids"
 #endif
 
 
