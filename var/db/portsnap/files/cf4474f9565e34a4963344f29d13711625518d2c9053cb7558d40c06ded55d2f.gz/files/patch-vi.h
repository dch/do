--- vi.h.orig	Sun Oct 20 19:08:33 1991
+++ vi.h	Thu Aug 15 04:45:45 1996
@@ -101,7 +101,7 @@
 #define READONLY	0x0002	/* the file is read-only */
 #define HADNUL		0x0004	/* the file contained NUL characters */
 #define MODIFIED	0x0008	/* the file has been modified */
-#define NOFILE		0x0010	/* no name is known for the current text */
+#define NOFILENAME	0x0010	/* no name is known for the current text */
 #define ADDEDNL		0x0020	/* newlines were added to the file */
 
 /* macros used to set/clear/test flags */
