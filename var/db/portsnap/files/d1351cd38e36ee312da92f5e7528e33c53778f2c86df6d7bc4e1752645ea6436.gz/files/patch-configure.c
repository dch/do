--- configure.c.orig	Mon Jan  5 18:16:22 2004
+++ configure.c	Mon Jan  5 18:16:32 2004
@@ -30,7 +30,6 @@
 */
 
 #include <string.h>
-#include <malloc.h>
 #include <ctype.h>
 #include <getopt.h>
 #include <stdlib.h>
