--- main.cc.orig	1993-08-02 05:28:21.000000000 +0900
+++ main.cc	2014-01-22 10:40:54.000000000 +0900
@@ -14,7 +14,8 @@
 //  to the comments or the code of this program, but if reported
 //  to me then an attempt will be made to fix them.
 
-#include <iostream.h>
+#include <iostream>
+using namespace std;
 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
