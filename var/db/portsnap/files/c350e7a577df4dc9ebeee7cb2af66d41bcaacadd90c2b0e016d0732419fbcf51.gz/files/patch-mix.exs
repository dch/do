--- mix.exs.orig	2015-07-21 01:19:36 UTC
+++ mix.exs
@@ -6,8 +6,7 @@ defmodule KafkaEx.Mixfile do
      version: "0.1.0",
      elixir: "~> 1.0",
      description: description,
-     package: package,
-     deps: deps]
+     package: package]
   end
 
   def application do
