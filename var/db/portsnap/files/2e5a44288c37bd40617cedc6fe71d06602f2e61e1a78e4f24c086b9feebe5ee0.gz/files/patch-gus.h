--- gus.h.orig	Sat Oct 21 13:06:38 1995
+++ gus.h	Thu Aug 22 20:53:57 2002
@@ -41,7 +41,7 @@
 
 extern unsigned char _seqbuf[];
 extern int _seqbuflen, _seqbufptr;
-unsigned short base_freq_table[];
+unsigned short base_freq_table[16];
 extern unsigned int gus_total_mem;
 
 int gus_mem_free(int dev);
