--- main.h.orig	Sat Oct 21 15:56:32 1995
+++ main.h	Sat Jan 27 15:30:30 2001
@@ -43,7 +43,7 @@
 
 void help(void);
 void get_audio_device(void);
-void main(int argc, char **argv);
+int main(int argc, char **argv);
 
 
 #endif /* _MAIN_H */
