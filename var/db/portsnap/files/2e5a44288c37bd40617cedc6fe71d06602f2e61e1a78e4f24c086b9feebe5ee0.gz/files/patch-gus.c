--- gus.c.orig	Sat Oct 21 12:14:33 1995
+++ gus.c	Thu Aug 22 20:55:06 2002
@@ -26,7 +26,7 @@
 #ifdef GUS
 
 #include <sys/soundcard.h>
-#include <sys/ultrasound.h>
+#include <machine/ultrasound.h>
 #include <unistd.h>
 #include "gus.h"
 #include "mod.h"
