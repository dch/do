--- source/src/bot/bot_waypoint.cpp.orig	2013-11-10 18:50:03 UTC
+++ source/src/bot/bot_waypoint.cpp
@@ -848,7 +848,7 @@
 
      if (!pWP)
      {
-          conoutf("Error: Couldn�t find near waypoint");
+          conoutf("Error: Couldn't find near waypoint");
           return;
      }
 
