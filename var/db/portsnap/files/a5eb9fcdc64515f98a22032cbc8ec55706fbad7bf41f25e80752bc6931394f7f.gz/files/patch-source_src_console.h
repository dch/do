--- source/src/console.h.orig	2013-10-09 08:27:31 UTC
+++ source/src/console.h
@@ -127,7 +127,7 @@
     }
 };
 
-/** WIP ALERT */
+/** WIP ALERT *//*
 struct textinputbuffer_wip
 {
     string buf;
@@ -257,4 +257,4 @@
         return false;
     }
 };
-
+*/
