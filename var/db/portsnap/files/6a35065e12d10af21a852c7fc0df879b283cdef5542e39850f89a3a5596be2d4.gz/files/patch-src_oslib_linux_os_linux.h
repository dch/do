diff -ur src/oslib_linux/os_linux.h src/oslib_linux/os_linux.h
--- src/oslib_linux/os_linux.h	Wed May 16 01:39:05 2001
+++ src/oslib_linux/os_linux.h	Sun Jun 24 17:23:29 2001
@@ -5,7 +5,7 @@
 #define OS_EXIT_ERROR   10
 #define OS_EXIT_OK      0
 
-#define OS_PLATFORM_NAME "Linux"
+#define OS_PLATFORM_NAME "FreeBSD"
 #define OS_PATH_CHARS "/"
 #define OS_CURRENT_DIR "."
 
