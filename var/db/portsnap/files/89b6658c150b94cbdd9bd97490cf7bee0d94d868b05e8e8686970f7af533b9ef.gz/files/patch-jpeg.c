--- jpeg.c.orig
+++ jpeg.c
@@ -5,6 +5,7 @@
 
 #include <stdio.h>
 #include <stdlib.h>
+#include <string.h>
 #include <malloc.h>
 #include "jpeglib.h"
 #include <setjmp.h>
