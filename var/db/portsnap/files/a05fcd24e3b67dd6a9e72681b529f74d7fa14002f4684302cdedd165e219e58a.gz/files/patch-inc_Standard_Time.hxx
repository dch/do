--- inc/Standard_Time.hxx.orig	2013-04-18 17:20:16.000000000 +0200
+++ inc/Standard_Time.hxx	2013-05-09 14:46:25.000000000 +0200
@@ -34,10 +34,10 @@
 // ------------------------------------------------------------------
 // IsEqual : Returns Standard_True if two time values are equal
 // ------------------------------------------------------------------
-inline Standard_Boolean IsEqual (const Standard_Time theOne,
-                                 const Standard_Time theTwo)
-{
-  return theOne == theTwo;
-}
+//inline Standard_Boolean IsEqual (const Standard_Time theOne,
+//                                 const Standard_Time theTwo)
+//{
+//  return theOne == theTwo;
+//}
 
 #endif
