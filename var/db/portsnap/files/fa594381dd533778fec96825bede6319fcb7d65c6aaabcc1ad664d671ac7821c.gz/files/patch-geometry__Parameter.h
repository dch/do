--- ./geometry/Parameter.h.orig	2011-08-28 21:10:15.000000000 +0200
+++ ./geometry/Parameter.h	2014-01-26 19:15:00.000000000 +0100
@@ -21,6 +21,7 @@
 #define PARAMETER_H
 
 #include <vector>
+#include <stdlib.h>
 
 /// A container for numbers passed from the command line.
 namespace Vamos_Geometry
