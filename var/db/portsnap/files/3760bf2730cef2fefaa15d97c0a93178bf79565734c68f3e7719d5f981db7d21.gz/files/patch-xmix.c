--- xmix.c.orig	Wed Nov  1 10:29:04 2000
+++ xmix.c	Wed Nov  1 10:29:04 2000
@@ -77,7 +77,7 @@
 #include "square_empty.bit"
 #include "square_with_x.bit"
 
-#include <linux/soundcard.h>
+#include <sys/soundcard.h>
 
 #define SOUND_FULL_SCALE 100.0
 #define MAX_SOUND_VOL 95
