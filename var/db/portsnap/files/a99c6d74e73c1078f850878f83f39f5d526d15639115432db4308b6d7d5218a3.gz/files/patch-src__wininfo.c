--- src/wininfo.c.orig	Fri Jun 11 00:10:25 2004
+++ src/wininfo.c	Fri Jun 11 00:10:29 2004
@@ -23,7 +23,6 @@
  */
 
 #include <stdio.h>
-#include <stdint.h>
 #include <string.h>
 #include <gtk/gtk.h>
 #include <gdk/gdk.h>
