--- zx.h.orig	2011-07-25 03:56:45.000000000 +0800
+++ zx.h	2011-12-29 17:00:27.394555276 +0800
@@ -25,6 +25,7 @@
 #include <memory.h>
 #include <string.h>
 #include <stdarg.h>
+#include <limits.h>
 
 #ifdef USE_OPENSSL
 #include <openssl/x509.h>
