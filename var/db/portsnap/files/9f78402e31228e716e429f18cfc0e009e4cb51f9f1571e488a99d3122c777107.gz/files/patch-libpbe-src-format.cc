--- libpbe/src/format.cc.orig	2009-11-20 00:12:52.878597868 -0800
+++ libpbe/src/format.cc	2009-11-20 00:13:07.402710981 -0800
@@ -21,7 +21,7 @@
 #include <string>
 #include <cstdarg>
 #include <cstdio>
-#include <malloc.h>
+#include <stdlib.h>
 
 
 namespace pbe {
