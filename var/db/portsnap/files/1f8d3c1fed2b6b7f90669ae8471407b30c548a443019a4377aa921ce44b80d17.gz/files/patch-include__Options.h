--- ./include/Options.h.orig	2014-08-12 10:59:56.000000000 -0400
+++ ./include/Options.h	2014-08-12 11:00:09.000000000 -0400
@@ -33,6 +33,7 @@
 
 #include <string>
 #include <vector>
+#include <sys/types.h>
 
 using namespace std;
 
