--- ./bfd/bfd-in2.h.orig	2011-03-31 08:58:19.000000000 +0000
+++ ./bfd/bfd-in2.h	2012-01-25 22:24:29.000000000 +0000
@@ -1862,6 +1862,7 @@
 #define bfd_mach_mips_loongson_2f      3002
 #define bfd_mach_mips_loongson_3a      3003
 #define bfd_mach_mips_sb1              12310201 /* octal 'SB', 01 */
+#define bfd_mach_mips_allegrex         10111431 /* octal 'AL', 31 */
 #define bfd_mach_mips_octeon           6501
 #define bfd_mach_mips_xlr              887682   /* decimal 'XLR'  */
 #define bfd_mach_mipsisa32             32
