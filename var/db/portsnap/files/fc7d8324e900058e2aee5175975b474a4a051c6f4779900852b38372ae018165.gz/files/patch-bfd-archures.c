--- ./bfd/archures.c.orig	2011-03-22 18:10:41.000000000 +0000
+++ ./bfd/archures.c	2012-01-25 22:24:29.000000000 +0000
@@ -175,6 +175,7 @@
 .#define bfd_mach_mips_loongson_2f      3002
 .#define bfd_mach_mips_loongson_3a      3003
 .#define bfd_mach_mips_sb1              12310201 {* octal 'SB', 01 *}
+.#define bfd_mach_mips_allegrex         10111431 {* octal 'AL', 31 *}
 .#define bfd_mach_mips_octeon		6501
 .#define bfd_mach_mips_xlr              887682   {* decimal 'XLR'  *}
 .#define bfd_mach_mipsisa32             32
