--- src/pdeliver.c.orig	Mon Apr 30 14:20:34 2001
+++ src/pdeliver.c	Sat Dec 16 15:01:12 2006
@@ -33,7 +33,7 @@
 #include "popular.h"
 
 
-static int debug;
+int debug;
 
 
 /*****************************************************************************
