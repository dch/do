--- src/popular.h.orig	Thu Nov 28 14:56:03 2002
+++ src/popular.h	Mon Jul 11 16:19:50 2005
@@ -26,9 +26,7 @@
 
 *****************************************************************************/
 
-#include <alloca.h>
 #include <arpa/inet.h>
-#include <crypt.h>
 #include <ctype.h>
 #include <dirent.h>
 #include <dlfcn.h>
