--- ./src/util/debug.cpp.orig	2014-04-05 15:33:31.000000000 +0200
+++ ./src/util/debug.cpp	2014-04-05 15:34:06.000000000 +0200
@@ -20,6 +20,7 @@
  *      http://www.gnu.org/licenses 
  */
 
+#include <time.h>
 #include <QFile>
 
 #include "debug.h"
