--- action_item.h.orig	Mon May 12 14:36:48 2003
+++ action_item.h	Mon May 12 14:36:59 2003
@@ -18,7 +18,7 @@
 
 #include <X11/X.h>
 #define XK_MISCELLANY
-#include <X11/keysymdef.h>
+#include <X11/keysym.h>
 #include <X11/Xutil.h>
 
 enum action_type
