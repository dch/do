--- src/flow-header.c.orig	Mon Jul 26 13:21:36 2004
+++ src/flow-header.c	Mon Jul 26 13:21:45 2004
@@ -32,6 +32,7 @@
 
 #include <stdio.h>
 #include <stdlib.h>
+#include <unistd.h>
 
 void usage(void);
 
