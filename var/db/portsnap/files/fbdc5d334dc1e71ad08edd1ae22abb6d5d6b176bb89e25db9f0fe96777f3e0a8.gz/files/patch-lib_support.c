--- lib/support.c.orig	Wed Nov  8 03:50:31 2006
+++ lib/support.c	Wed Nov  8 03:51:27 2006
@@ -40,6 +40,7 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <syslog.h>
+#include <unistd.h>
 #include <time.h>
 #include <fcntl.h>
 
