--- xsysstats.c.orig	Sat Nov  9 08:44:11 2002
+++ xsysstats.c	Sat Nov  9 08:44:45 2002
@@ -1,5 +1,4 @@
 #include "xsysstats.h"
-#include "headers.h"
 #include "patchlevel.h"
 
 struct base_types {
