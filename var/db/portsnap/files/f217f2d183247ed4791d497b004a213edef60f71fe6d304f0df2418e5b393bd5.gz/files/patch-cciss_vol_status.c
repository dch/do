--- cciss_vol_status.c.orig	2010-10-01 11:01:29.000000000 +0400
+++ cciss_vol_status.c	2010-10-01 11:01:43.000000000 +0400
@@ -697,7 +697,7 @@
 			break;
 		case 1: sprintf(raid_level, "RAID 4");
 			break;
-		case 2: sprintf(raid_level, "RAID 1");
+		case 2: sprintf(raid_level, "RAID 1(1+0)");
 			break;
 		case 3: sprintf(raid_level, "RAID 5");
 			break;
