--- mkmfsed.c.orig      Tue May 28 00:00:00 2002
+++ mkmfsed.c   Tue Dec 27 14:51:35 2005
@@ -5,6 +5,7 @@
 */
 
 #include <stdio.h>
+#include <stdlib.h>
 #include "machine.h"
 		
 #ifdef NOVOID
