--- src/eibclient.c.orig	2007-12-29 22:23:06.000000000 +0100
+++ src/eibclient.c	2008-10-23 20:15:56.000000000 +0200
@@ -32,6 +32,7 @@
 #include <netinet/in.h>
 #include <netdb.h>
 #include <errno.h>
+#include <string.h>
 
 #include "config.h"
 
