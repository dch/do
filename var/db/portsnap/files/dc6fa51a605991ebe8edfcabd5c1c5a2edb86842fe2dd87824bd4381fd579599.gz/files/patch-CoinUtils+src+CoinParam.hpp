--- CoinUtils/src/CoinParam.hpp.orig	2009-08-16 22:33:13.000000000 -0500
+++ CoinUtils/src/CoinParam.hpp	2009-08-16 22:34:23.000000000 -0500
@@ -12,6 +12,7 @@
 
 #include <vector>
 #include <string>
+#include <cstdio>
 
 /*! \class CoinParam
     \brief A base class for `keyword value' command line parameters.
