--- lug/lugfnts.h.old	Sat Aug 18 13:33:46 2001
+++ lug/lugfnts.h	Sat Feb 12 16:30:29 2005
@@ -1057,13 +1057,6 @@
 );
 
 extern int
-isnumber(
-#ifdef USE_PROTOTYPES
-        char *
-#endif
-);
-
-extern int
 Uncompress(
 #ifdef USE_PROTOTYPES
         char *,
