--- portsentry.c.orig	Fri May 23 20:10:13 2003
+++ portsentry.c	Fri Oct  6 20:18:26 2006
@@ -1581,8 +1581,7 @@
 Usage (void)
 {
   printf ("PortSentry - Port Scan Detector.\n");
-  printf ("Copyright 1997-2003 Craig H. Rowland <craigrowland at users dot 
-sourceforget dot net>\n");
+  printf ("Copyright 1997-2003 Craig H. Rowland <craigrowland at users dot sourceforget dot net>\n");
   printf ("Licensing restrictions apply. Please see documentation\n");
   printf ("Version: %s\n\n", VERSION);
 #ifdef SUPPORT_STEALTH
