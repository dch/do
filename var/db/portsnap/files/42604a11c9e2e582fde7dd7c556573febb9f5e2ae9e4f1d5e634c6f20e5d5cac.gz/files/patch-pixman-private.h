--- pixman/pixman-private.h.orig	2014-06-12 21:43:22.000000000 +0000
+++ pixman/pixman-private.h	2014-06-12 21:43:38.000000000 +0000
@@ -1,5 +1,3 @@
-#include <float.h>
-
 #ifndef PIXMAN_PRIVATE_H
 #define PIXMAN_PRIVATE_H
 
@@ -30,6 +28,7 @@
 #include <stdio.h>
 #include <string.h>
 #include <stddef.h>
+#include <float.h>
 
 #include "pixman-compiler.h"
 
