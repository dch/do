--- src/server-main.C.orig	Wed Nov  2 09:54:12 2005
+++ src/server-main.C	Sun Dec 18 18:37:29 2005
@@ -20,7 +20,6 @@
  */
 
 
-#include <sys/mman.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <unistd.h>
