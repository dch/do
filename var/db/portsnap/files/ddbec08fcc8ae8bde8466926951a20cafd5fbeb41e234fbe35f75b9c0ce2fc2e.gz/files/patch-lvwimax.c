--- lvwimax.c.orig      2009-06-18 00:44:07.000000000 +0500
+++ lvwimax.c   2013-05-24 12:43:13.000000000 +0400
@@ -21,7 +21,7 @@

 #include <syslog.h>
 #include <stdlib.h>
-#include <libusb20.h>
+#include <libusb.h>
 #include <pthread.h>
 #include <poll.h>
 #include <errno.h>
