--- testport.cc.orig	2013-01-09 14:43:31.000000000 -0500
+++ testport.cc	2013-01-09 14:43:44.000000000 -0500
@@ -38,7 +38,6 @@
 #include <ctime>
 
 #include <sys/ioctl.h>
-#include <sys/io.h>
 #include <fcntl.h>
 #include <sys/time.h>
 #include <unistd.h>
