--- courier/cdmsgq.C.orig	2009-05-02 15:11:56 UTC
+++ courier/cdmsgq.C
@@ -38,6 +38,7 @@
 #include	<utime.h>
 #include	"numlib/numlib.h"
 
+#include	<functional>
 #include	<vector>
 #include	<list>
 #include	<algorithm>
