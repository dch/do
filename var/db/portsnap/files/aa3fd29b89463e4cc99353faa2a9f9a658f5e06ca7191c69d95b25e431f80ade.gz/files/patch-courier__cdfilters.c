--- courier/cdfilters.C.orig	2014-05-15 12:11:32.000000000 -0300
+++ courier/cdfilters.C	2014-05-15 12:11:44.000000000 -0300
@@ -13,6 +13,7 @@
 #include	<unistd.h>
 #endif
 #include	<stdlib.h>
+#include	<string.h>
 #include	<errno.h>
 #include	<ctype.h>
 
