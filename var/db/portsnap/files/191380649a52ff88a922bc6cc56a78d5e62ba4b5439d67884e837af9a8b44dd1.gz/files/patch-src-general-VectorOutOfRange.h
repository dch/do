--- src/general/VectorOutOfRange.h.orig	2013-12-20 23:16:13.000000000 +0800
+++ src/general/VectorOutOfRange.h	2013-12-20 23:16:37.000000000 +0800
@@ -5,6 +5,7 @@
  */
 #include <stdexcept>
 #include <exception>
+#include <string>
 namespace clustalw
 {
 
