--- xldlas.h.orig	Tue Jul  2 01:22:11 2002
+++ xldlas.h	Tue Jul  2 01:20:07 2002
@@ -51,8 +51,10 @@
 	change the numbers above to suit your tastes (and recompile!).
 */
 
+#ifndef TRUE
 #define TRUE		1			/* Standard Logic Testing		*/
 #define	FALSE		0			/* "			"		*/
+#endif
 #define TYPE_COLS	1			/* User supplied format for imports	*/
 #define TYPE_ROWS	2			/* "				  "	*/
 #define	TINY		1.0e-20			/* Need this to calculate Gamma function*/
