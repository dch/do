*** setstate.c.orig	Mon May 12 10:42:06 1997
--- setstate.c	Mon Apr 27 01:10:29 1998
***************
*** 509,515 ****
  	}
  	
  	if(found_label == FALSE)
! 		strcpy(help_location,"/usr/local/xldlas/help/");
  	strcpy(searcher,"test -r ");
  	strcat(searcher, help_location);
  	strcat(searcher,"general.help");
--- 509,515 ----
  	}
  	
  	if(found_label == FALSE)
! 		strcpy(help_location, PREFIX "/share/xldlas/help/");
  	strcpy(searcher,"test -r ");
  	strcat(searcher, help_location);
  	strcat(searcher,"general.help");
