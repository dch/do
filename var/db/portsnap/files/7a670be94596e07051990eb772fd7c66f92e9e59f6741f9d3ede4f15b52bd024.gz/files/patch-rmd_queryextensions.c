--- src/rmd_queryextensions.c.orig	2009-03-09 15:04:55.000000000 +0800
+++ src/rmd_queryextensions.c	2009-03-09 15:05:18.000000000 +0800
@@ -32,6 +32,7 @@
 #include <X11/extensions/shape.h>
 #include <X11/extensions/Xfixes.h>
 #include <X11/extensions/Xdamage.h>
+#include <stdlib.h>
 
 
 
