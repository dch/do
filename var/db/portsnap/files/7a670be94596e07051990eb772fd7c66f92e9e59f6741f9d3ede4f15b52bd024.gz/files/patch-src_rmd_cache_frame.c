--- src/rmd_cache_frame.c.orig	2009-03-09 14:58:04.000000000 +0800
+++ src/rmd_cache_frame.c	2009-03-09 14:58:51.000000000 +0800
@@ -34,6 +34,7 @@
 #include <signal.h>
 #include <string.h>
 #include <stdio.h>
+#include <stdlib.h>
 #include <errno.h>
 #include <math.h>
 
