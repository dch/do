--- src/rmd.c.orig	2009-03-09 14:56:13.000000000 +0800
+++ src/rmd.c	2009-03-09 14:56:52.000000000 +0800
@@ -43,6 +43,7 @@
 
 #include <stdio.h>
 #include <stdlib.h>
+#include <string.h>
 #include <errno.h>
 
 int main(int argc,char **argv){
