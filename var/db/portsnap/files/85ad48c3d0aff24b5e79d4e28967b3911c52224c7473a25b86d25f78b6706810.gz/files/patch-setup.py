--- setup.py.orig	2013-12-13 13:49:46.929425897 -0200
+++ setup.py	2013-12-13 13:49:58.999423613 -0200
@@ -154,7 +154,6 @@
                     'build_locale': build_locale,
                     'clean': clean,
                     'clean_locale': clean_locale,
-                    'install': install,
                     'install_locale': install_locale,
                     },
 
