--- gui/loadsave_frame.h.orig
+++ gui/loadsave_frame.h
@@ -11,6 +11,7 @@
 
 #include "savegame_frame.h"
 #include "../tpl/stringhashtable_tpl.h"
+#include <time.h>
 #include <string>
 
 class karte_t;
