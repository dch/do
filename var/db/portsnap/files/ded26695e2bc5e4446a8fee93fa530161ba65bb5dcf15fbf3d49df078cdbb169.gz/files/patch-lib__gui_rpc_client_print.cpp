--- ./lib/gui_rpc_client_print.cpp.orig	2013-07-24 15:13:29.000000000 +0000
+++ ./lib/gui_rpc_client_print.cpp	2013-09-17 21:43:21.000000000 +0000
@@ -31,6 +31,7 @@
 #include <sys/un.h>
 #include <cstdio>
 #include <unistd.h>
+#include <time.h>
 #include <cstdlib>
 #include <cstring>
 #endif
