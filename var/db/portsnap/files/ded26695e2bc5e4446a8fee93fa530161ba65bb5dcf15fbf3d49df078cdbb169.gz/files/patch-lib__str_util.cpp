--- ./lib/str_util.cpp.orig	2013-07-24 15:13:29.000000000 +0000
+++ ./lib/str_util.cpp	2013-09-17 21:45:40.000000000 +0000
@@ -29,6 +29,7 @@
 #include <string>
 #include <math.h>
 #include <string.h>
+#include <time.h>
 #include <stdlib.h>
 #include <ctype.h>
 #endif
