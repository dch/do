--- convert/rla.c.orig	Mon Jul 12 08:36:48 1993
+++ convert/rla.c	Wed Dec 27 18:18:42 2000
@@ -26,6 +26,7 @@
  *
  */
 
+#include <stdio.h>
 #include <lug.h>
 #include <lugfnts.h>
 
