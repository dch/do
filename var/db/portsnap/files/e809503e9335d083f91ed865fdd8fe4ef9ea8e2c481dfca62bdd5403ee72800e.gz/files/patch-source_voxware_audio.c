--- source/voxware_audio.c.orig	Sat Jun 28 15:55:41 2003
+++ source/voxware_audio.c	Sat Jun 28 15:56:08 2003
@@ -50,7 +50,7 @@
 #ifdef linux
 #include <linux/soundcard.h>
 #else
-#include <machine/soundcard.h>
+#include <sys/soundcard.h>
 #endif
 
 #include "argv.h"
