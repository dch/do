--- source/fbsd_joystick.c.orig	Sat Jun 28 15:55:30 2003
+++ source/fbsd_joystick.c	Sat Jun 28 15:56:01 2003
@@ -44,7 +44,7 @@
 #include <errno.h>
 #include <fcntl.h>
 #include <sys/time.h>
-#include <machine/joystick.h>
+#include <sys/joystick.h>
 
 #include "argv.h"
 #include "global.h"
