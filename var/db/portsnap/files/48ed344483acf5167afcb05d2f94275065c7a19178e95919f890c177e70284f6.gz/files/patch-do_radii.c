--- do_radii.c.orig	2010-09-01 11:05:44.971100153 +0200
+++ do_radii.c	2010-09-01 11:06:02.362650476 +0200
@@ -290,6 +290,7 @@ modification follow.
 
 */
 
+#include <string.h>
 
 #include "periodic.h"
 #include "info.h"
