--- raop_play/m4a_stream.c~	Thu Jul 28 04:43:17 2005
+++ raop_play/m4a_stream.c	Fri Aug 12 09:32:06 2005
@@ -20,7 +20,6 @@
 #include <stdio.h>
 #include <string.h>
 #include <unistd.h>
-#include <asm/types.h>
 #include <sys/types.h>
 #include <sys/stat.h>
 #include <fcntl.h>
