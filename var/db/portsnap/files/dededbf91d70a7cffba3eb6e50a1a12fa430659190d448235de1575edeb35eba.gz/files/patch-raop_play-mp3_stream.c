--- raop_play/mp3_stream.c~	Thu Jul 28 04:43:18 2005
+++ raop_play/mp3_stream.c	Fri Aug 12 09:47:58 2005
@@ -17,7 +17,7 @@
  * along with this program; if not, write to the Free Software
  * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
  *****************************************************************************/
-#include <asm/types.h>
+#include <sys/types.h>
 #include <stdio.h>
 #include <unistd.h>
 #include <sys/wait.h>
