--- raop_play/flac_stream.c~	Fri Dec 16 23:17:02 2005
+++ raop_play/flac_stream.c	Wed Jul  5 16:01:58 2006
@@ -18,7 +18,7 @@
  * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
  *****************************************************************************/
 #include <netinet/in.h>
-#include <asm/types.h>
+#include <sys/types.h>
 #include <stdio.h>
 #include <unistd.h>
 #include <sys/stat.h>
