--- raop_play/wav_stream.c~	Thu Jul 28 04:43:19 2005
+++ raop_play/wav_stream.c	Fri Aug 12 09:47:15 2005
@@ -17,7 +17,7 @@
  * along with this program; if not, write to the Free Software
  * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111, USA.
  *****************************************************************************/
-#include <asm/types.h>
+#include <sys/types.h>
 #include <stdio.h>
 #define WAV_STREAM_C
 #include "audio_stream.h"
