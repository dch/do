--- coda-src/venus/hdb.cc
+++ coda-src/venus/hdb.cc
@@ -58,7 +58,6 @@
 #include <stdlib.h>
 #include <pwd.h>
 #include <fcntl.h>
-#include <utmp.h>
 
 #include <codadir.h>
 
