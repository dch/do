--- src/qalc.cc.orig	Fri Jun  3 12:51:31 2005
+++ src/qalc.cc	Fri Jun  3 12:51:45 2005
@@ -16,7 +16,7 @@
 #include <time.h>
 #include <pthread.h>
 #include <dirent.h>
-#include <malloc.h>
+#include <stdlib.h>
 #include <stdio.h>
 #include <vector>
 #include <glib.h>
