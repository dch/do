--- spgrove/GroveBuilder.cxx.orig	Sun Nov 17 03:01:12 2002
+++ spgrove/GroveBuilder.cxx	Tue Aug  5 11:27:44 2003
@@ -4,26 +4,24 @@
 // FIXME location for SgmlDocument node.
 
 #include "config.h"
-#include "Boolean.h"
+#include <OpenSP/Boolean.h>
 #include "Node.h"
-#include "Resource.h"
-#include "Ptr.h"
-#include "xnew.h"
-#include "Event.h"
+#include <OpenSP/Resource.h>
+#include <OpenSP/Ptr.h>
+#include <OpenSP/xnew.h>
+#include <OpenSP/Event.h>
 #include "GroveBuilder.h"
-#include "ErrorCountEventHandler.h"
-#include "OutputCharStream.h"
-#include "MessageFormatter.h"
-#include "Dtd.h"
-#include "Syntax.h"
-#include "Attribute.h"
-#include "Vector.h"
+#include <OpenSP/ErrorCountEventHandler.h>
+#include <OpenSP/OutputCharStream.h>
+#include <OpenSP/MessageFormatter.h>
+#include <OpenSP/Dtd.h>
+#include <OpenSP/Syntax.h>
+#include <OpenSP/Attribute.h>
+#include <OpenSP/Vector.h>
 #include "LocNode.h"
 #include "SdNode.h"
 #include "threads.h"
-#include "macros.h"
-#include <assert.h>
-#include <stdio.h>
+#include <OpenSP/macros.h>
 
 #ifdef _MSC_VER
 #pragma warning ( disable : 4250 ) // inherits via dominance
