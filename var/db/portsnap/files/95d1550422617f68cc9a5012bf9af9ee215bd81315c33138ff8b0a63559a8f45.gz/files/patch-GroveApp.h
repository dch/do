--- spgrove/GroveApp.h.orig	Sun May  2 21:57:37 1999
+++ spgrove/GroveApp.h	Tue Aug  5 11:27:44 2003
@@ -7,9 +7,9 @@
 #pragma interface
 #endif
 
-#include "ParserApp.h"
+#include <OpenSP/ParserApp.h>
 #include "GroveBuilder.h"
-#include "HashTable.h"
+#include <OpenSP/HashTable.h>
 
 #ifdef SP_NAMESPACE
 namespace SP_NAMESPACE {
