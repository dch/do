--- src/commands.c.old	2010-05-28 12:54:19.000000000 +0200
+++ src/commands.c	2010-05-28 12:54:37.000000000 +0200
@@ -18,6 +18,7 @@
  * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
  */
 
+#include <stdlib.h>
 #include <stdio.h>
 #include <stdint.h>
 #include <string.h>
