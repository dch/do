--- xeyes+.c.orig	2012-09-11 09:39:46.000000000 +0200
+++ xeyes+.c	2012-09-11 09:40:06.000000000 +0200
@@ -111,7 +111,7 @@
 }
 
 
-void main(argc, argv)
+int main(argc, argv)
 int argc;
 char **argv;
 {
