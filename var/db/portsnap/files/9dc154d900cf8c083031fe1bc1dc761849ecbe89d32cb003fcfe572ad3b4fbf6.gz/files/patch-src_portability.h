--- src/portability.h.orig	2014-08-19 21:12:42.000000000 -0400
+++ src/portability.h	2014-08-19 21:12:51.000000000 -0400
@@ -42,6 +42,7 @@
 #include <stdio.h>
 #include <math.h>
 #include <stdint.h>
+#include <stdlib.h>
 #include <string>
 #include <cstring>
 
