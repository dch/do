--- gtksourceview/gtksourceregex.h.orig	2012-10-04 08:40:27.000000000 +0000
+++ gtksourceview/gtksourceregex.h	2012-10-04 08:40:34.000000000 +0000
@@ -20,7 +20,7 @@
 #ifndef __GTK_SOURCE_REGEX_H__
 #define __GTK_SOURCE_REGEX_H__
 
-#include <glib/gtypes.h>
+#include <glib.h>
 
 G_BEGIN_DECLS
 
