--- ETL/_surface.h.orig
+++ ETL/_surface.h
@@ -34,6 +34,7 @@
 #include "_misc.h"
 #include <algorithm>
 #include <cstring>
+#include <cstdlib>
 
 /* === M A C R O S ========================================================= */
 
