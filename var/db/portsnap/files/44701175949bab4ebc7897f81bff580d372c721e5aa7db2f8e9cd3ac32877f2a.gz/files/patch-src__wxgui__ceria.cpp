--- ./src/wxgui/ceria.cpp.orig	2011-06-04 02:19:33.000000000 +0200
+++ ./src/wxgui/ceria.cpp	2014-04-08 14:57:03.288600636 +0200
@@ -9,6 +9,7 @@
 #include <stdio.h>
 #include <ctype.h>
 #include <math.h>
+#include <stdlib.h>
 #include <assert.h>
 #include <string.h>
 #include <algorithm>
