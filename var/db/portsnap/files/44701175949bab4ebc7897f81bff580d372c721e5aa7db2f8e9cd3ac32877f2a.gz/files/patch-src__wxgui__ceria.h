--- src/wxgui/ceria.h.orig	2011-06-03 17:15:42 UTC
+++ src/wxgui/ceria.h
@@ -4,6 +4,7 @@
 #ifndef FITYK_WX_CERIA_H_
 #define FITYK_WX_CERIA_H_
 
+#include <stdio.h>
 #include <vector>
 #include <string>
 #include "atomtables.h"
