--- drivers/staging/echo/echo.c.orig	2012-08-29 15:54:31.000000000 +0700
+++ drivers/staging/echo/echo.c	2012-08-29 15:54:42.000000000 +0700
@@ -659,4 +659,3 @@
 MODULE_LICENSE("GPL");
 MODULE_AUTHOR("David Rowe");
 MODULE_DESCRIPTION("Open Source Line Echo Canceller");
-MODULE_VERSION("0.3.0");
