--- ./binding/ruby/test/run-test.sh.orig	2011-05-11 22:19:37.356427000 +0900
+++ ./binding/ruby/test/run-test.sh	2011-06-16 20:04:31.000000000 +0900
@@ -1,4 +1,4 @@
-#!/bin/bash
+#!/bin/sh
 #
 # Copyright (C) 2011  Kouhei Sutou <kou@clear-code.com>
 #
