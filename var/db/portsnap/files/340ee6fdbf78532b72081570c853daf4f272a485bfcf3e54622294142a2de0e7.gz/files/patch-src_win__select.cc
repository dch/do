--- src/win_select.cc.orig	Fri Apr 29 05:39:00 2005
+++ src/win_select.cc	Fri Apr 29 05:39:04 2005
@@ -12,9 +12,9 @@
    See the COPYING file for more details
 */
 
+#include "audio.h"
 #include "win_select.h"
 
-#include "audio.h"
 
 win_select::win_select()
 {
