--- src/map_event_handler.cc.orig	Fri Apr 29 05:30:43 2005
+++ src/map_event_handler.cc	Fri Apr 29 05:30:44 2005
@@ -19,9 +19,9 @@
  * @brief Implements the map_event_handler class.
  */
 
-#include <algorithm>
 #include "map_event.h"
 #include "map_event_handler.h"
+#include <algorithm>
 
 
 // See whether a matching event is registered and execute the
