--- xstrtol.h.orig	Sat Jul  2 23:18:21 2005
+++ xstrtol.h	Sat Jul  2 23:18:47 2005
@@ -1,3 +1,4 @@
+#include "dcfldd.h"
 #ifndef XSTRTOL_H_
 # define XSTRTOL_H_ 1
 
