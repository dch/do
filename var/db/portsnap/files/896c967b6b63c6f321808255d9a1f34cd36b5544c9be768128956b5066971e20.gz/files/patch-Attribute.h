--- Attribute.h.orig	Sat Aug 16 16:14:02 2003
+++ Attribute.h	Sat Aug 16 16:14:11 2003
@@ -21,6 +21,7 @@
 #ifndef ATTRIBUTE_H_
 #define ATTRIBUTE_H_
 
+#include <cassert>
 #include <string>
 #include <map>
 
