--- demo.c.orig
+++ demo.c
@@ -1,4 +1,5 @@
 #include <stdio.h>
+#include <stdlib.h>
 #include <X11/Xlib.h>
 #include "struct.h"
 
