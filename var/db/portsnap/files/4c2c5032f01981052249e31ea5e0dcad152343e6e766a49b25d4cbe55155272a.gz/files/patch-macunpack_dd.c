--- macunpack/dd.c.orig	Fri Apr 16 00:26:39 1999
+++ macunpack/dd.c	Fri Apr 16 00:26:45 1999
@@ -45,7 +45,7 @@
 #endif /* UNTESTED */
 static void dd_cpt_compat();
 
-typedef struct methodinfo {
+struct methodinfo {
 	char *name;
 	int number;
 };
