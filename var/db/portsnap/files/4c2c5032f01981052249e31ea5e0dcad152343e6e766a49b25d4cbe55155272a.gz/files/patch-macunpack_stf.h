--- macunpack/stf.h.orig	Fri Apr 16 00:22:12 1999
+++ macunpack/stf.h	Fri Apr 16 00:22:19 1999
@@ -5,7 +5,7 @@
 #define	S_RSRCLNGTH	3	/* + NAMELENGTH */
 #define	S_DATALNGTH	7	/* + NAMELENGTH */
 
-typedef struct fileHdr {
+struct fileHdr {
 	char		magic[3];
 	char		flength;
 	char		fname[32];	/* actually flength */
