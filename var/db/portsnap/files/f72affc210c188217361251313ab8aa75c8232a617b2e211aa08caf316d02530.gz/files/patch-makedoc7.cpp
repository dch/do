--- makedoc7.cpp.orig	Wed Mar 13 21:37:41 2002
+++ makedoc7.cpp	Wed Mar 13 21:39:39 2002
@@ -589,7 +589,7 @@
 		printf("\n       -n builds the .prc file without compression");
 		printf("\n       -b option compresses/decompresses binary");
 #if UNIX
-		printf("\n");
+		printf("\n\n");
 #endif
 		exit(1);
 	}
@@ -746,5 +746,6 @@
 		fclose(fin);
 		fclose(fout);
 	}
+	printf("\n");
 	exit(0);
 }
