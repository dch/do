--- charresize.c.orig	Fri Aug 23 16:24:22 2002
+++ charresize.c	Fri Aug 23 16:24:46 2002
@@ -46,7 +46,6 @@
 void
 processChar(void)
 {
-  char	*malloc();
   char	*srcimage;
   int	*dstgray;
 
