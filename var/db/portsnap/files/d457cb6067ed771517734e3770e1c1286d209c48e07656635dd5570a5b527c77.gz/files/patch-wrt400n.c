--- wrt400n.c.orig	2011-12-22 14:21:03 UTC
+++ wrt400n.c
@@ -11,6 +11,7 @@
 #include <stdio.h>
 #include <stdint.h>
 #include <string.h>
+#include <unistd.h>
 #include <sys/types.h>
 #include <sys/stat.h>
 
