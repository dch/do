--- src/zbuf/input.c.orig	2009-01-11 14:29:55.000000000 -0500
+++ src/zbuf/input.c	2011-03-31 11:40:20.000000000 -0400
@@ -32,6 +32,7 @@
 of this software.
 */
 
+#include <string.h>
 #include "mulGlobal.h"
 #include "zbufGlobal.h"
 
