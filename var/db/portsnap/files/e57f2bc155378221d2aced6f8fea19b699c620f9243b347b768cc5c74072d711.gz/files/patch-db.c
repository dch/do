--- db.c.orig	Sun Aug  8 10:58:13 1999
+++ db.c	Sun Aug  8 10:58:27 1999
@@ -19,7 +19,7 @@
 
 #include <stdio.h>
 #include <string.h>
-#include <malloc.h>
+#include <stdlib.h>
 #include "db.h"
 
 /* Definition of a record in linked list
