--- screens/nc_init.c.orig	Thu Jan 18 01:51:19 2001
+++ screens/nc_init.c	Fri Jan 26 05:28:47 2001
@@ -34,7 +34,6 @@
 #endif
 
 #include <stdio.h>
-#include <wchar.h>
 #include <stdlib.h>
 #include <signal.h>
 #include <unistd.h>
