--- screen.h.orig	Thu Jan 18 01:31:19 2001
+++ screen.h	Fri Jan 26 05:27:35 2001
@@ -2,7 +2,6 @@
 #   define _SCREEN_H
 
 #include "parse.h"
-#include <wchar.h>
 #include <stdio.h>
 
 void init_scr();
