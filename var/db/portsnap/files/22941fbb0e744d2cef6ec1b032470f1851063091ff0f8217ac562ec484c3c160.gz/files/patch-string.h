--- string.h.orig	Thu Jan 18 01:21:24 2001
+++ string.h	Fri Jan 26 05:36:32 2001
@@ -2,7 +2,6 @@
 #   define __STRING_H
 
 #include <ctype.h>
-#include <wchar.h>
 
 #define CR '\n'
 #define TAB '\t'
