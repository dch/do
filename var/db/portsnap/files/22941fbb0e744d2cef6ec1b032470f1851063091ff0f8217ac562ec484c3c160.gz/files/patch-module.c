--- module.c.orig	Mon Jan 17 19:56:45 2000
+++ module.c	Sat Jan  6 11:06:54 2001
@@ -25,7 +25,6 @@
 #include<stdlib.h>
 #include<pwd.h>
 #include<sys/types.h>
-#include<sys/resource.h> 
 #include<sys/wait.h>
 #include<sys/stat.h>
 #include<fcntl.h>
