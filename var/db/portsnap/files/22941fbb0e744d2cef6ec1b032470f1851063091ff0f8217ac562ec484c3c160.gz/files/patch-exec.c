--- exec.c.orig	Thu Jan 18 01:18:17 2001
+++ exec.c	Fri Jan 26 05:30:33 2001
@@ -38,7 +38,6 @@
 #include <ctype.h>
 #include <time.h>
 #include <errno.h>
-#include <wchar.h>
 
 #include "exec.h"
 #include "misc.h"
