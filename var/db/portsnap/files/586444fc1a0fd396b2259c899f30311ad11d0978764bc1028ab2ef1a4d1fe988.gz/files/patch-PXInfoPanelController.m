--- PXInfoPanelController.m.orig	2004-12-15 16:11:49.000000000 +0100
+++ PXInfoPanelController.m	2008-05-03 09:37:17.000000000 +0200
@@ -25,6 +25,7 @@
 #import <Foundation/NSUserDefaults.h>
 
 #import <AppKit/NSColor.h>
+#import <AppKit/NSGraphics.h>
 #import <AppKit/NSNibLoading.h>
 #import <AppKit/NSPanel.h>
 #import <AppKit/NSTextField.h>
