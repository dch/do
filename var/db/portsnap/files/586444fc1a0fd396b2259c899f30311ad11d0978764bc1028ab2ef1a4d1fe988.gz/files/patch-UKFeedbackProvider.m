--- UKFeedbackProvider.m.orig	2004-12-15 16:11:50.000000000 +0100
+++ UKFeedbackProvider.m	2012-02-19 07:59:17.000000000 +0100
@@ -7,7 +7,9 @@
 //
 
 #import "UKFeedbackProvider.h"
+#if 0
 #import <Message/NSMailDelivery.h>
+#endif
 
 
 @implementation UKFeedbackProvider
