--- vsort.h.orig	2014-08-15 12:06:55.000000000 -0400
+++ vsort.h	2014-08-15 12:07:03.000000000 -0400
@@ -28,7 +28,7 @@
  */
 
 #if !defined(__VSORT_H__)
-#define _VSORT_H__
+#define __VSORT_H__
 
 #include "bwstring.h"
 
