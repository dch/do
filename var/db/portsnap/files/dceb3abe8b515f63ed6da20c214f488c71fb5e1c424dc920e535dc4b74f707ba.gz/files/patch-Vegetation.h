--- src/components/ogre/terrain/foliage/Vegetation.h.orig	2014-03-11 22:15:45.000000000 +0100
+++ src/components/ogre/terrain/foliage/Vegetation.h	2014-03-11 22:16:03.000000000 +0100
@@ -9,6 +9,7 @@
 #define VEGETATION_H_
 
 #include "components/ogre/terrain/Types.h"
+#include <cstdlib>
 #include <map>
 
 namespace Ember
