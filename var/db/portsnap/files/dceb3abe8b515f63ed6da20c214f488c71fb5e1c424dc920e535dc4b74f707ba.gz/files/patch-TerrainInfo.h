--- src/components/ogre/terrain/TerrainInfo.h.orig	2009-02-13 18:06:16.000000000 +0100
+++ src/components/ogre/terrain/TerrainInfo.h	2009-02-13 18:06:43.000000000 +0100
@@ -26,6 +26,7 @@
 #include "../EmberOgrePrerequisites.h"
 // #include <wfmath/wfmath.h>
 #include <wfmath/axisbox.h>
+#include <wfmath/point.h>
 
 namespace Mercator
 {
