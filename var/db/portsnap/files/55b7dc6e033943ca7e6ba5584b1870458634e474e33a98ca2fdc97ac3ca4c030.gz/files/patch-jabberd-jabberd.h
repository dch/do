--- jabberd/jabberd.h.orig
+++ jabberd/jabberd.h
@@ -103,10 +103,10 @@
 #include <jabberdlib.h>
 #include <gnutls/gnutls.h>
 #include <gnutls/x509.h>
+#include <gnutls/openpgp.h>
 
 #ifdef HAVE_GNUTLS_EXTRA
 #  include <gnutls/extra.h>
-#  include <gnutls/openpgp.h>
 #endif
 
 /** Packet types */
