--- src/client/level.cc.orig	Tue Oct 21 16:48:11 2003
+++ src/client/level.cc	Tue Oct 21 16:48:25 2003
@@ -26,6 +26,7 @@
 #include <vector>
 #include <math.h>
 #include <algorithm>
+#include <cassert>
 #include "game.h"
 #include "level.h"
 #include "output.h"
