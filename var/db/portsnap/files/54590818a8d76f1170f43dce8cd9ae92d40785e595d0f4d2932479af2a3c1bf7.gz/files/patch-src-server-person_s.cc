--- src/server/person_s.cc.orig	Tue Oct 21 16:50:02 2003
+++ src/server/person_s.cc	Tue Oct 21 16:50:15 2003
@@ -1,4 +1,5 @@
 #include <algorithm>
+#include <cassert>
 #include <cstdlib>
 #include <sstream>
 #include <string>
