--- src/client/objects_c.cc.orig
+++ src/client/objects_c.cc
@@ -21,6 +21,7 @@
  */
 
 #include <cmath>
+#include <cstdlib>
 #include <string>
 #include "objects_c.h"
 #include "level.h"
