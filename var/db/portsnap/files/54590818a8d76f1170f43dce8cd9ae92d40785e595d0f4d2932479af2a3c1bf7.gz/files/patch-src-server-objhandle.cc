--- src/server/objhandle.cc.orig	Tue Oct 21 16:49:11 2003
+++ src/server/objhandle.cc	Tue Oct 21 16:49:32 2003
@@ -2,6 +2,7 @@
  * Copyright (c) 2002, Stefan Farfeleder <e0026813@stud3.tuwien.ac.at>
  * $Id: objhandle.cc,v 1.2 2002/09/19 10:42:02 stefan Exp $
  */
+#include <cassert>
 #include "object_s.h"
 #include "objhandle.h"
 
