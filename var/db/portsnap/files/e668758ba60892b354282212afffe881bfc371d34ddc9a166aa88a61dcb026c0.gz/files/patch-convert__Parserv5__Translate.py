--- ./convert/Parserv5/Translate.py.orig	Fri Dec 16 09:21:30 2005
+++ ./convert/Parserv5/Translate.py	Mon Jan  9 22:31:28 2006
@@ -19,8 +19,7 @@
 #
 # ======================================================================
 
-#!/bin/env python -d
-#!/tools/net/app/Python-1.5.2/bin/python1.5
+#!/usr/bin/env python -d
 
 """Translate - a first attempt at parsing my little language
 
