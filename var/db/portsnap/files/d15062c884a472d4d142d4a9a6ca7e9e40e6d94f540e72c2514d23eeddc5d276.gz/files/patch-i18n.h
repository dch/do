--- i18n.h.orig
+++ i18n.h
@@ -28,8 +28,8 @@
 #if (APIVERSNUM < 10507)
 #define trNOOP(a)  a
 #define trVDR  tr
-#endif
 
 extern const tI18nPhrase Phrases[];
+#endif
 
 #endif // VDR_OSDPIP_I18N_H
