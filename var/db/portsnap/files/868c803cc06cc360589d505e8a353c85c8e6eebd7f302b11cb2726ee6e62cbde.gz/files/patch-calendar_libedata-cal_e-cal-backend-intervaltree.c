--- calendar/libedata-cal/e-cal-backend-intervaltree.c.orig	2014-03-14 14:06:17.876564707 +0000
+++ calendar/libedata-cal/e-cal-backend-intervaltree.c	2014-03-14 14:05:42.004562353 +0000
@@ -36,6 +36,7 @@
 
 #include <stdio.h>
 #include <string.h>
+#include <stdlib.h>
 
 #include "e-cal-backend-intervaltree.h"
 
