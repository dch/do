--- FastMarching.cpp-orig	2015-02-20 03:51:59.000000000 +0000
+++ FastMarching.cpp	2015-02-20 03:52:16.000000000 +0000
@@ -22,6 +22,7 @@
 #include <cmath>
 #include <memory>
 #include <stdexcept>
+#include <string>
 
 namespace fastMarching
 {
