--- estic-1.61.orig/spunk/itemwin.h
+++ spunk/itemwin.h
@@ -54,7 +54,7 @@
 /*                             class WindowItem                              */
 /*****************************************************************************/
 
-
+class ItemWindow;
 
 class WindowItem : public Streamable {
 
