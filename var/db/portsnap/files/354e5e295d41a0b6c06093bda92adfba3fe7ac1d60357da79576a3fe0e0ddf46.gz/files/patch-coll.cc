--- spunk/coll.cc.orig	1996-11-30 00:40:58.000000000 +0100
+++ spunk/coll.cc	2014-11-14 08:11:36.000000000 +0100
@@ -21,7 +21,7 @@
 
 #include <stdlib.h>
 #include <string.h>
-#include <iostream.h>
+#include <iostream>
 
 #include "machine.h"
 #include "check.h"
