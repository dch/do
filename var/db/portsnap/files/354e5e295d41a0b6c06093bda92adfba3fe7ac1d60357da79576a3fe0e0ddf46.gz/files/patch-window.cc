--- spunk/window.cc.orig	Sat Feb 26 18:05:58 2000
+++ spunk/window.cc	Sat Feb 26 18:06:16 2000
@@ -1395,7 +1395,7 @@
 // Write a string to the inner window. Note: Attr is an index, not a real
 // attribute !
 {
-    const BufSize = 256;
+    const int BufSize = 256;
     u16 Buf [256];
 
     // Check if the given string is empty
@@ -1517,7 +1517,7 @@
 // Write a string to the inner window. Note: Attr is an index, not a real
 // attribute !
 {
-    const BufSize = 256;
+    const int BufSize = 256;
     u16 Buf [BufSize];
 
     // If the Y coord is outside the inner window, there is nothing to do
