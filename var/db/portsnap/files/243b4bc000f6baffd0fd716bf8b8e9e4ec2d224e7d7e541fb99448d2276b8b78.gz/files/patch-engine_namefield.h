--- engine/namefield.h.orig	Tue Sep 12 19:06:04 2006
+++ engine/namefield.h	Tue Sep 12 19:07:20 2006
@@ -31,6 +31,7 @@
 #include "../util/gltypes.h"
 #include "../util/gllist.h"
 #include "SDL_endian.h"
+#include "SDL_rwops.h"
 
 
 
