--- mix.exs.orig	2015-07-27 05:39:41 UTC
+++ mix.exs
@@ -7,7 +7,7 @@ defmodule Plug.Mixfile do
     [app: :plug,
      version: @version,
      elixir: "~> 1.0",
-     deps: deps,
+     deps: [],
      package: package,
      description: "A specification and conveniences for composable " <>
                   "modules in between web applications",
