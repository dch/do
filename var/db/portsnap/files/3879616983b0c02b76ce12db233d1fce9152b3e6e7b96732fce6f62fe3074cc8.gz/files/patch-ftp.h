--- ftp.h.orig	Thu Aug  1 18:27:55 2002
+++ ftp.h	Sat Oct 21 21:09:28 2006
@@ -25,6 +25,7 @@
 
 #include <errno.h>
 #include <netdb.h>
+#include <time.h>
 
 #include <netinet/in.h>
 #include <arpa/inet.h>
