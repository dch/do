--- ./include/QF/console.h.orig	Fri Jul 25 19:21:42 2003
+++ ./include/QF/console.h	Sun Dec 17 15:59:27 2006
@@ -141,6 +141,4 @@
 void Menu_Enter (void);
 void Menu_Leave (void);
 
-extern struct cvar_s *con_size;
-
 #endif // __console_h
