--- ./sample_client.C.orig	2014-02-21 11:34:06.215654443 +0100
+++ ./sample_client.C	2014-02-21 11:34:17.068652509 +0100
@@ -42,7 +42,7 @@
 #define LISTS 0
 
 
-main()
+int main()
 {
   // first, get a couple of boxes in which to put our models
 
