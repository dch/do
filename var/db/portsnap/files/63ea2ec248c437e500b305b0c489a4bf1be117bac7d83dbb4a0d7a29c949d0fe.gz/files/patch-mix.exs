--- mix.exs.orig	2015-07-08 12:15:58 UTC
+++ mix.exs
@@ -6,8 +6,7 @@ defmodule Joken.Mixfile do
      version: "0.14.1",
      elixir: "~> 1.0.0",
      description: description,
-     package: package,
-     deps: deps]
+     package: package]
   end
 
   def application do
