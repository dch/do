--- visprint.c.orig	Sat Nov 11 18:58:22 2006
+++ visprint.c	Sat Nov 11 18:58:25 2006
@@ -33,7 +33,6 @@
 #include <string.h>
 #include <fcntl.h>
 #include <png.h>
-#include <sys/io.h>
 
 #define MAX_RES            1000
 #define DEFAULT_RES        300
