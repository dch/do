--- dataxfer.h.orig	2014-12-28 21:17:23.000000000 +0200
+++ dataxfer.h	2014-12-28 21:17:53.000000000 +0200
@@ -20,7 +20,7 @@
 #ifndef DATAXFER
 #define DATAXFER
 
-#include <linux/serial.h>
+#include <sys/serial.h>
 
 #include "controller.h"
 
