--- src/message.c.orig	2007-09-30 18:30:42.000000000 -0300
+++ src/message.c	2008-02-18 23:32:17.000000000 -0300
@@ -202,7 +202,7 @@
 /*
  *  Function for creating the communication atoms.
  */
-void
+static void
 getAtoms (Display* d)
 {
   char* sem; /* semaphore property name */
