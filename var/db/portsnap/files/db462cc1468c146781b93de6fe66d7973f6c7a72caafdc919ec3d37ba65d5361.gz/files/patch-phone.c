*** phone.c.org	Sat Jan  9 22:25:15 1999
--- phone.c	Sat Jan  9 22:25:52 1999
***************
*** 7,13 ****
  
  #include <xview/xview.h>
  #include <xview/panel.h>
! #include <sys/dir.h>
  #include "defs.h"
  
  static Frame volume_frame;
--- 7,14 ----
  
  #include <xview/xview.h>
  #include <xview/panel.h>
! #include <sys/types.h>
! #include <sys/dirent.h>
  #include "defs.h"
  
  static Frame volume_frame;
