--- svg.c.orig	2009-09-23 21:50:37.000000000 +0900
+++ svg.c	2009-11-09 22:27:21.000000000 +0900
@@ -8,6 +8,7 @@
 #include <string.h>
 #include <math.h>
 #include <limits.h>
+#include <unistd.h>
 #include <sys/stat.h>
 #include <sys/wait.h>
 

