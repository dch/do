--- ./src/core/include/hydrogen/LashClient.h.orig	2014-06-19 06:38:04.000000000 +0930
+++ ./src/core/include/hydrogen/LashClient.h	2014-08-13 02:18:54.984463002 +0930
@@ -27,7 +27,7 @@
 #ifndef LASH_CLIENT
 #define LASH_CLIENT
 
-#include <lash-1.0/lash/lash.h>
+#include <lash/lash.h>
 
 #include <string>
 #include <cassert>
