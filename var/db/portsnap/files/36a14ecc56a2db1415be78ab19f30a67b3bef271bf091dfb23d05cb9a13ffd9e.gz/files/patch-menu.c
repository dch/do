--- ./menu.c.orig	Thu May 19 17:56:13 2005
+++ ./menu.c	Sun Feb 26 11:23:56 2006
@@ -587,6 +587,7 @@
 {
 {"+attack", 		"attack"},
 {"weapnext", 		"next weapon"},
+{"weapprev", 		"previous weapon"},
 {"+forward", 		"walk forward"},
 {"+back", 			"backpedal"},
 {"+left", 			"turn left"},
