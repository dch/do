--- file.cpp.orig	2013-10-06 17:12:46.000000000 +0400
+++ file.cpp	2013-10-06 17:13:27.000000000 +0400
@@ -12,6 +12,7 @@
  * Author: John Whitney <jjw@deltup.org>
  */
 
+#include <stdlib.h>
 #include <zlib.h>
 #include <bzlib.h>
 #include <string>
