*** play.c.orig	Wed May 20 11:42:42 1998
--- play.c	Wed May 20 13:21:15 1998
***************
*** 4,9 ****
--- 4,10 ----
  
  #include <stdio.h>
  #include <stdlib.h>
+ #include <unistd.h>
  #include <fcntl.h>
  #include <err.h>
  #include <signal.h>
