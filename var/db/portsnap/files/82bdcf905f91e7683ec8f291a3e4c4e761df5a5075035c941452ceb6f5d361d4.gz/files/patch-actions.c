--- actions.c.orig	Sat Sep  7 16:41:31 2002
+++ actions.c	Sat Sep  7 16:41:49 2002
@@ -32,7 +32,6 @@
 
 #include <stdio.h>					/* usual include stuff */
 #include <stdlib.h>
-#include <values.h>
 #include <string.h>
 #include <fcntl.h>
 #include <time.h>
