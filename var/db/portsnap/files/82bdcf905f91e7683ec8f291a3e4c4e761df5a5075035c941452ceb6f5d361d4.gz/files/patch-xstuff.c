--- xstuff.c.orig	Sat Sep  7 16:41:43 2002
+++ xstuff.c	Sat Sep  7 16:42:00 2002
@@ -28,7 +28,6 @@
 
 #include <stdio.h>
 #include <stdlib.h>
-#include <values.h>
 #include <string.h>
 #include <fcntl.h>
 #include <time.h>
