--- Utils/TimeConverter.h.orig	2013-04-24 14:28:21.000000000 +0200
+++ Utils/TimeConverter.h	2013-12-01 15:39:50.000000000 +0100
@@ -19,6 +19,7 @@
 #ifndef _TIME_CONVERTER_H
 #define _TIME_CONVERTER_H
 
+#include <time.h>
 #include <string>
 
 #include "Visibility.h"
