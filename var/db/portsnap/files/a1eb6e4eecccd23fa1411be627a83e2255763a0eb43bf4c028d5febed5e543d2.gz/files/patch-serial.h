--- serial.h.orig
+++ serial.h
@@ -1,7 +1,7 @@
 #ifndef _SERIAL_H
 #define _SERIAL_H
 
-#include "SDL/SDL.h"
+#include "SDL.h"
 
 class CSerial {
 
