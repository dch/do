--- interface.cpp.orig
+++ interface.cpp
@@ -10,7 +10,7 @@
 	(c) 2000, 2001 Attila Gr�sz
 */
 
-#include "SDL/SDL.h"
+#include "SDL.h"
 #include "tedmem.h"
 #include "interface.h"
 #include "archdep.h"
