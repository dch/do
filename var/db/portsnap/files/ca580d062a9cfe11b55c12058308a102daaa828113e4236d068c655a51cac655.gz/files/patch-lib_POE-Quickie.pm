--- lib/POE/Quickie.pm.orig	2011-05-25 14:44:40.000000000 +0900
+++ lib/POE/Quickie.pm	2011-06-14 12:00:27.000000000 +0900
@@ -604,6 +604,8 @@

 =item C<ARG2>: the context variable, if any

+=back
+
 =head2 ResultEvent

 =over 4
@@ -620,6 +622,8 @@

 =item C<ARG5>: the context variable, if any

+=over
+
 =back

 =back
