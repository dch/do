--- log.c.orig	Mon Nov 18 01:25:37 2002
+++ log.c	Mon Nov 18 01:25:43 2002
@@ -81,8 +81,8 @@
 extern char *initial_logfile_name;
 extern Display *display;
 extern int print_password_in_debug;
-extern int sys_nerr;
 #if !defined(__FreeBSD__) && !defined(__MACHTEN_PPC__)
+extern int sys_nerr;
 extern char *sys_errlist[];
 #endif
 
