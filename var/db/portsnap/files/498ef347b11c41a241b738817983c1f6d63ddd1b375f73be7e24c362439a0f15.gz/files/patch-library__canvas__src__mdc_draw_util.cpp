--- ./library/canvas/src/mdc_draw_util.cpp.orig	2014-08-26 12:45:54.802730992 -0400
+++ ./library/canvas/src/mdc_draw_util.cpp	2014-08-26 12:46:32.638126992 -0400
@@ -24,6 +24,7 @@
 #endif
 
 #include "mdc_draw_util.h"
+#include <cstdlib>
 
 using namespace base;
 
