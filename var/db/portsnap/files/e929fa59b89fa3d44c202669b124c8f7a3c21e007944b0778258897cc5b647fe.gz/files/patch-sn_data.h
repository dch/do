--- sn_data.h.orig	Tue Dec  4 10:16:59 2001
+++ sn_data.h	Tue Dec  4 10:20:02 2001
@@ -38,9 +38,9 @@
 char *NETDEV[]={"ppp","ed"};		
 int HEADSIZE[]={4    ,14}; 
 */
-#define NETDEV_NR      1
-char *NETDEV[]={"ed"};		
-int HEADSIZE[]={14}; 
+#define NETDEV_NR      6
+char *NETDEV[]={"fxp","de","ed","ppp","tun","lo"};
+int HEADSIZE[]={14   ,14  ,14  ,4    ,4    ,4   }; 
 #endif
 
 #ifdef BSDI				/* ppp: 4 or 0 ? */
