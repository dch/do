--- sn_resolv.c.orig	Thu Jul 16 09:17:10 1998
+++ sn_resolv.c	Sun Aug 16 23:25:58 1998
@@ -2,6 +2,8 @@
 /*  - getaddrbyname: Godmar Back / Shudoh Kazuyuki                       */
 
 #include "sn_defines.h"
+#include <sys/types.h>
+#include <netinet/in.h>
 #include <netdb.h>
 #include <arpa/inet.h>
 
