--- src/Network/XMPP/Stream.hs.orig	2012-08-30 21:44:36 UTC
+++ src/Network/XMPP/Stream.hs
@@ -1,3 +1,4 @@
+{-# LANGUAGE FlexibleContexts #-}
 -----------------------------------------------------------------------------
 -- |
 -- Module      :  Network.XMPP.Stream
