--- src/DLList.cc	Sun Apr  4 06:03:04 1999
+++ src/DLList.cc	Sat Oct 26 00:48:24 2002
@@ -21,7 +21,7 @@
 //#pragma implementation
 #endif
 #include <limits.h>
-#include <stream.h>
+//#include <stream>
 #include <stdio.h>
 #include <errno.h>
 //#include <builtin.h>
