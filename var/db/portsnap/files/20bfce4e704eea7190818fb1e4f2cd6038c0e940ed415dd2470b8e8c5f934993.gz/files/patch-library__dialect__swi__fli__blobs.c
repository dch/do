--- ./library/dialect/swi/fli/blobs.c.orig	2010-12-02 09:47:28.000000000 -0200
+++ ./library/dialect/swi/fli/blobs.c	2013-11-02 21:10:56.000000000 -0200
@@ -18,6 +18,7 @@
 #include	<Yap.h>
 #include	<Yatom.h>
 
+#include <stdio.h>
 #include <string.h>
 
 #include	<SWI-Prolog.h>
