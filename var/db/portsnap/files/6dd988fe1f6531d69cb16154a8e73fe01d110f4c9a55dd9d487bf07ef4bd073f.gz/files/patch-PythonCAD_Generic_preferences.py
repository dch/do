--- PythonCAD/Generic/preferences.py.orig	2010-07-25 18:10:27.707308605 +0200
+++ PythonCAD/Generic/preferences.py	2010-07-25 18:10:46.194466051 +0200
@@ -41,7 +41,7 @@
 # global variables
 #
 
-pref_file = '/etc/pythoncad/prefs.py'
+pref_file = '/usr/local/etc/pythoncad/prefs.py'
 
 #
 
