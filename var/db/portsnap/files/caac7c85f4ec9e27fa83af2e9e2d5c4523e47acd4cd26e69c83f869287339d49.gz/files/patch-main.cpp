--- main.cpp.orig	2013-09-19 22:25:36.000000000 +0400
+++ main.cpp	2013-09-19 22:26:10.000000000 +0400
@@ -19,6 +19,7 @@
  ***************************************************************************/
 
 #include <qapplication.h>
+#include <clocale>
 #include "mainwnd.h"
 
 int main(int argc, char **argv)
