--- aplay/formats.h~
+++ aplay/formats.h
@@ -1,7 +1,6 @@
 #ifndef FORMATS_H
 #define FORMATS_H		1
 
-#include <endian.h>
 #include <byteswap.h>
 
 /* Definitions for .VOC files */
