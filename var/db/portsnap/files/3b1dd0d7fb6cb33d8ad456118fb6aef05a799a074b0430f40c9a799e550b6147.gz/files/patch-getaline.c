diff -ur getaline.c getaline.c
--- getaline.c	Sun Dec  5 01:32:50 2004
+++ getaline.c	Sun Dec  5 01:33:24 2004
@@ -27,7 +27,7 @@
  *  THE POSSIBILITY OF SUCH DAMAGE.
  */
 #include <stdio.h>
-#include <malloc.h>
+#include <stdlib.h>
 
 #include "magicfilter.h"
 
