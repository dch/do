--- ./setup.py.orig	2014-03-03 07:52:24.000000000 +0000
+++ ./setup.py	2014-03-11 14:41:18.910777288 +0000
@@ -177,7 +177,6 @@
           'django-pipeline>=1.2.24,<1.3',
           'docutils',
           markdown_requirement,
-          'mimeparse>=0.1.3',
           'paramiko>=1.9.0',
           'Pygments>=1.5',
           'python-dateutil==1.5',
