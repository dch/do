--- tacpluslib/tac_plus.h
+++ tacpluslib/tac_plus.h
@@ -163,7 +163,6 @@
 #include <sys/syslog.h>
 #endif
 
-#include <utmp.h>
 
 #include <unistd.h>
 
