--- Preferences.cc.orig	2014-09-29 18:19:21 UTC
+++ Preferences.cc
@@ -29,6 +29,7 @@
 #include <map>
 #include <iostream>
 #include <fstream>
+#include <cstdlib>
 
 #include "Preferences.hh"
 
