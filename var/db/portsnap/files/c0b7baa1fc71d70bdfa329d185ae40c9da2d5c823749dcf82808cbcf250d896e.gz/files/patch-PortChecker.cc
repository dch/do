--- PortChecker.cc.orig	2014-09-29 18:19:21 UTC
+++ PortChecker.cc
@@ -31,6 +31,8 @@
 #include <string>
 #include <algorithm>
 #include <iostream>
+#include <cstdio>
+#include <cerrno>
 
 #include <QStringList>
 
