--- setup.py.orig	2010-08-20 15:32:51.000000000 +0200
+++ setup.py	2010-08-20 15:33:03.000000000 +0200
@@ -1,7 +1,7 @@
 from distutils.core import setup
 
 setup(
-    name='BlindElephant',
+    name='blindelephant',
     version='1.0',
     description='Uses static file fingerprinting to determine the version of web applications and plugins installed at a url', 
     author="Patrick Thomas",
@@ -17,4 +17,4 @@
         "Topic :: Internet :: WWW/HTTP"
         "Programming Language :: Python :: 2.6"
     ]
-)
\ No newline at end of file
+)
