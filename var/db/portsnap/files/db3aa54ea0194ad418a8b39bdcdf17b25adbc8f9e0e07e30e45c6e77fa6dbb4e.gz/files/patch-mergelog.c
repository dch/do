--- src/mergelog.c 2001-04-11 10:54:53.000000000 +0100
+++ src/mergelog.c 2010-09-22 11:11:12.000000000 +0100
@@ -35,7 +35,7 @@
 
 #define BUFFER_SIZE 32768
 #define DATE_SIZE 14
-#define SCAN_OFFSET 9
+#define SCAN_OFFSET 8
 #define SCAN_SIZE 512
 
