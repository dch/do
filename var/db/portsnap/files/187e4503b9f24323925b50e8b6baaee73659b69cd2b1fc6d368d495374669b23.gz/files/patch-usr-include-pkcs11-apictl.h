--- usr/include/pkcs11/apictl.h.orig	2010-07-29 21:28:41.000000000 +0900
+++ usr/include/pkcs11/apictl.h	2010-10-19 23:42:04.580983829 +0900
@@ -296,7 +296,7 @@
 
 
 #include <pkcs11types.h>
-#include <linux/limits.h>
+#include <limits.h>
 #include <local_types.h>
 #include <stdll.h>
 #include <slotmgr.h>
