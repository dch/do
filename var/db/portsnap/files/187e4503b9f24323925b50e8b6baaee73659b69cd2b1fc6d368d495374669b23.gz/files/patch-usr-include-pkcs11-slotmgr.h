--- usr/include/pkcs11/slotmgr.h.orig	2010-07-29 21:28:41.000000000 +0900
+++ usr/include/pkcs11/slotmgr.h	2010-10-19 23:42:55.423984058 +0900
@@ -301,7 +301,7 @@
 
 
 #include <pkcs11types.h>
-#include <linux/limits.h>
+#include <limits.h>
 #include <local_types.h>
 #include <pthread.h>
 
