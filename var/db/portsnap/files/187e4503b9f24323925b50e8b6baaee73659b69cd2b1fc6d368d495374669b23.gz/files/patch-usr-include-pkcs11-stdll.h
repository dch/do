--- usr/include/pkcs11/stdll.h.orig	2010-07-29 21:28:41.000000000 +0900
+++ usr/include/pkcs11/stdll.h	2010-10-19 23:43:40.418984281 +0900
@@ -302,7 +302,7 @@
 
 
 #include <pkcs11types.h>
-#include <linux/limits.h>
+#include <limits.h>
 #include <local_types.h>
 #include <slotmgr.h>
 
