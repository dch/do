--- usr/sbin/pkcsslotd/pkcsslotd.h.orig	2010-07-29 21:28:41.000000000 +0900
+++ usr/sbin/pkcsslotd/pkcsslotd.h	2010-10-20 01:20:18.253984238 +0900
@@ -353,7 +353,7 @@
 #include <nl_types.h>
 
 #include <sys/ipc.h>
-#include <linux/limits.h>
+#include <limits.h>
 #include <sys/shm.h>
 #include <sys/stat.h>
 #include <sys/types.h>
