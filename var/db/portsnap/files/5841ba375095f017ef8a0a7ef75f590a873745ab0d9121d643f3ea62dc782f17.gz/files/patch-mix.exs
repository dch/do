--- mix.exs.orig	2015-07-08 10:43:54 UTC
+++ mix.exs
@@ -9,8 +9,7 @@ defmodule UUID.Mixfile do
      homepage_url: "http://hexdocs.pm/uuid",
      elixir: "~> 1.0",
      description: description,
-     package: package,
-     deps: deps]
+     package: package]
   end
 
   # Application configuration.
