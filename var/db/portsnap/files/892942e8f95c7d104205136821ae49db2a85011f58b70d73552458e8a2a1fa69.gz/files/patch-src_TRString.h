--- src/TRString.h.orig	2012-08-15 13:55:46 UTC
+++ src/TRString.h
@@ -34,6 +34,7 @@
 #import <config.h>
 #endif
 
+#import <stdarg.h>
 #import <stdlib.h>
 
 #import "TRObject.h"
