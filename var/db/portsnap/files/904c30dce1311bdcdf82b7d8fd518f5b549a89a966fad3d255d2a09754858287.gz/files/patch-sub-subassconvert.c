--- sub/subassconvert.c.orig	2013-07-09 16:33:36 UTC
+++ sub/subassconvert.c
@@ -18,6 +18,7 @@
  * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
  */
 
+#include <ctype.h>
 #include <string.h>
 #include <stdint.h>
 #include <stdlib.h>
