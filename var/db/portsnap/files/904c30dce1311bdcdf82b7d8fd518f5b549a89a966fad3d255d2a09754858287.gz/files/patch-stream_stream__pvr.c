--- stream/stream_pvr.c.orig	2015-08-26 13:37:03 UTC
+++ stream/stream_pvr.c
@@ -37,7 +37,6 @@
 #include <fcntl.h>
 #include <inttypes.h>
 #include <poll.h>
-#include <linux/types.h>
 #include <linux/videodev2.h>
 
 #include "mp_msg.h"
