--- src/todoterm.cc.orig	2007-06-28 13:04:36 UTC
+++ src/todoterm.cc
@@ -5,6 +5,7 @@
 #include <iostream>
 #include <string>
 #include <stdexcept>
+#include <cstdlib>
 #include <curses.h>
 #include <term.h>
 
