--- src/VBox/GuestHost/OpenGL/include/state/cr_point.h.orig	2015-03-02 10:09:45.000000000 -0500
+++ src/VBox/GuestHost/OpenGL/include/state/cr_point.h	2015-03-02 19:21:08.518525000 -0500
@@ -4,8 +4,8 @@
  * See the file LICENSE.txt for information on redistributing this software.
  */
 
-#ifndef CR_STATE_LINE_H
-#define SR_STATE_LINE_H
+#ifndef CR_STATE_POINT_H
+#define CR_STATE_POINT_H
 
 #include "state/cr_statetypes.h"
 
@@ -59,4 +59,4 @@
 }
 #endif
 
-#endif /* CR_STATE_LINE_H */
+#endif /* CR_STATE_POINT_H */
