--- src/VBox/GuestHost/OpenGL/include/state/cr_line.h.orig	2015-03-02 10:09:45.000000000 -0500
+++ src/VBox/GuestHost/OpenGL/include/state/cr_line.h	2015-03-02 19:26:01.576169000 -0500
@@ -5,7 +5,7 @@
  */
 
 #ifndef CR_STATE_LINE_H
-#define SR_STATE_LINE_H
+#define CR_STATE_LINE_H
 
 #include "state/cr_statetypes.h"
 
