--- src/samplerate.h.orig	2013-11-23 23:36:11.000000000 +0100
+++ src/samplerate.h	2013-11-23 23:36:25.000000000 +0100
@@ -174,7 +174,7 @@
 	SRC_SINC_MEDIUM_QUALITY		= 1,
 	SRC_SINC_FASTEST			= 2,
 	SRC_ZERO_ORDER_HOLD			= 3,
-	SRC_LINEAR					= 4,
+	SRC_LINEAR					= 4
 } ;
 
 /*
