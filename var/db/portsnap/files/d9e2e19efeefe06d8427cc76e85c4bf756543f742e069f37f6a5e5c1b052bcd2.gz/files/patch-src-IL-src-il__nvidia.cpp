--- src-IL/src/il_nvidia.cpp.orig	2009-03-08 10:10:09.000000000 +0300
+++ src-IL/src/il_nvidia.cpp	2009-03-18 18:32:29.000000000 +0300
@@ -19,7 +19,6 @@
 
 #ifdef IL_USE_DXTC_NVIDIA
 #include <nvtt/nvtt.h>
-#include <nvcore/Memory.h>
 
 using namespace nvtt;
 
