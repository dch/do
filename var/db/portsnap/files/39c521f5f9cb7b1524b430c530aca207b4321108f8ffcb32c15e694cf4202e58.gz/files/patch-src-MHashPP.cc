--- src/MHashPP.cc.orig	Sun Sep 24 17:48:31 2006
+++ src/MHashPP.cc	Sun Sep 24 17:56:27 2006
@@ -21,6 +21,7 @@
 #include <cstdlib>
 #include <string>
 
+#define _Bool bool
 #include <mhash.h>
 
 #include "BitString.h"
