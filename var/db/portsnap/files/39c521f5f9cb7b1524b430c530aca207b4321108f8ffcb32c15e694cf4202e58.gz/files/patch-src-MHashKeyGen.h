--- src/MHashKeyGen.h.orig	Sun Sep 24 17:40:24 2006
+++ src/MHashKeyGen.h	Sun Sep 24 17:40:44 2006
@@ -23,6 +23,7 @@
 
 #include <vector>
 
+#define _Bool bool
 #include <mhash.h>
 
 class MHashKeyGen {
