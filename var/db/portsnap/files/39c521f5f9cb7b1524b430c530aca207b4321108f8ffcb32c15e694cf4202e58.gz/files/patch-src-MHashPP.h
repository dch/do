--- src/MHashPP..orig	Sun Sep 24 17:45:55 2006
+++ src/MHashPP.h	Sun Sep 24 17:46:10 2006
@@ -21,6 +21,7 @@
 #ifndef SH_MHASHPP_H
 #define SH_MHASHPP_H
 
+#define _Bool bool
 #include <mhash.h>
 
 #include "common.h"
