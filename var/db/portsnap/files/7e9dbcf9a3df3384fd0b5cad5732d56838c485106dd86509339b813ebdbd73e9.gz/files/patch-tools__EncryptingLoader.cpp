--- tools/EncryptingLoader.cpp.orig
+++ tools/EncryptingLoader.cpp
@@ -17,6 +17,8 @@
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
  ************************** * * * * * * * * * * * * **************************/
 
+#include <cstdlib>
+
 #include <QSqlError>
 
 #include "EncryptingLoader.h"
