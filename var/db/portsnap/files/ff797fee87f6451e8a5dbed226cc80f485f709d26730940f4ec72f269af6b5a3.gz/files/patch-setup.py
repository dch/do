--- setup.py.orig	2013-07-14 19:01:36.000000000 +0000
+++ setup.py	2013-07-14 19:02:02.000000000 +0000
@@ -31,7 +31,7 @@
     install_requires = [
         'setuptools',
         'PyCrypto',
-        'Twisted',
+        'Twisted_Core',
         'argparse',
         'pyptlib'
         ],
