--- lib/ContourMatching.cc.orig	2009-07-10 11:19:11.000000000 -0400
+++ lib/ContourMatching.cc	2009-07-10 11:20:05.000000000 -0400
@@ -1,6 +1,7 @@
 #include <cmath>
 #include <algorithm>
 #include <iostream>
+#include <stdio.h>
 
 #include "ContourMatching.hh"
 
