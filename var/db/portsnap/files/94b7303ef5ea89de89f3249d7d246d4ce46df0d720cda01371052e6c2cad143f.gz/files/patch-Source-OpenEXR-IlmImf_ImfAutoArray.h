--- Source/OpenEXR/IlmImf/ImfAutoArray.h.orig	2013-01-30 11:10:28.000000000 +0100
+++ Source/OpenEXR/IlmImf/ImfAutoArray.h	2013-01-30 12:05:10.000000000 +0100
@@ -46,6 +46,8 @@
 
 #include "OpenEXRConfig.h"
 
+#include <string.h>
+
 namespace Imf {
 
 
