--- Data/Certificate/X509/Cert.hs.orig	2013-10-07 02:22:00 UTC
+++ Data/Certificate/X509/Cert.hs
@@ -1,3 +1,4 @@
+{-# LANGUAGE FlexibleContexts #-}
 module Data.Certificate.X509.Cert
         (
         -- * Data Structure
