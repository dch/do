--- ./Config/prefs.rc.py.orig	2014-07-05 20:20:50.061669387 -0300
+++ ./Config/prefs.rc.py	2014-07-05 20:20:59.018078274 -0300
@@ -23,7 +23,7 @@
 # Frame test button on the Palette toolbar
 showFrameTestButton = False
 # Style flags used by most splitters in the IDE
-splitterStyle = wx.SP_LIVE_UPDATE | wx.SP_3DSASH | wx.NO_3D
+splitterStyle = wx.SP_LIVE_UPDATE | wx.SP_3DSASH
 
 # Alternating background colours used in ListCtrls (pastel blue and yellow)
 pastels = True
