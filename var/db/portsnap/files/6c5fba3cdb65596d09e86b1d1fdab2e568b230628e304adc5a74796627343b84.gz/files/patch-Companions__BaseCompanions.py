--- ./Companions/BaseCompanions.py.orig	2014-07-05 20:19:16.079675572 -0300
+++ ./Companions/BaseCompanions.py	2014-07-05 20:19:24.740675001 -0300
@@ -851,7 +851,7 @@
         self.windowStyles = ['wx.CAPTION', 'wx.MINIMIZE_BOX', 'wx.MAXIMIZE_BOX',
             'wx.THICK_FRAME', 'wx.SIMPLE_BORDER', 'wx.DOUBLE_BORDER',
             'wx.SUNKEN_BORDER', 'wx.RAISED_BORDER', 'wx.STATIC_BORDER', 
-            'wx.TRANSPARENT_WINDOW', 'wx.NO_3D', 'wx.TAB_TRAVERSAL', 
+            'wx.TRANSPARENT_WINDOW', 'wx.TAB_TRAVERSAL', 
             'wx.WANTS_CHARS', 'wx.NO_FULL_REPAINT_ON_RESIZE', 'wx.VSCROLL', 
             'wx.HSCROLL', 'wx.CLIP_CHILDREN', 'wx.NO_BORDER', 'wx.ALWAYS_SHOW_SB']
         
