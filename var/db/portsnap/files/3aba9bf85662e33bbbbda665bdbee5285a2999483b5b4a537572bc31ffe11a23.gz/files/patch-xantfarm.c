--- xantfarm.c.orig	Mon May 31 08:57:49 1999
+++ xantfarm.c	Mon May 31 08:58:33 1999
@@ -113,7 +113,7 @@
 extern char* malloc();
 extern long random();
 extern char* realloc();
-extern long time();
+extern time_t time();
 
 
 /* Forward routines. */
