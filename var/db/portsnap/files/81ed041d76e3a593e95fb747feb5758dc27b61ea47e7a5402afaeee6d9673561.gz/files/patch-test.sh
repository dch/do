--- test.sh	Mon Jan  7 22:05:20 2002
+++ ./test.sh	Sun Sep 12 00:42:56 2004
@@ -1,4 +1,4 @@
-#!/bin/bash
+#!/bin/sh
 
 testit () {
 	echo "TEST: Running 'atitvout $FLAG $1' ..."
