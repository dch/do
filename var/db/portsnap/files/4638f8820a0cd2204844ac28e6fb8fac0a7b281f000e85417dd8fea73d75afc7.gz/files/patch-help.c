--- help.c.orig	2002-04-04 05:46:11.000000000 +0200
+++ help.c	2013-11-05 16:44:41.000000000 +0100
@@ -19,6 +19,7 @@ Foundation, Inc., 59 Temple Place - Suit
 */
 #include <stdio.h>
 #include <stdlib.h>
+#include <string.h>
 #include <gtk/gtk.h>
 
 #include "help.h"
