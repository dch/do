--- complex.c.orig	2002-04-04 05:46:10.000000000 +0200
+++ complex.c	2013-11-05 16:40:36.000000000 +0100
@@ -21,6 +21,7 @@ Foundation, Inc., 59 Temple Place - Suit
 
 #include <stdio.h>
 #include <stdlib.h>
+#include <string.h>
 #include <math.h>
 
 #include "complex.h"
