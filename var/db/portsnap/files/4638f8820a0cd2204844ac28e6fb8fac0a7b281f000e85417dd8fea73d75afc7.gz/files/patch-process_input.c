--- process_input.c.orig	2002-04-04 05:46:11.000000000 +0200
+++ process_input.c	2013-11-05 16:43:55.000000000 +0100
@@ -20,6 +20,7 @@ Foundation, Inc., 59 Temple Place - Suit
 /* process_input.c  by Paul Wilkins 3/21/97 */
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <gtk/gtk.h>
 #include <gdk/gdkkeysyms.h>
 
