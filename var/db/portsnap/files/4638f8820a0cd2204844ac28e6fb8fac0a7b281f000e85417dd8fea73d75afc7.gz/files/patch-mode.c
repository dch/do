--- mode.c.orig	2002-04-04 05:46:11.000000000 +0200
+++ mode.c	2013-11-05 16:44:30.000000000 +0100
@@ -20,6 +20,7 @@ Foundation, Inc., 59 Temple Place - Suit
 /* setup mode.c  by Paul Wilkins  2/8/98 */
 
 #include <stdio.h>
+#include <string.h>
 #include <gtk/gtk.h>
 
 #include "mode.h"
