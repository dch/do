--- run_cmd.c.orig	2002-04-04 05:46:11.000000000 +0200
+++ run_cmd.c	2013-11-05 16:41:30.000000000 +0100
@@ -20,6 +20,7 @@ Foundation, Inc., 59 Temple Place - Suit
 /* run_cmd.c  by Paul Wilkins */
 
 #include <stdio.h>
+#include <string.h>
 #include <gtk/gtk.h>
 
 #include "buttons.h"
