--- main.c.orig	2002-04-04 05:46:11.000000000 +0200
+++ main.c	2013-11-05 16:42:00.000000000 +0100
@@ -23,6 +23,7 @@ Foundation, Inc., 59 Temple Place - Suit
  */
 
 #include <stdio.h>
+#include <stdlib.h>
 #ifdef USE_GNOME
 #include <gnome.h>
 #endif
