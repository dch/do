--- subcommander/WcViewWhatsThis.cpp.orig	2009-01-03 02:33:10.000000000 +0900
+++ subcommander/WcViewWhatsThis.cpp	2012-05-10 05:48:12.000000000 +0900
@@ -162,7 +162,7 @@
       "</tr>"
       "<tr>";
   ws += "<td></td>"
-        "<td></td><td>not modified</td><td></td>" "<td>*</td><td>modified</td><td></td>";
+        "<td></td><td>not modified</td><td></td>" "<td>*</td><td>modified</td><td></td>"
       "</tr>"
      "</table>"
     "</qt>";
