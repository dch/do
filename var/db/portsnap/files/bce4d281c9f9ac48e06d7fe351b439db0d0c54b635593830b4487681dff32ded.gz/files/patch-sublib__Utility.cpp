--- sublib/Utility.cpp.orig	2009-09-20 18:10:18.000000000 +0900
+++ sublib/Utility.cpp	2012-05-10 05:31:52.000000000 +0900
@@ -27,6 +27,7 @@
 #endif // _WIN32
 
 // sys
+#include <cstdlib>
 #include <locale.h>
 
 
