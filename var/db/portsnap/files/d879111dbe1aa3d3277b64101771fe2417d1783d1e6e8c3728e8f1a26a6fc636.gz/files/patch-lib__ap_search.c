--- ./lib/ap_search.c.orig	2004-05-04 15:18:09.000000000 +0000
+++ ./lib/ap_search.c	2014-05-30 08:01:14.000000000 +0000
@@ -34,6 +34,7 @@
 #include <sys/socket.h>
 #endif
 
+#include <sys/socket.h>
 #include <net/if.h>
 #include <sys/time.h>
 #include <errno.h>
