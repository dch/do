--- amqp.h.orig	2010-09-07 22:27:12.427343614 -0400
+++ amqp.h	2010-09-07 22:27:29.186292928 -0400
@@ -1,3 +1,4 @@
+#include <sys/types.h>
 #ifndef librabbitmq_amqp_h
 #define librabbitmq_amqp_h
 
