--- src/FileTools.cpp.orig	2007-11-25 12:28:07.000000000 +0300
+++ src/FileTools.cpp	2013-09-17 06:11:17.036227572 +0400
@@ -45,6 +45,8 @@
 #include <dirent.h>
 #include <limits.h>
 #include <iostream>
+#include <cstdlib>
+#include <cstring>
 
 /* ========================================================================== *
  * FileTools - Implementation
