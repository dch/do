--- libpalm/Block.h.orig	Mon Dec 25 16:02:34 2006
+++ libpalm/Block.h	Mon Dec 25 16:02:56 2006
@@ -176,7 +176,7 @@
 	size_type m_size;
     };
 
-};
+}
 
 bool operator == (const PalmLib::Block& lhs, const PalmLib::Block& rhs);
 
