--- libpalm/File.h.orig	Mon Dec 25 16:02:24 2006
+++ libpalm/File.h	Mon Dec 25 16:02:30 2006
@@ -89,6 +89,6 @@
 	uid_map_t m_uid_map;
     };
 
-};
+}
 
 #endif
