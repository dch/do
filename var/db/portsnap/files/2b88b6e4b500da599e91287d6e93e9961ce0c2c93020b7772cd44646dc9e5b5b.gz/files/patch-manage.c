--- ./manage.c.orig	2011-06-24 15:13:24.000000000 +0200
+++ ./manage.c	2011-06-24 15:13:59.000000000 +0200
@@ -10,6 +10,7 @@
 
 #include <stdio.h>
 #include <stdlib.h>
+#include <string.h>
 
 #include "antiwm.h"
 
