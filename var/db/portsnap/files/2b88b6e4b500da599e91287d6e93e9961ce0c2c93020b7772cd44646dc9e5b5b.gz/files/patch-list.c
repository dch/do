--- ./list.c.orig	2011-06-24 15:14:48.000000000 +0200
+++ ./list.c	2011-06-24 15:15:27.000000000 +0200
@@ -4,6 +4,7 @@
 
 #include <stdio.h>
 #include <stdlib.h>
+#include <string.h>
 
 #include "antiwm.h"
 
