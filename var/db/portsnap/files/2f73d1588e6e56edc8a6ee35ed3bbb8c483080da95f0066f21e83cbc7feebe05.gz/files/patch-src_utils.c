--- src/utils.c.orig	Sun Jun  9 13:13:57 2002
+++ src/utils.c	Sun Jun  9 13:14:22 2002
@@ -66,7 +66,7 @@
 #define _IOSTRG 0
 #endif
 
-extern int sys_nerr;
+// extern int sys_nerr;
 
 struct id
   {
