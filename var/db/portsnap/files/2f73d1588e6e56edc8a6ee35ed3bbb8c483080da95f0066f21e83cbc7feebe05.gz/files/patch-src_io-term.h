--- src/io-term.h.orig	2008-02-08 16:38:59.000000000 +0100
+++ src/io-term.h	2008-02-08 16:38:48.000000000 +0100
@@ -21,6 +21,7 @@
  */
 
 #include <setjmp.h>
+#include "funcs.h"
 #include "global.h"
 
 extern int using_x;
