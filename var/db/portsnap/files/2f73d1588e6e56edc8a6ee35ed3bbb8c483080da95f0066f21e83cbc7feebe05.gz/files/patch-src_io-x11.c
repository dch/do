--- src/io-x11.c.orig	Wed Jul 14 23:14:24 2004
+++ src/io-x11.c	Wed Jul 14 23:14:28 2004
@@ -34,7 +34,6 @@
 #include <stdio.h>
 #include <ctype.h>
 #include <sys/param.h>
-#define NeedFunctionPrototypes 0
 #include <X11/X.h>
 #include <X11/Xlib.h>
 #include <X11/Xutil.h>
