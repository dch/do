--- src/include/xdtp.h.orig	2013-10-06 03:58:31.000000000 +0900
+++ src/include/xdtp.h	2013-10-06 03:58:44.000000000 +0900
@@ -40,6 +40,7 @@
 #include <string.h>
 #include <locale.h>
 #include <errno.h>
+#include <unistd.h>
 
 #include "xdtptypes.h"
 
