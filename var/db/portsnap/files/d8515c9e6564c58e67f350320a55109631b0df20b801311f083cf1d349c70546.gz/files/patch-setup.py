--- ./setup.py.orig	2012-07-03 15:02:11.000000000 +0200
+++ ./setup.py	2012-07-03 15:03:10.000000000 +0200
@@ -1,4 +1,4 @@
-from setuptools import setup
+from distutils.core import setup
 import sys
 
 extra = {}
