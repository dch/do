--- src/data-to-c.pl.orig	2014-03-22 16:28:35.000000000 +0100
+++ src/data-to-c.pl	2014-03-22 16:28:44.000000000 +0100
@@ -1,4 +1,4 @@
-#!/usr/bin/perl
+#!/usr/bin/env perl
 
 # Copyright © 2011 Red Hat, Inc
 #
