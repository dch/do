--- Samples/Tests/PacketAndLowLevelTestsTest.cpp.orig	2012-03-21 18:05:53.218690543 +0100
+++ Samples/Tests/PacketAndLowLevelTestsTest.cpp	2012-03-21 18:06:27.805674560 +0100
@@ -1,6 +1,6 @@
 #include "PacketAndLowLevelTestsTest.h"
 
-#include "malloc.h"
+#include <stdlib.h>
 
 /*
 Description:
