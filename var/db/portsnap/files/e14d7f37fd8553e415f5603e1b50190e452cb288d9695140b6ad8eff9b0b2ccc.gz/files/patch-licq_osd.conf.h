--- src/licq_osd.conf.h.orig	Mon Mar  7 19:24:09 2005
+++ src/licq_osd.conf.h	Mon Mar  7 19:27:17 2005
@@ -4,7 +4,7 @@
 "# you can get the available fonts for your machine from xfontsel\n"
 "# i prefer this one - but it is not available everywhere\n"
 "# Font=-*-lucida-*-r-*-*-24-*-*-*-*-*-iso8859-15\n"
-"Font=-*-*-*-*-*-*-24-*-*-*-*-*-*-*\n"
+"Font=-*-lucida-*-*-*-*-24-*-*-*-*-*-iso8859-15\n"
 "\n"
 "# how long should a message be displayed\n"
 "Timeout=5\n"
