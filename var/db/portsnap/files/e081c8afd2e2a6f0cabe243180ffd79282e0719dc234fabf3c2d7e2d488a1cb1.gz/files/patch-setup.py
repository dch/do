--- ./setup.py.orig	2014-04-08 01:03:58.000000000 +0000
+++ ./setup.py	2014-04-08 19:02:39.000000000 +0000
@@ -56,5 +56,5 @@
           'simplejson',
           'requests',
     ],
-    data_files=data_files,
+    #data_files=data_files,
 )
