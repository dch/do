--- afterstep/alpha_header.h.orig	Thu Aug 22 20:48:18 1996
+++ afterstep/alpha_header.h	Mon Sep 13 14:35:09 2004
@@ -7,11 +7,6 @@
 
 extern int select(int, fd_set *, fd_set *, fd_set *, struct timeval *);
 
-/* string manipulation */
-#ifdef __GNUC__
-extern size_t strlen(char *);
-#endif
-
 /* Commented out 08/22/96 -- Thanks to Pierre Wendling 
 extern int bzero(char *, int);
 extern int gethostname (char *, int);
