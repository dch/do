--- GLTTGlyphPolygonizerHandler.h.orig	2007-11-16 11:59:00.000000000 +0100
+++ GLTTGlyphPolygonizerHandler.h	2007-11-16 11:59:58.000000000 +0100
@@ -28,6 +28,7 @@
 #include "FTGlyphVectorizer.h"
 #endif
 
+class GLTTGlyphPolygonizer;
 /////////////////////////////////////////////////////////////////////////////
 
 // Mmh, this class name is a bit long... /SR
