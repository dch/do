--- ps.c.orig	Thu Jul 17 03:40:40 1997
+++ ps.c	Fri Dec 10 03:11:36 1999
@@ -57,7 +57,6 @@
 #define PS(str)		OUT(psFile, str)
 #define PSU(str)	OUT(ui->psFile, str)
 #define IY(val)		(ui->height_devs - val)
-#define MAX(a, b)	((a) > (b) ? (a) : (b))
 
 /*
  * Globals
