--- hpgl.c.orig	Thu Aug  3 03:31:56 2000
+++ hpgl.c	Sun Aug  6 23:45:06 2000
@@ -13,9 +13,8 @@
 #include "xgout.h"
 #include "plotter.h"
 #include <stdio.h>
+#include <stdlib.h>
 #include <math.h>
-#define MAX(a,b) ( ((a)>(b)) ? (a) : (b) )
-#define MIN(a,b) ( ((a)<(b)) ? (a) : (b) )
 /* char *malloc(); */
 
 static void hpglText();
