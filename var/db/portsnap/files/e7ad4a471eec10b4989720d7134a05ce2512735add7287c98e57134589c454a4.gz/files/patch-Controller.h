--- Controller.h.orig	2005-02-08 12:21:42.000000000 +0100
+++ Controller.h	2010-05-23 07:14:06.000000000 +0200
@@ -37,6 +37,7 @@
 #include <AppKit/NSFont.h>
 #include <AppKit/NSWindow.h>
 #include <AppKit/NSMenu.h>
+#include <AppKit/NSPanel.h>
 
 typedef enum {
     MENU_NEW_WITH_REP = 500,
