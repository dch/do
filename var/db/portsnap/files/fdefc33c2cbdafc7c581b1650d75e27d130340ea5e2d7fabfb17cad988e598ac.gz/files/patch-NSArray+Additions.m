--- General/NSArray+Additions.m.orig	2006-01-24 14:10:07.000000000 +0100
+++ General/NSArray+Additions.m	2008-05-03 08:13:11.000000000 +0200
@@ -19,6 +19,7 @@
 */
 
 #include "NSArray+Additions.h"
+#include "Foundation/NSEnumerator.h"
 #include "Macros.h"
 
 // Enumerator of objects in a range of indexes of an array
