--- lessons.c.orig
+++ lessons.c
@@ -166,6 +166,7 @@
 "gggg pppp gggg pppp gggg pppp gggg pppp gggg pppp gggg pppp gggg ppp\n"
 "pg pg pg pg pg pg pg pg pg pg pg pg pg pg pg pg pg pg pg pg pg pg pg\n"
 "gp gp gp gp gp gp gp gp gp gp gp gp gp gp gp gp gp gp gp gp gp gp gp\n"
+"\x1"
 "gggg hhhh pppp uuuu gggg hhhh pppp uuuu gggg hhhh pppp uuuu\n"
 "up up up up hug hug hug hug pug pug pug pug pup pup pup pup\n"
 "ugh ugh ugh ugh Hugh Hugh Hugh Hugh Pugh Pugh Pugh Pugh",
@@ -263,7 +264,7 @@
 "The catchup accident at the picnic depicted Dutch as an apathetic nuisance.\n"
 "It is no coincidence that this idiotic sentence has eight concise Cs in it.\n"
 "The enthusiastic duchess noticed the Pontiac coupe...and decided to chase it."
-"\1"
+"\x1"
 "I detect a headache...I hope it is not the\n"
 "Schnapps and Cocoa I had as a nightcap.\n"
 "\n"
@@ -362,11 +363,12 @@
 "Allegra, an unparalleled intellectual, calculated the celestial latitudes and\n"
 "longitudes in her sleep.",
 
-    "YF: index fingers streching up",
+    "YF: index fingers stretching up",
 "\x2"   
 "ffff yyyy ffff yyyy ffff yyyy ffff yyyy ffff yyyy ffff yyyy ffff yyyy\n"
 "ffff yyyy ffff yyyy ffff yyyy ffff yyyy ffff yyyy ffff yyyy ffff yyyy\n"
 "fy fy fy fy fy fy fy yf yf yf yf yf yf yf ffff gggg hhhh yyyy pppp uuuu\n"
+"\x1"
 "guy guy guy guy guy guy guy guy guy gyp gyp gyp gyp gyp gyp gyp gyp gyp\n"
 "UHF UHF UHF UHF UHF UHF UHF UHF UHF yuh yuh yuh yuh yuh yuh yuh yuh yuh\n"
 "huff huff huff huff huff huff huff puff puff puff puff puff puff puff\n"
@@ -406,6 +408,7 @@
 "kkkk mmmm kkkk mmmm kkkk mmmm kkkk mmmm kkkk mmmm kkkk mmmm\n"
 "kkkk mmmm kkkk mmmm kkkk mmmm kkkk mmmm kkkk mmmm kkkk mmmm\n"
 "km km km km km km km km km km mk mk mk mk mk mk mk mk mk mk\n"
+"\x1"
 "hhhh kkkk mmmm uuuu hhhh kkkk mmmm uuuu hhhh kkkk mmmm uuuu\n"
 "ku ku ku ku ku ku ku ku ku ku mu mu mu mu mu mu mu mu mu mu\n"
 "UK UK UK UK UK UK UK UK UK UK UK UK UK UK UK UK UK UK UK UK\n"
@@ -442,6 +445,7 @@
 "jjjj wwww jjjj wwww jjjj wwww jjjj wwww jjjj wwww jjjj wwww\n"
 "jjjj wwww jjjj wwww jjjj wwww jjjj wwww jjjj wwww jjjj wwww\n"
 "jw jw jw jw jw jw jw jw jw jw jw wj wj wj wj wj wj wj wj wj\n"
+"\x1"
 "eeee jjjj tttt wwww eeee jjjj tttt wwww eeee jjjj tttt wwww\n"
 "ewe ewe ewe ewe ewe jet jet jet jet jet Jew Jew Jew Jew Jew\n"
 "wee wee wee wee wee wee wee wet wet wet wet wet wet wet wet\n"
@@ -500,6 +504,7 @@
 "An acquisitive mind helped Pavlov evolve his theories.\n"
 "QVC's involvement with Paramount may give it new verve.\n"
 "Vivian's new Volvo unequivocally vanquished her fears of driving.\n"
+"\x1"
 "According to Pravda, Vladivostok was a quiet village in its Soviet days.\n"
 "This unique, opaque liquor does not quench your thirst, it makes you queasy.\n"
 "David's vivid imagination and his inquisitive and inventive mind suggest a high IQ."
@@ -548,7 +553,7 @@
 "activity; several lizards hazarded the freezing waters and capsized the fish\n"
 "tanks; a dozen grizzlies were waltzing in the plaza.",
 
-    "XB: index fingers streching down",
+    "XB: index fingers stretching down",
 "\x2"   
 "bbbb xxxx bbbb xxxx bbbb xxxx bbbb xxxx bbbb xxxx bbbb xxxx\n"
 "bbbb xxxx bbbb xxxx bbbb xxxx bbbb xxxx bbbb xxxx bbbb xxxx\n"
