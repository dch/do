--- Vsop.h.orig	Tue Nov 26 15:41:59 2002
+++ Vsop.h	Tue Nov 26 15:42:13 2002
@@ -12,6 +12,7 @@
 #define VSOP__H
 
 #include "PlanetData.h"  // for enum Planet
+#include <math.h>
 
 // * * * * * simple support structs * * * * *
 
