--- pex/version.py.orig	2015-07-14 15:45:35 UTC
+++ pex/version.py
@@ -3,5 +3,5 @@
 
 __version__ = '1.0.1'
 
-SETUPTOOLS_REQUIREMENT = 'setuptools>=2.2,<16'
+SETUPTOOLS_REQUIREMENT = 'setuptools>=2.2,<=17'
 WHEEL_REQUIREMENT = 'wheel>=0.24.0,<0.25.0'
