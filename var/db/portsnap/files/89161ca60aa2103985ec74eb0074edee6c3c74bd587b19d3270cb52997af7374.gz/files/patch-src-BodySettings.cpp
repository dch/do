--- src/BodySettings.cpp.orig	2007-12-03 01:30:41.000000000 +0300
+++ src/BodySettings.cpp	2013-09-17 17:25:49.896520104 +0400
@@ -1,5 +1,7 @@
 #include "../include/animorph/BodySettings.h"
 
+#include <cstring>
+
 using namespace std;
 using namespace Animorph;
 
