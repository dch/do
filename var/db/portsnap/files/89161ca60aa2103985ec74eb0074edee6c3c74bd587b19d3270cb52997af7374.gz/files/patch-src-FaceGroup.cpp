--- src/FaceGroup.cpp.orig	2007-12-03 01:30:41.000000000 +0300
+++ src/FaceGroup.cpp	2013-09-17 17:56:37.772519994 +0400
@@ -1,5 +1,7 @@
 #include "../include/animorph/FaceGroup.h"
 
+#include <cstring>
+
 using namespace std;
 using namespace Animorph;
 
