--- src/Hotspot.cpp.orig	2007-11-25 12:34:58.000000000 +0300
+++ src/Hotspot.cpp	2013-09-17 17:32:58.043519323 +0400
@@ -1,5 +1,7 @@
 #include "../include/animorph/Hotspot.h"
 
+#include <cstring>
+
 using namespace std;
 using namespace Animorph;
 
