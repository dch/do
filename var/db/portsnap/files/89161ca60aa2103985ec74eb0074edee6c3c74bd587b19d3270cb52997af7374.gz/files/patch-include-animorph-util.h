--- include/animorph/util.h.orig	2007-11-25 12:34:57.000000000 +0300
+++ include/animorph/util.h	2013-09-14 08:03:24.413227432 +0400
@@ -37,6 +37,7 @@
 #include <iomanip>
 #include <vector>
 #include <iostream>
+#include <cstdlib> // for atoi()
 #include "Vector3.h"
 #include "Vertex.h"
 #include "VertexVector.h"
