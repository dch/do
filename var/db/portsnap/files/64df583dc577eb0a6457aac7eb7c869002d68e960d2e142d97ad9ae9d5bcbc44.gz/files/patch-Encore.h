--- Encore.h.orig	2006-12-08 08:41:12.000000000 +0100
+++ Encore.h	2012-02-06 04:57:39.000000000 +0100
@@ -53,7 +53,6 @@
 #include <Encore/ECLogging.h>
 #include <Encore/ECDefaultLoggingFormatter.h>
 #include <Encore/ECNSLogLoggingWriter.h>
-#include <Encore/ECLoggingConfigurationFactory.h>
 #include <Encore/ECLoggingConfiguration.h>
 #include <Encore/ECFileLoggingWriter.h>
 #include <Encore/ECLoggingXMLConfiguration.h>
