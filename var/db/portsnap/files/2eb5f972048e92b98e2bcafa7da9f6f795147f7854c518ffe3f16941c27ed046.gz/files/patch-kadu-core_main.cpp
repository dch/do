--- kadu-core/main.cpp.orig	2015-07-20 19:41:44 UTC
+++ kadu-core/main.cpp
@@ -33,7 +33,7 @@
 
 #include <QtCore/QLibraryInfo>
 #include <QtCore/QTranslator>
-#include <QtCrypto/QtCrypto>
+#include <QtCrypto>
 #include <QtWidgets/QApplication>
 #include <QtWidgets/QMessageBox>
 
