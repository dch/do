--- config.inc.php.orig	2009-04-08 06:42:59.000000000 +0200
+++ config.inc.php	2012-05-04 19:43:02.000000000 +0200
@@ -100,7 +100,7 @@
 */
 $list_webcals = array(
 #	'webcal://dimer.tamu.edu/calendars/seminars/Biochem.ics'
-'webcal://calendar.sxsw.com/iCal-EXDrB-sa-sxsw@rollerfeet.com.ics'
+#	'webcal://calendar.sxsw.com/iCal-EXDrB-sa-sxsw@rollerfeet.com.ics'
 );
 $more_webcals['recur_tests'] = array();
 $locked_cals = array(
