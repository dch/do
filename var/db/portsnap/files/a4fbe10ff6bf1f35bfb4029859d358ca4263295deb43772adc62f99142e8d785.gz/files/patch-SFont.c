--- SFont.c	Thu Aug 30 04:00:45 2001
+++ SFont.c	Fri Oct 25 21:07:58 2002
@@ -1,6 +1,7 @@
 #include <SDL.h>
 #include "SFont.h"
 #include <string.h>
+#include <stdlib.h>
 
 SFont_FontInfo InternalFont;
