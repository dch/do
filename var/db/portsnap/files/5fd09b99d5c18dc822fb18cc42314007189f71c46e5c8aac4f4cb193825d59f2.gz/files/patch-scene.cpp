--- ./scene.cpp.orig	Thu Oct 10 16:57:58 2002
+++ ./scene.cpp	Sat Jul 21 17:54:40 2007
@@ -2361,7 +2361,7 @@
 	oldTimer = newTimer;
 	globalList->move()	;
 #ifndef PI
-#define PI=3.151592653589793
+#define PI=3.141592653589793
 #endif
 	benchFrames++;
 
