--- src/dlmodule.c.orig	2005-11-13 07:45:16.000000000 +0900
+++ src/dlmodule.c	2008-06-16 15:28:33.000000000 +0900
@@ -89,6 +89,9 @@
         return RETURN_FAILURE;
     }
     
+    /* clear error indicator */
+    dlerror();
+
     newkey.data = dlsym(handle, dl_function);
     if (!newkey.data && (error = dlerror()) != NULL) {
         errmsg(error);
