--- gpl.h.orig	2007-11-05 23:45:33.000000000 +0100
+++ gpl.h	2007-11-05 23:45:40.000000000 +0100
@@ -20,7 +20,7 @@
 //
 ////////////////////////////////////////////////////////////////////////
 
-char *gpl[] = {
+const char *gpl[] = {
 "GNU GENERAL PUBLIC LICENSE",
 "TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION",
 " ",
