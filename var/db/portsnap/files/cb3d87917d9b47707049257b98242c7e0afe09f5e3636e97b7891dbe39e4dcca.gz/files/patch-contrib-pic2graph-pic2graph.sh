--- contrib/pic2graph/pic2graph.sh.orig	2014-08-30 03:06:55.000000000 +0900
+++ contrib/pic2graph/pic2graph.sh	2014-08-30 03:07:01.000000000 +0900
@@ -1,4 +1,4 @@
-#!/bin/bash
+#!/bin/sh
 #
 # pic2graph -- compile PIC image descriptions to bitmap images
 #
