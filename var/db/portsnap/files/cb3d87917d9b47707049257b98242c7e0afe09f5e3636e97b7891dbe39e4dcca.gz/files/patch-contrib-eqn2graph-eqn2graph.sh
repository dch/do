--- contrib/eqn2graph/eqn2graph.sh.orig	2014-08-30 03:07:55.000000000 +0900
+++ contrib/eqn2graph/eqn2graph.sh	2014-08-30 03:08:01.000000000 +0900
@@ -1,4 +1,4 @@
-#!/bin/bash
+#!/bin/sh
 #
 # eqn2graph -- compile EQN equation descriptions to bitmap images
 #
