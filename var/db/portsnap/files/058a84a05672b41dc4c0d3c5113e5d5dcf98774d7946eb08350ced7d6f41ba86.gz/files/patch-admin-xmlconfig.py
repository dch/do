--- admin/xmlconfig.py.orig	2008-02-20 23:13:48.000000000 +0100
+++ admin/xmlconfig.py	2008-03-03 16:39:09.376694098 +0100
@@ -48,7 +48,7 @@
 # The HTTP package base URI.  This is the place on the web where the
 # PEAR-installable tarballs will live, and this (plus the package
 # tarball name) will be the URL that users pass to "pear install".
-package_base_uri = 'http://www.openidenabled.com/resources/downloads/php-openid/pear/'
+package_base_uri = 'http://openidenabled.com/files/php-openid/packages/'
 
 # The release stability.  Maybe this should be a commandline parameter
 # since it might differ from release to release.
