--- mix.exs.orig	2015-07-07 20:48:03 UTC
+++ mix.exs
@@ -7,7 +7,6 @@ defmodule EXJSX.Mixfile do
       elixir: ">= 0.13.3",
       description: description,
       package: package,
-      deps: deps
     ]
   end
 
