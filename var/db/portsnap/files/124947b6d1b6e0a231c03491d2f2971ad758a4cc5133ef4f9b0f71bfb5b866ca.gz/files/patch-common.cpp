--- common.cpp.orig
+++ common.cpp
@@ -22,6 +22,8 @@
  *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
  */
 
+#include <cstdlib>
+
 #include "common.h"
 #include "speedctrl.h"
 #include "mirroradmin.h"
