--- enemyshot.c.orig
+++ enemyshot.c
@@ -11,6 +11,7 @@
 #include <X11/xpm.h>
 */
 
+#include <stdlib.h>
 #include "image.h"
 #include "xsoldier.h"
 #include "manage.h"
