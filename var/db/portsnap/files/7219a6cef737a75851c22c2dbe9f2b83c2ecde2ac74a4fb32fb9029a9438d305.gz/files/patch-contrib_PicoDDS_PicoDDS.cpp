--- contrib/PicoDDS/PicoDDS.cpp.orig	2015-06-07 21:44:10 UTC
+++ contrib/PicoDDS/PicoDDS.cpp
@@ -48,6 +48,7 @@
 */
 
 #include "PicoDDS.h"
+#include <stdlib.h>
 #include <cstdio>
 #include <cstring>
 #include <cassert>
