--- libicq2000/src/ContactTree.cpp.orig	2011-05-23 01:06:31.000000000 +0400
+++ libicq2000/src/ContactTree.cpp	2013-11-28 19:19:57.334970339 +0400
@@ -22,6 +22,8 @@
 #include "ContactTree.h"
 #include "events.h"
 
+#include <cstdlib>
+
 namespace ICQ2000 {
 
   using std::string;
