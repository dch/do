--- convolution_process.c.orig	Mon Apr  2 09:22:07 2007
+++ convolution_process.c	Mon Apr  2 09:22:15 2007
@@ -23,7 +23,7 @@
 #include <dsp/dspop.h>
 #endif
 
-#include <malloc.h>
+#include <stdlib.h>
 #include <math.h>
 
 
