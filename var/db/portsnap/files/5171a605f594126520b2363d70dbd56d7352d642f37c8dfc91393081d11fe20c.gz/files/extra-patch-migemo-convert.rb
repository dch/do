--- migemo-convert.rb.orig	2003-05-26 15:55:22.000000000 +0900
+++ migemo-convert.rb	2011-08-22 02:20:13.000000000 +0900
@@ -14,7 +14,6 @@
 #
 # Convert a SKK's dictionary into Migemo's.
 #
-$KCODE= "e"
 require 'romkan'
 
 HIRAGANA = "[��-�󡼡�]"
