--- src/util/file_reader.hpp.orig	2011-12-25 01:46:47.000000000 +0400
+++ src/util/file_reader.hpp	2014-10-17 23:56:43.000000000 +0400
@@ -19,6 +19,7 @@
 
 #include <memory>
 #include <vector>
+#include <string>
 
 class Size;
 class Color;
