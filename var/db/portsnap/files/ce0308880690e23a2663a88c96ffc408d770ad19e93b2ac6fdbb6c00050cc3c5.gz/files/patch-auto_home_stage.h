--- /dev/null	2014-08-21 12:22:00.000000000 +0200
+++ auto_home_stage.h	2014-08-21 12:25:14.000000000 +0200
@@ -0,0 +1,6 @@
+#ifndef AUTO_HOME_STAGE_H_
+#define AUTO_HOME_STAGE_H_
+
+extern char auto_home[];
+
+#endif
