--- shapes/pngio.cc.orig	2013-01-27 03:00:25 UTC
+++ shapes/pngio.cc
@@ -31,6 +31,7 @@ Foundation, Inc., 59 Temple Place - Suit
 
 #include <png.h>
 #include <setjmp.h>
+#include <string.h>
 
 
 /*
