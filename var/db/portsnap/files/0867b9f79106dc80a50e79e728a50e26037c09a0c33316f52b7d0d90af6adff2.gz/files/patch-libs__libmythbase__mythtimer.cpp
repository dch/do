--- libs/libmythbase/mythtimer.cpp.orig	2013-09-18 20:06:08.000000000 +0000
+++ libs/libmythbase/mythtimer.cpp	2013-10-22 11:03:36.000000000 +0000
@@ -19,6 +19,8 @@
  *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA
  */
 
+#include <stdint.h>
+
 // MythTV includes
 #include "mythtimer.h"
 
