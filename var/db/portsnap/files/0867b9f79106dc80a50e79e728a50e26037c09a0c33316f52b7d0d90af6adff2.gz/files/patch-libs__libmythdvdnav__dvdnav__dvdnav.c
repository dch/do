--- libs/libmythdvdnav/dvdnav/dvdnav.c.orig	2012-03-18 12:13:45.805789048 +0100
+++ libs/libmythdvdnav/dvdnav/dvdnav.c	2012-03-18 12:12:47.166812027 +0100
@@ -33,7 +33,7 @@
 #include <limits.h>
 #include <string.h>
 #include <sys/time.h>
-#include "dvdnav/dvdnav.h"
+#include "dvdnav.h"
 #include <dvdread/dvd_reader.h>
 #include <dvdread/nav_types.h>
 #include <dvdread/ifo_types.h> /* For vm_cmd_t */
