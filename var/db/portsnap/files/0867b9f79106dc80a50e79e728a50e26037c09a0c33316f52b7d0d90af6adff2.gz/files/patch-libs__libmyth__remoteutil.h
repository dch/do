--- libs/libmyth/remoteutil.h.orig	2013-09-18 16:06:08.000000000 -0400
+++ libs/libmyth/remoteutil.h	2014-01-22 08:26:34.000000000 -0500
@@ -8,6 +8,7 @@
 using namespace std;
 
 #include "mythexp.h"
+#include <sys/types.h>
 
 class ProgramInfo;
 class MythEvent;

