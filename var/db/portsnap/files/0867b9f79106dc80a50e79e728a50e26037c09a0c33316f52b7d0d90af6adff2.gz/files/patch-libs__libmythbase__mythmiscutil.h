--- libs/libmythbase/mythmiscutil.h.orig	2013-09-18 20:06:08.000000000 +0000
+++ libs/libmythbase/mythmiscutil.h	2013-10-18 12:23:08.000000000 +0000
@@ -2,6 +2,7 @@
 #define MYTHMISCUTIL_H_
 
 #include <stdint.h>
+#include <time.h>
 
 #include <algorithm>
 using namespace std;
