--- libdi_d/config.sh.orig	Wed Apr 21 15:27:07 2004
+++ libdi_d/config.sh	Sun Mar 12 23:40:59 2006
@@ -744,7 +744,7 @@
 
 	if [ -z "$IOCDEF" -o "$IOCDEF" = 0 ]
 	then
-		IOCDEF=1
+		IOCDEF=2
 	fi
 
 	while :
