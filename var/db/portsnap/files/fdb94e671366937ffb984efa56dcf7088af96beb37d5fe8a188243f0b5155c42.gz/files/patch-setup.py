--- setup.py.orig	2010-08-08 11:00:33.408023094 +0200
+++ setup.py	2010-08-08 11:00:48.754104230 +0200
@@ -35,7 +35,7 @@
     author_email = "richard@mechanicalcat.net",
     url = 'http://mechanicalcat.net/tech/webunit/',
     download_url = 'http://pypi.python.org/pypi/webunit',
-    packages = ['webunit', 'demo'],
+    packages = ['webunit'],
     classifiers = [
         'Development Status :: 5 - Production/Stable',
         'Environment :: Console',
