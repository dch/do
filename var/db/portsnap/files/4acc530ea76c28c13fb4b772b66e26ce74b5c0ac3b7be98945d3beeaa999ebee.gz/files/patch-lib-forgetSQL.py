--- lib/forgetSQL.py.orig	Sat Nov 20 16:59:07 2004
+++ lib/forgetSQL.py	Sat Nov 20 16:59:39 2004
@@ -1,4 +1,5 @@
 #!/usr/bin/env python
+# -*- coding: ISO-8859-1 -*-
 
 __version__ = "0.5.1"
 
