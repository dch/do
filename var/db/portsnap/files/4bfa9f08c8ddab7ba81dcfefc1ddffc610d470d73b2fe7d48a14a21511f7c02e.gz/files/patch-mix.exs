--- mix.exs.orig	2015-07-13 09:38:15 UTC
+++ mix.exs
@@ -5,7 +5,6 @@ defmodule ESTree.Mixfile do
     [app: :estree,
      version: "2.0.0",
      elixir: "~> 1.0",
-     deps: deps,
      description: description,
      package: package,
      source_url: "https://github.com/bryanjos/elixir-estree"]
