--- netmap/hostclass.c.orig
+++ netmap/hostclass.c
@@ -1,4 +1,3 @@
-#include <strstream>
 #include <map>
 
 //from belgolib
