--- netmap/drawmap.c.orig
+++ netmap/drawmap.c
@@ -1,4 +1,3 @@
-#include <strstream>
 #include <iostream>
 
 #include <fstream>
