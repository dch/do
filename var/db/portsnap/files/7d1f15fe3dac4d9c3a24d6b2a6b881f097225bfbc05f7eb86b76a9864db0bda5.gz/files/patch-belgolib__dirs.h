--- belgolib/dirs.h.orig	Sun Dec 15 14:54:27 2002
+++ belgolib/dirs.h	Sun Dec 15 14:54:27 2002
@@ -3,6 +3,7 @@
 //   - Consider using vector instead of list<T*>'s 
 
 #include <list>
+using namespace std;
 
 #ifndef __make_dep__
 #include <string>
