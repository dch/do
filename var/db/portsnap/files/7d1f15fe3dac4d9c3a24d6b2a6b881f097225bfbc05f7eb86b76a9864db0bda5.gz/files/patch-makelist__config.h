--- makelist/config.h.orig	Sun Dec 15 14:54:27 2002
+++ makelist/config.h	Sun Dec 15 14:54:27 2002
@@ -2,6 +2,7 @@
 #define _config_h_
 
 #include <string>
+using namespace std;
 
 extern int par_traceroute;
 
