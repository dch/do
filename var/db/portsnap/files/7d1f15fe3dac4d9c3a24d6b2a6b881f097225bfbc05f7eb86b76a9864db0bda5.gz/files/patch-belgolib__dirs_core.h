--- belgolib/dirs_core.h.orig	Wed Dec 19 07:46:22 2001
+++ belgolib/dirs_core.h	Sun Dec 15 15:01:06 2002
@@ -4,6 +4,7 @@
 
 #ifndef __make_dep__
 #include <string>
+using namespace std;
 #endif
 
 #ifndef __dirs_core_h__
