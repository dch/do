--- belgolib/dirs.c.orig	Tue Jul 22 04:58:32 2003
+++ belgolib/dirs.c	Tue Jul 22 04:58:46 2003
@@ -1,5 +1,6 @@
 #include <stdio.h>
 #include <dirent.h>
+#include <assert.h>
 
 #include <list>
 
