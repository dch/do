--- netmap/misc.h.orig
+++ netmap/misc.h
@@ -2,7 +2,6 @@
 #define _misc_h_
 
 #include <string>
-#include <strstream>
 #include <iostream>
 
 #include <list>
