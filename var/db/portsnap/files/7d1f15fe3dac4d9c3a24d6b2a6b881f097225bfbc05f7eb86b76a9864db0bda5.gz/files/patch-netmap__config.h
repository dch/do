--- netmap/config.h.orig	Sun Dec 15 14:54:26 2002
+++ netmap/config.h	Sun Dec 15 14:54:26 2002
@@ -3,6 +3,7 @@
 
 #include <list>
 #include <string>
+using namespace std;
 
 const string version = "NetMap 0.1.2 20011221";
 
