--- modules/freebsd/vmhgfs/channel.h.orig	2014-04-23 15:36:34.432844311 +0000
+++ modules/freebsd/vmhgfs/channel.h	2014-04-23 15:36:44.389843756 +0000
@@ -21,7 +21,7 @@
  */
 
 #ifndef _HGFS_CHANNEL_H_
-#define _HGFS_CHANNEL__H_
+#define _HGFS_CHANNEL_H_
 
 #include "hgfs_kernel.h"
 #include "requestInt.h"
