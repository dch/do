--- include/grub/i386/bsd.h.orig	2014-12-30 21:10:24 UTC
+++ include/grub/i386/bsd.h
@@ -26,6 +26,7 @@
 #include <grub/i386/netbsd_reboot.h>
 #include <grub/i386/openbsd_reboot.h>
 #include <grub/i386/freebsd_linker.h>
+#include <grub/i386/freebsd_bootinfo.h>
 #include <grub/i386/netbsd_bootinfo.h>
 #include <grub/i386/openbsd_bootarg.h>
 
