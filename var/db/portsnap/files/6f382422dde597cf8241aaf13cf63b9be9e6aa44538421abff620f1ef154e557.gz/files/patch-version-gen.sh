--- version-gen.sh.orig	2012-11-11 11:43:05.000000000 +0100
+++ version-gen.sh	2012-12-06 14:49:39.204586447 +0100
@@ -1,4 +1,4 @@
-#!/usr/bin/env bash
+#!/usr/bin/env sh
 
 DEFAULT_VERSION="4.10.8.git"
