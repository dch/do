--- valknut/main.cpp.orig	2009-01-17 18:01:25.000000000 +0000
+++ valknut/main.cpp
@@ -26,6 +26,7 @@
 #include <signal.h>
 #endif
 
+#include <unistd.h>
 #include <qapplication.h>
 #include <qfont.h>
 #include <qstring.h>
