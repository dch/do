--- src/examples/ft_recv.cpp.orig
+++ src/examples/ft_recv.cpp
@@ -11,7 +11,7 @@
 using namespace gloox;
 
 #include <unistd.h>
-#include <stdio.h>
+#include <ctime>
 #include <string>
 
 #include <cstdio> // [s]print[f]
