--- help.c	Sat Jul 12 18:54:34 1997
+++ /home/andy/tmp/wrk/help.c	Tue Dec 16 12:15:00 1997
@@ -10,7 +10,7 @@
 
 #define CS              34
 #define HELPDIR         "/usr/lib/deco/help/"
-#define LCLHELPDIR      "/usr/local/lib/deco/help/"
+#define LCLHELPDIR      "/usr/local/share/deco/help/"
 
 struct helptab {
 	char row;
