--- ex.c	Sat Jul 12 18:54:34 1997
+++ /home/andy/tmp/wrk/ex.c	Tue Dec 16 12:14:53 1997
@@ -59,11 +59,11 @@
 #define UMFILE ".menu"
 #define INITFILE ".decoini"
 #define ULDINITFILE "/usr/lib/deco/initfile"
-#define ULLDINITFILE "/usr/local/lib/deco/initfile"
+#define ULLDINITFILE "/usr/local/share/deco/initfile"
 #define ULDUMFILE "/usr/lib/deco/menu"
-#define ULLDUMFILE "/usr/local/lib/deco/menu"
+#define ULLDUMFILE "/usr/local/share/deco/menu"
 #define ULDEXFILE "/usr/lib/deco/profile"
-#define ULLDEXFILE "/usr/local/lib/deco/profile"
+#define ULLDEXFILE "/usr/local/share/deco/profile"
 
 struct ex {
 	char *pat;
