--- covmerge.c.orig	2014-08-05 11:26:54.373266288 -0300
+++ covmerge.c	2014-08-05 11:27:07.809636312 -0300
@@ -18,6 +18,7 @@
 
 
 #include <read_database.h>
+#include <stdlib.h>
 
 
 //
