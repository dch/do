--- covstream.c.orig	2014-08-05 11:23:02.593282007 -0300
+++ covstream.c	2014-08-05 11:23:04.274285503 -0300
@@ -35,6 +35,7 @@
 #include <iostream>
 #include <unistd.h>
 #include <algorithm>
+#include <string.h>
 
 using namespace std;
 
