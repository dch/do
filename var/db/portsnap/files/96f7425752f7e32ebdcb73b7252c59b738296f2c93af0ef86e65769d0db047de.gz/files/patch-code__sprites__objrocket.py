--- ./code/sprites/objrocket.py.orig	2001-08-26 22:43:43.000000000 +0200
+++ ./code/sprites/objrocket.py	2014-04-09 22:27:18.663886283 +0200
@@ -6,7 +6,6 @@
 import random
 import pygame
 from pygame.locals import *
-from pygame.UserRect import UserRect
 import game, gfx
 
 from baseairobj import AirObj
