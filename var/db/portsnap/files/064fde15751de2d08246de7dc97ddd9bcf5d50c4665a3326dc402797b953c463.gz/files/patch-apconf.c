--- apconf.c.orig	Sat Feb 19 21:05:40 2005
+++ apconf.c	Sat Feb 19 21:05:54 2005
@@ -6,6 +6,7 @@
  */
 
 #include <stdio.h>
+#include <sys/types.h>
 #include <regex.h>
 #include <string.h>
 #include <stdlib.h>
