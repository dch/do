--- src/libUnicorn/TrackInfo.h.orig
+++ src/libUnicorn/TrackInfo.h
@@ -33,6 +33,8 @@
 #include <QStringList>
 #include <QUrl>
 
+#include <sys/time.h>
+
 
 class UNICORN_DLLEXPORT TrackInfo
 {
