--- src/utils.cpp.orig
+++ src/utils.cpp
@@ -22,6 +22,8 @@
 #  include "config.h"
 #endif
 
+#include <cstdio>
+#include <cstdlib>
 #include <glib.h>
 #include <glib/gi18n.h>
 
