from distutils.core import setup

setup(
    name = 'PHPSerialize',
    version = "%%PORTVERSION%%",
    py_modules = ['PHPSerialize', 'PHPUnserialize'],
    )
