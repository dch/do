--- 7z/Portable.h.org	Mon Aug  7 10:54:35 2006
+++ 7z/Portable.h	Mon Aug  7 10:54:55 2006
@@ -2,7 +2,7 @@
 #define __PORTABLE_H
 
 #include <string.h>
-#include <stdint.h>
+#include <inttypes.h>
 
 typedef signed char INT8;
 typedef unsigned char UINT8;
