--- ./docs/conf.py.orig	2014-04-01 22:42:52.000000000 +0200
+++ ./docs/conf.py	2014-04-01 22:43:15.000000000 +0200
@@ -244,7 +244,3 @@
 
 # How to display URL addresses: 'footnote', 'no', or 'inline'.
 #texinfo_show_urls = 'footnote'
-
-
-# Example configuration for intersphinx: refer to the Python standard library.
-intersphinx_mapping = {'http://docs.python.org/': None}
