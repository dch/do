--- src/libqtlcmswidgets/lprofgauge.h.orig	2008-02-20 00:02:39.000000000 +0300
+++ src/libqtlcmswidgets/lprofgauge.h	2008-05-24 05:07:17.000000000 +0400
@@ -58,7 +58,6 @@
 
 #include <Qt>
 #include <QWidget>
-#include <QtDesigner/QDesignerExportWidget>
 
 
 class QColor;
