--- nas.h.orig	Mon Oct  3 18:53:39 2005
+++ nas.h	Mon Oct  3 18:53:51 2005
@@ -21,7 +21,6 @@
 #ifndef NAS_H
 #define NAS_H
 
-#include "config.h"
 
 #include <gtk/gtk.h>
 
