*** naplay.c.ORIG	Tue Nov  1 19:40:13 1994
--- naplay.c	Sat Jun 10 19:51:40 1995
***************
*** 1,3 ****
--- 1,4 ----
+ #include <sys/types.h>
  #include <useconfig.h>
  #include <sys/time.h>
  #include <sys/stat.h>
