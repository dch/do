--- src/tooracleconnection.cpp.orig	2010-09-19 09:27:38 UTC
+++ src/tooracleconnection.cpp
@@ -58,7 +58,6 @@
 
 #define OTL_STL
 #define OTL_EXCEPTION_ENABLE_ERROR_OFFSET
-#define OTL_ORA_UTF8
 #define OTL_ORA_UNICODE
 #define OTL_ORA_TIMESTAMP
 #define OTL_ANSI_CPP
