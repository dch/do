--- src/toreport.cpp.orig	2010-01-14 16:39:02 UTC
+++ src/toreport.cpp
@@ -39,6 +39,7 @@
  *
  * END_COMMON_COPYRIGHT_HEADER */
 
+#include <unistd.h>
 #include "utils.h"
 
 #include "toconf.h"
