--- src/topiechart.h.orig	2009-10-23 16:19:33 UTC
+++ src/topiechart.h
@@ -44,6 +44,7 @@
 
 #include "config.h"
 
+#include <time.h>
 #include <list>
 #include <qwidget.h>
 
