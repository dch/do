--- src/towaitevents.h.orig	2009-10-23 16:19:33 UTC
+++ src/towaitevents.h
@@ -48,6 +48,7 @@
 #include <list>
 #include <map>
 #include <algorithm>
+#include <ctime>
 
 #include <QWidget>
 #include <QString>
