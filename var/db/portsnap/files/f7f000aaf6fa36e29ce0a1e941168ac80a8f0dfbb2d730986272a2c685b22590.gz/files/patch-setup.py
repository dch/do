--- setup.py.orig	2007-09-24 17:30:50.000000000 +0900
+++ setup.py	2008-03-05 20:02:42.000000000 +0900
@@ -16,11 +16,6 @@
 		'Pmw.Pmw_1_3.lib',],
 
       package_data={'Pmw': ['Pmw_1_3/lib/Pmw.def',
-			    'Pmw_1_3/doc/*',
-	                    'Pmw_1_3/contrib/*',
-	                    'Pmw_1_3/demos/*',
-	                    'Pmw_1_3/tests/*',
-                            'Pmw_1_3/bin/*',
 			   ]
                    },
       
