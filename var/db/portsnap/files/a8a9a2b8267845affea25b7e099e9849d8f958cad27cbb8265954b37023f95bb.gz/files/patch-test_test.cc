--- test/test.cc.orig	2009-12-12 20:22:34.000000000 +0000
+++ test/test.cc
@@ -1,5 +1,6 @@
 #include <iostream>
 #include <stdexcept>
+#include <unistd.h>
 using namespace std;
 #include <opkele/exception.h>
 #include <opkele/util.h>
