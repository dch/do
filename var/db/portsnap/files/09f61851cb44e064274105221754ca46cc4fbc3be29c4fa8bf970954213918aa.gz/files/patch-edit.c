--- edit.c.orig	2013-06-11 18:21:01.902812410 +0400
+++ edit.c	2013-06-11 18:21:15.931811652 +0400
@@ -2,6 +2,7 @@
 
 #include <stdio.h>
 #include <unistd.h>
+#include <string.h>
 #include "scav.h"
 #include "edit.h"
 #include "x.h"
