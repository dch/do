--- src/gaiagraphics_grids.c.orig	2012-07-01 18:19:38.000000000 +0200
+++ src/gaiagraphics_grids.c	2012-07-01 18:19:59.000000000 +0200
@@ -30,6 +30,7 @@
 #include <limits.h>
 #include <string.h>
 #include <stdlib.h>
+#include <sys/types.h>
 
 #include "gaiagraphics.h"
 #include "gaiagraphics_internals.h"
