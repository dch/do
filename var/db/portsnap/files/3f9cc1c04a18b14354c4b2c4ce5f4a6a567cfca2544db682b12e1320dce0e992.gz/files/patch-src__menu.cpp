--- src/menu.cpp.orig	2005-07-19 03:25:16.000000000 +0400
+++ src/menu.cpp	2014-11-24 16:08:56.000000000 +0300
@@ -341,6 +341,7 @@
 	} else {
 		//@fixme throw something
 	}
+	return false;
 }
 
 };
