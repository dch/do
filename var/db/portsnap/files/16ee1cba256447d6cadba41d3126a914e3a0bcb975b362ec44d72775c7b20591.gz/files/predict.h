char *predictpath={"%%PREFIX%%/share/predict/"}, soundcard=1, *version={"2.2.3"};
