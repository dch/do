char *path={"%%PREFIX%%/share/predict/vocalizer/"};
