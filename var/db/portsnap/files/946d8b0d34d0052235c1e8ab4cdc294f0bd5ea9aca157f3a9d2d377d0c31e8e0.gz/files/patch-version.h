Index: version.h
===================================================================
RCS file: /home/cvs/cdparanoia/version.h,v
retrieving revision 1.1.1.1
retrieving revision 1.2
diff -u -r1.1.1.1 -r1.2
--- version.h	2003/01/05 09:46:26	1.1.1.1
+++ version.h	2003/01/07 00:49:01	1.2
@@ -8,6 +8,8 @@
 
 
 #define VERSION "cdparanoia III release 9.8 (March 23, 2001)\n"\
-                "(C) 2001 Monty <monty@xiph.org> and Xiphophorus\n\n"\
+                "(C) 2001 Monty <monty@xiph.org> and Xiphophorus\n"\
+		"FreeBSD porting (c) 2003\n"\
+		"\tSimon 'corecode' Schubert <corecode@corecode.ath.cx>\n\n"\
 		"Report bugs to paranoia@xiph.org\n"\
 		"http://www.xiph.org/paranoia/\n"
