--- src/spring.cpp.orig	2013-11-23 01:34:04.000000000 +0400
+++ src/spring.cpp	2013-12-10 04:26:29.352082590 +0400
@@ -28,6 +28,7 @@
 #include <wx/filename.h>
 #include <stdexcept>
 #include <vector>
+#include <clocale>
 #include <fstream>
 
 #include "spring.h"
