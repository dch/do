--- src/lsl/src/lslutils/misc.cpp.orig	2013-08-31 14:17:00.000000000 +0400
+++ src/lsl/src/lslutils/misc.cpp	2013-12-10 04:20:26.887107289 +0400
@@ -3,6 +3,7 @@
 
 #include <boost/filesystem.hpp>
 #include <fstream>
+#include <cmath>
 
 namespace LSL {
 namespace Util {
