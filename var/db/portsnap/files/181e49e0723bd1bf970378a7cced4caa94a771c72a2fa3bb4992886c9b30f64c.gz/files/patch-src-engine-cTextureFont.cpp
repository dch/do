--- src/engine/cTextureFont.cpp.orig	Sun Jul  6 22:31:10 2003
+++ src/engine/cTextureFont.cpp	Sun Nov 20 02:33:54 2005
@@ -31,6 +31,7 @@
 #include <stdio.h>
 #include <GL/gl.h>
 #include <GL/glu.h>
+#include <math.h>
 #include "cTextureManager.hpp"
 #include "Debug.hpp"
 //------------------------------------------------------------------------------
