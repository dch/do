--- Opcodes/urandom.c.old	2011-01-30 02:14:59.000000000 -0600
+++ Opcodes/urandom.c	2011-01-30 02:15:08.000000000 -0600
@@ -22,7 +22,6 @@
 */
 
 #include "csdl.h"
-#include <ieee754.h>
 
 typedef struct {
     OPDS    h;
