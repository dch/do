--- InOut/rtalsa.c.orig	2011-12-22 19:41:53.000000000 +0900
+++ InOut/rtalsa.c	2011-12-27 23:53:00.000000000 +0900
@@ -35,9 +35,6 @@
 /* #ifndef _BSD_SOURCE */
 /* #define _BSD_SOURCE 1 */
 /* #endif */
-#include <alloca.h>
-#include <termios.h>
-#include <unistd.h>
 
 #include "csdl.h"
 
