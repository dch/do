--- src/prefs.h.orig	Sat Jul 24 13:17:03 2004
+++ src/prefs.h	Sat Jul 24 13:17:16 2004
@@ -20,7 +20,7 @@
  */
 
 
-#include <linux/soundcard.h>
+#include <sys/soundcard.h>
 
 #define config_filename 	"mixmos"
 
