--- src/client.cc.orig	2009-03-15 04:13:28.000000000 +0000
+++ src/client.cc
@@ -8,6 +8,7 @@
 #include <errno.h>
 #include <stdlib.h>
 #include <string.h>
+#include <unistd.h>
 
 namespace
 {
