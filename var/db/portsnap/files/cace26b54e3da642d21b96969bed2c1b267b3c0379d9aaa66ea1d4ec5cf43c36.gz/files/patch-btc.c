--- btc.c.orig	Sat Oct  2 00:24:02 1993
+++ btc.c	Mon Jul 26 16:40:04 2004
@@ -705,7 +705,7 @@
 /*
  *  GLOBALS
  */
-UINT max_line_length;       /* Length of line in characters   */
+UINT max_line_length,       /* Length of line in characters   */
      num_of_lines_read;     /* Number of lines read from file */
 
 /*
@@ -1583,7 +1583,7 @@
 
 #if FONT == NO_CUSTOM_FONT
     fprintf( outfile, "\
-     ||                 Capitol notes are dotted notes (1.5 x duration)\n\
+     ||                 Capital notes are dotted notes (1.5 x duration)\n\
      ||\n" );
 #endif
 
