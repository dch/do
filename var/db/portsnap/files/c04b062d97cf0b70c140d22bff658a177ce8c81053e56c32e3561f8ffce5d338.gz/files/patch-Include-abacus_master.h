--- Include/abacus/master.h.orig	2014-07-28 09:34:10.000000000 +0200
+++ Include/abacus/master.h	2014-07-28 09:38:07.000000000 +0200
@@ -51,7 +51,6 @@
 #include "abacus/cputimer.h"
 #include "abacus/cowtimer.h"
 #include "abacus/string.h"
-#include "abacus/standardpool.h"
 
 
 class ABA_SUB;
