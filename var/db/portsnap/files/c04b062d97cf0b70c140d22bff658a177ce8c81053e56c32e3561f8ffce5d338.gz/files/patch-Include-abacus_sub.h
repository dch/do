--- Include/abacus/sub.h.orig	2014-07-28 09:37:03.000000000 +0200
+++ Include/abacus/sub.h	2014-07-28 09:37:19.000000000 +0200
@@ -51,6 +51,7 @@
 #include "abacus/buffer.h"
 #include "abacus/vartype.h"
 #include "abacus/cputimer.h"
+#include "abacus/standardpool.h"
 
 class ABA_LPSUB;
 class ABA_TAILOFF;
