--- bhmusers.cpp.orig
+++ bhmusers.cpp
@@ -1,5 +1,6 @@
 #include "bhmusers.h"
-#include <stdio.h>
+#include <cstdio>
+#include <cstdlib>
 #include <cstring>
 #include "expand.h"
 
