--- maps.h.orig	2010-01-14 08:52:26 UTC
+++ maps.h
@@ -23,6 +23,7 @@
 #ifndef _MAPS_INC
 #define _MAPS_INC            /* include guard */
 
+#include <sys/types.h>
 #include "list.h"
 
 /* determine what regions we need */
