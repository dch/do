--- src/libqhullcpp/QhullLinkedList.h.orig	2012-01-26 04:32:05.000000000 +0100
+++ src/libqhullcpp/QhullLinkedList.h	2014-12-19 15:19:26.000000000 +0100
@@ -9,7 +9,7 @@
 #ifndef QHULLLINKEDLIST_H
 #define QHULLLINKEDLIST_H
 
-namespace std { struct bidirectional_iterator_tag; struct random_access_iterator_tag; }
+#include <iterator>
 
 #include "QhullError.h"
 
