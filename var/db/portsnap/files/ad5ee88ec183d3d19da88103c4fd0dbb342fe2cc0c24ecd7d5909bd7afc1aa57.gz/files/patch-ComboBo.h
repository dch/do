--- ComboBo.h.orig	Thu Nov 25 08:11:05 1993
+++ ComboBo.h	Tue Sep 23 20:03:24 1997
@@ -23,7 +23,9 @@
 
 #define XtNselectCallback "selectCallback"
 #define XtNselectMenu "selectMenu"
+#ifndef XtNcancelCallback
 #define XtNcancelCallback "cancelCallback"
+#endif
 #define XtNmargin "margin"
 #define XtNnumberRows "numberRows"
 #define XtNshowDotFiles "showDotFiles"
