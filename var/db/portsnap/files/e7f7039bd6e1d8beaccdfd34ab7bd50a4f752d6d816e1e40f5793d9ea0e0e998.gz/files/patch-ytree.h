--- ytree.h.orig
+++ ytree.h
@@ -14,6 +14,7 @@
 #include <stdio.h>
 #include <ctype.h>
 #include <math.h>
+#include <locale.h>
 
 #ifdef XCURSES
 #include <xcurses.h>
