--- dclib/ccasefolder.cpp.orig	2008-08-12 01:03:30.000000000 +0200
+++ dclib/ccasefolder.cpp	2008-08-12 01:04:03.000000000 +0200
@@ -22,7 +22,7 @@
 #endif
 
 #ifndef ICONV_CONST
-#define ICONV_CONST
+#define ICONV_CONST const
 #endif
 
 /*
