--- srs2.h	2014-01-03 01:01:47.000000000 +0100
+++ srs2.h.new	2014-06-17 16:16:22.880373371 +0200
@@ -20,6 +20,7 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <ctype.h>
+#include <time.h>
 
 #ifndef __BEGIN_DECLS
 #define __BEGIN_DECLS
