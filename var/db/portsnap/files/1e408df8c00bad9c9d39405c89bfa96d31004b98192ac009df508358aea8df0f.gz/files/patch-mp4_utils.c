--- mp4_utils.c.orig	2004-10-17 20:44:51 UTC
+++ mp4_utils.c
@@ -3,7 +3,7 @@
 */
 
 #include "mp4ff.h"
-#include "faad.h"
+#include "neaacdec.h"
 
 #include <gtk/gtk.h>
 #include <stdio.h>
