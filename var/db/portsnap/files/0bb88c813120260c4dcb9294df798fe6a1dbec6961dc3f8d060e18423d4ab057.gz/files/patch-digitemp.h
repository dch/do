--- src/digitemp.h.orig	2008-08-28 06:34:17.000000000 +0200
+++ src/digitemp.h	2011-06-25 12:52:19.000000000 +0200
@@ -18,7 +18,7 @@
    with this program; if not, write to the Free Software Foundation, Inc.,
    59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
    ----------------------------------------------------------------------- */
-#define BANNER_1     "DigiTemp v3.5.0 Copyright 1996-2007 by Brian C. Lane\n"
+#define BANNER_1     "DigiTemp v3.6.0 Copyright 1996-2007 by Brian C. Lane\n"
 #define BANNER_2     "GNU Public License v2.0 - http://www.digitemp.com\n"
 #define BANNER_3     "Compiled for %s\n\n"
 
