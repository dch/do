--- ./fea/data_plane/control_socket/routing_socket.hh.orig	2011-03-16 21:27:46.000000000 +0000
+++ ./fea/data_plane/control_socket/routing_socket.hh	2014-02-26 21:17:13.000000000 +0000
@@ -31,7 +31,7 @@
 
 
 class RoutingSocketObserver;
-struct RoutingSocketPlumber;
+// struct RoutingSocketPlumber;
 
 /**
  * RoutingSocket class opens a routing socket and forwards data arriving
