--- src/interpolate.h~	Tue May 12 05:43:04 1998
+++ src/interpolate.h	Sat May 24 12:03:04 2003
@@ -30,6 +30,7 @@
  */
 
 #include <math.h>
+#define float_t ACM_float_t
 
 typedef float float_t;
 
