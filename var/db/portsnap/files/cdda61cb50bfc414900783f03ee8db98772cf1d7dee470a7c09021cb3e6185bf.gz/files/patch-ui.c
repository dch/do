--- ./ui.c.orig	2010-04-23 13:49:47.000000000 +0200
+++ ./ui.c	2010-04-23 13:49:47.000000000 +0200
@@ -6,7 +6,6 @@
 	Project Page: http://atariarea.krap.pl/stymulator
 	
 	Original ST-Sound GPL library by Arnaud Carre (http://leonard.oxg.free.fr)
-	ALSA (Advanced Linux Sound Architecture) library (http://www.alsa-project.org/)
 
 -----------------------------------------------------------------------------
  *   STYMulator is free software; you can redistribute it and/or modify    *
