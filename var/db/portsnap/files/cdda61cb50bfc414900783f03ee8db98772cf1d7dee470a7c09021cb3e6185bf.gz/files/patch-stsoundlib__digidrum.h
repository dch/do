--- ./stsoundlib/digidrum.h.orig	2010-04-23 13:49:47.000000000 +0200
+++ ./stsoundlib/digidrum.h	2010-04-23 13:50:07.000000000 +0200
@@ -32,6 +32,8 @@
 #ifndef __DIGIDRUM__
 #define __DIGIDRUM__
 
+#define	MAX_DIGIDRUM	40
+
 extern ymu8		*	sampleAdress[];
 extern ymu32		sampleLen[];
 
