--- match.c.orig
+++ match.c
@@ -34,6 +34,8 @@
  *    "awf" copyright notice.]
  */
 
+#include <string.h>
+
 /* match.c: pattern matching routines */
 
 
