--- /dev/null	Fri Aug 25 22:02:50 2000
+++ include/linux/kd.h	Fri Aug 25 22:05:02 2000
@@ -0,0 +1,2 @@
+#include <sys/consio.h>
+#include <sys/kbio.h>
