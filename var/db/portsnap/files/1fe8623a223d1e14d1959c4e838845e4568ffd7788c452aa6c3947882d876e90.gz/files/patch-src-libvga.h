diff -druN svgalib-1.4.2.orig/src/libvga.h src/libvga.h
--- svgalib-1.4.2.orig/src/libvga.h	Fri Aug 25 04:39:39 2000
+++ src/libvga.h	Fri Aug 25 04:39:57 2000
@@ -358,7 +358,7 @@
 
 #else
 
-#define SVGALIB_ACQUIRE_SIG SIGUNUSED
+#define SVGALIB_ACQUIRE_SIG SIGUSR2
 #define SVGALIB_RELEASE_SIG SIGPROF
 
 #endif
