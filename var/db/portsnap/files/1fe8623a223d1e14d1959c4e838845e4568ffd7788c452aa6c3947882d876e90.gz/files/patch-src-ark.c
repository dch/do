--- src/ark.c.orig	Fri Aug 25 05:03:06 2000
+++ src/ark.c	Fri Aug 25 05:03:21 2000
@@ -25,6 +25,7 @@
 #include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
+#include <sys/types.h>
 #include <sys/mman.h>
 #include <signal.h>
 #include "vga.h"
