--- utils/gtf/scitech.h.orig	Fri Aug 25 05:23:32 2000
+++ utils/gtf/scitech.h	Fri Aug 25 05:24:02 2000
@@ -228,7 +228,7 @@
 #endif
 
 /* 32-bit FreeBSD compile environment */
-#elif	defined(__FREEBSD__)
+#elif	defined(__FreeBSD__)
 #ifndef	__32BIT__
 #define __32BIT__
 #endif
