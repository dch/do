--- demos/accel.c.orig	Fri Aug 25 06:13:16 2000
+++ demos/accel.c	Fri Aug 25 06:13:30 2000
@@ -12,7 +12,6 @@
 #include <unistd.h>
 #include <time.h>
 #include <math.h>
-#include <alloca.h>
 #include <string.h>
 #include "vga.h"
 #include "vgagl.h"
