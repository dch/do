--- ./src/vdrivers/svgalib.c.orig	Wed Jun 25 18:06:38 2003
+++ ./src/vdrivers/svgalib.c	Sat Jul  1 16:07:10 2006
@@ -18,7 +18,6 @@
 
 #include <string.h>
 #include <vga.h>
-#include <unistd.h>
 
 #include "libgrx.h"
 #include "grdriver.h"
