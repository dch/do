--- ./test/speedtst.c.orig	Sat May  3 19:45:12 2003
+++ ./test/speedtst.c	Sat Jul  1 16:06:12 2006
@@ -26,7 +26,7 @@
 /*#include <wcdefs.h>*/
 #include <conio.h>
 #else
-#include <values.h>
+#include <limits.h>
 #endif
 #include <math.h>
 #include <time.h>
