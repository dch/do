--- clfsplit.cpp.orig	Tue Jan  8 17:41:53 2002
+++ clfsplit.cpp	Tue Jan  8 17:41:18 2002
@@ -199,7 +199,7 @@
   MAP m;
   FILE *input = stdin;
   bool new_input = false;
-  optind = 0;
+  optind = 1;
   while(-1 != (int_c = getopt(argc, argv, "d:i:f:s:")) )
   {
     switch(char(int_c))
