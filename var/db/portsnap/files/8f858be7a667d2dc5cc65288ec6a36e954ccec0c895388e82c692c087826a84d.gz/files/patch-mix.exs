--- mix.exs.orig	2015-07-05 07:36:59 UTC
+++ mix.exs
@@ -7,8 +7,7 @@ defmodule Calendar.Mixfile do
      version: "0.6.9",
      elixir: "~> 1.1.0 or ~> 1.0.0",
      package: package,
-     description: description,
-     deps: deps]
+     description: description]
   end
 
   def application do
