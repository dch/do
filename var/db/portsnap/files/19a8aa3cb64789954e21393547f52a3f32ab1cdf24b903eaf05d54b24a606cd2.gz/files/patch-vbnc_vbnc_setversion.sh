--- vbnc/vbnc/setversion.sh.orig
+++ vbnc/vbnc/setversion.sh
@@ -1,4 +1,4 @@
-#!/bin/bash -ex
+#!/usr/bin/env bash -ex
 
 VERSION_VB=$1
 VERSION_TMP=version.tmp
