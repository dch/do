--- gnugetopt.c.orig	Thu May 22 08:35:25 2003
+++ gnugetopt.c	Thu May 22 08:35:37 2003
@@ -45,6 +45,7 @@
 #endif
 
 #include <stdio.h>
+#include <string.h>
 
 /* Comment out all this code if we are using the GNU C Library, and are not
    actually compiling the library itself.  This code is part of the GNU C
