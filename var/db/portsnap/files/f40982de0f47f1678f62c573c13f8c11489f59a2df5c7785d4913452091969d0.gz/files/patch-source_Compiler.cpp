--- source/Compiler.cpp.orig	2008-04-07 14:21:12 UTC
+++ source/Compiler.cpp
@@ -33,6 +33,7 @@ Description:
 #include <iomanip>
 #include <algorithm>
 #include <cstring>
+#include <cstdio>
 
 #include "zlib.h"
 
