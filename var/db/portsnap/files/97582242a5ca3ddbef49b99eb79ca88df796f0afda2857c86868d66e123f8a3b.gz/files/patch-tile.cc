--- src/tile.cc.orig
+++ src/tile.cc
@@ -5,6 +5,7 @@
 #include <algorithm>
 #include <stack>
 //#include <stdio.h>
+#include <stdlib.h>
 
 /* 
  * changed<05.02.2003> by Rudolf Polzer: including namespace std (C++)
