--- texi2pod.pl.orig	2013-02-15 14:24:00 UTC
+++ texi2pod.pl
@@ -1,4 +1,4 @@
-#! /usr/bin/perl -w
+#! /usr/local/bin/perl -w
 
 #   Copyright (C) 1999, 2000, 2001 Free Software Foundation, Inc.
 
