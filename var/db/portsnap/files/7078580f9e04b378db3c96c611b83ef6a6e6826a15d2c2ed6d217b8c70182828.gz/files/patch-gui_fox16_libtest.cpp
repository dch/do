--- gui/fox16/libtest.cpp.orig	2010-08-28 13:40:12.000000000 +0000
+++ gui/fox16/libtest.cpp
@@ -1,4 +1,5 @@
 
+#include <unistd.h>
 #ifdef HAVE_CONFIG_H
 # include <config.h>
 #endif
