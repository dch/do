--- xgen.c.orig	1999-07-29 14:00:50.000000000 +0900
+++ xgen.c	2012-10-24 03:05:24.000000000 +0900
@@ -30,6 +30,7 @@
  */
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <string.h>
 #include <X11/Xlib.h>
 #include <X11/xpm.h>
