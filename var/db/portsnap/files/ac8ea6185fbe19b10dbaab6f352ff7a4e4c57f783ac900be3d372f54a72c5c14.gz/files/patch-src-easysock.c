--- src/easysock.c.orig	Fri Mar 17 01:35:39 2006
+++ src/easysock.c	Sun Apr  9 20:50:42 2006
@@ -58,8 +58,8 @@
 #include <sys/socket.h>
 #include <sys/uio.h>
 #include <sys/un.h>
-#include <arpa/inet.h>
 #include <netinet/in.h>
+#include <arpa/inet.h>
 #include <netdb.h>
 #endif
 
