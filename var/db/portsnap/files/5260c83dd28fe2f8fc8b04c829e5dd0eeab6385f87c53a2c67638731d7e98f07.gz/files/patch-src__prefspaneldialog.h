--- ./src/prefspaneldialog.h.orig	2008-04-06 13:47:45.000000000 +0400
+++ ./src/prefspaneldialog.h	2008-04-07 01:12:12.000000000 +0400
@@ -12,7 +12,7 @@
 #ifndef PREFSPANELDIALOG_H
 #define PREFSPANELDIALOG_H
 
-#include <qdialog.h>
+#include <QDialog>
 #include <ui_prefs_panel.h>
 
 
