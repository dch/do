--- mix.exs.orig	2015-07-27 12:54:35 UTC
+++ mix.exs
@@ -7,7 +7,7 @@ defmodule Phoenix.Mixfile do
     [app: :phoenix,
      version: @version,
      elixir: "~> 1.0.2 or ~> 1.1-dev",
-     deps: deps,
+     deps: [],
      package: package,
      docs: [source_ref: "v#{@version}", main: "Phoenix"],
      name: "Phoenix",
