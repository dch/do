--- setup.py.orig	2013-07-31 05:48:36.000000000 +0800
+++ setup.py	2014-10-02 21:37:32.390653346 +0800
@@ -22,7 +22,7 @@
 from setuptools.command import test
 
 REQUIRE = [
-    "python-dateutil>=1.4,<2",
+    "python-dateutil>=1.4",
     "python-gflags>=1.4",
     "pytz>=2010",
     ]
