--- libs/libmythui/mythpainter.cpp.orig	2013-09-18 16:06:08.000000000 -0400
+++ libs/libmythui/mythpainter.cpp	2014-01-22 08:18:40.000000000 -0500
@@ -1,5 +1,6 @@
 #include <stdint.h>
 #include <algorithm>
+#include <cstdlib>
 
 // QT headers
 #include <QRect>
