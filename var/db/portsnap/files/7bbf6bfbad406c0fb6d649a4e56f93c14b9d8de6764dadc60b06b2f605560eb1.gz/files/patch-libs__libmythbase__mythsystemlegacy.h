--- libs/libmythbase/mythsystemlegacy.h.orig	2013-09-18 20:06:08.000000000 +0000
+++ libs/libmythbase/mythsystemlegacy.h	2013-10-18 11:37:16.000000000 +0000
@@ -42,6 +42,7 @@
 
 // C headers
 #include <stdint.h>
+#include <time.h>
 
 #ifdef __cplusplus
 
