#!%%PERL%%

$CONFDIR = "%%CONFDIR%%";

