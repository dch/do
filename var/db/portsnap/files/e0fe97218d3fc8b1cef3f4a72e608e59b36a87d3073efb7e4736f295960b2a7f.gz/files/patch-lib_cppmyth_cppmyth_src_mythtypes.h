--- lib/cppmyth/cppmyth/src/mythtypes.h.orig	2015-03-01 20:42:14 UTC
+++ lib/cppmyth/cppmyth/src/mythtypes.h
@@ -27,6 +27,7 @@
 
 #include <string>
 #include <stdint.h>
+#include <time.h>
 #include <vector>
 #include <map>
 
