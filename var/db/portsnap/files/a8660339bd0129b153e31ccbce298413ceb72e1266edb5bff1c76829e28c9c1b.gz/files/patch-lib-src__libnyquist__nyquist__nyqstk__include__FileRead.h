--- ./lib-src/libnyquist/nyquist/nyqstk/include/FileRead.h.orig	2011-05-04 17:18:48.000000000 +0200
+++ ./lib-src/libnyquist/nyquist/nyqstk/include/FileRead.h	2011-05-04 17:19:13.000000000 +0200
@@ -33,6 +33,7 @@
 #define STK_FILEREAD_H
 
 #include "Stk.h"
+#include <stdio.h>
 
 namespace Nyq
 {
