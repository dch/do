--- include/aacplus.h.orig	2010-11-11 06:27:38.000000000 +0900
+++ include/aacplus.h	2011-10-13 18:19:31.000000000 +0900
@@ -12,7 +12,7 @@

 typedef enum {
 	AACPLUS_INPUT_16BIT = 0,
-	AACPLUS_INPUT_FLOAT,
+	AACPLUS_INPUT_FLOAT
 } aacplusInFormat;


