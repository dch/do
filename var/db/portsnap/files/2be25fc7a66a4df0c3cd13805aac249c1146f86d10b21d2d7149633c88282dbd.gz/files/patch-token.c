--- token.c.orig	Fri Mar 19 17:50:19 1999
+++ token.c	Fri Mar 19 18:09:54 1999
@@ -6,6 +6,7 @@
  */
 
 #include <math.h>
+#include <stdlib.h>
 #include <stdio.h>
 
 #ifdef LCC 
