--- jgraph.c.orig	Fri Mar 19 16:27:09 1999
+++ jgraph.c	Mon Aug  2 16:21:34 1999
@@ -36,6 +36,13 @@
 
   l = (Label) malloc (sizeof(struct label));
   l->label = CNULL;
+  l->x = 0;
+  l->y = 0;
+  l->rotate = 0;
+  l->xmin = 0;
+  l->xmax = 0;
+  l->ymin = 0;
+  l->ymax = 0;
   l->hj = 'c';
   l->vj = 'b';
   l->font = "Times-Roman";
