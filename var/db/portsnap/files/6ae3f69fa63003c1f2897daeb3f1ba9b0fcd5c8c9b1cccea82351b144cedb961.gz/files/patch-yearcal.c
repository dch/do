--- yearcal.c.orig	1998-10-13 18:52:20.000000000 +0200
+++ yearcal.c	2011-07-01 09:45:48.000000000 +0200
@@ -16,7 +16,7 @@
 , "December"
 } ;
 
-void main(argc,argv)
+int main(argc,argv)
 int argc;
 char **argv;
 {
