--- make-compileso.sh.orig	Wed Dec 31 21:00:00 1969
+++ make-compileso.sh	Fri Jun 16 02:05:36 2000
@@ -0,0 +1 @@
+echo exec "$CC $CCSO" -o '�$@�' -c '${1+"$@"}'
