--- charset/dfopen.c.orig	1994-11-29 16:10:29.000000000 +0100
+++ charset/dfopen.c	2011-07-25 20:21:13.000000000 +0200
@@ -1,7 +1,6 @@
 #include "iso646.h"
 #include <stdio.h>
 #include <errno.h>
-#include <malloc.h>
 #include <stdlib.h>	/* TW 941114 */
 #include <memory.h>	/* TW 941114 */
 #include <unistd.h>	/* TW 941114 */
