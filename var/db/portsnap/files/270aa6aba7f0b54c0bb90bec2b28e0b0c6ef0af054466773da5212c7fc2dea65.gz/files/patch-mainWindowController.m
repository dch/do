--- mainWindowController.m.orig	2003-04-05 08:47:02.000000000 +0200
+++ mainWindowController.m	2008-06-16 20:36:29.000000000 +0200
@@ -17,6 +17,7 @@
     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
 
+#include "GNUstepBase/GNUstep.h"
 #include "mainWindowController.h"
 
 @implementation MainWindowController
