--- src/parser/AutoTrainMailMessageReader.cc.orig	2013-11-03 22:30:29.000000000 +0100
+++ src/parser/AutoTrainMailMessageReader.cc	2013-11-03 22:33:21.000000000 +0100
@@ -28,6 +28,7 @@
 //    http://www.cooldevtools.com/qpl.html
 //
 
+#include <cstdlib>
 #include "MailMessage.h"
 #include "AutoTrainMailMessageReader.h"
 
