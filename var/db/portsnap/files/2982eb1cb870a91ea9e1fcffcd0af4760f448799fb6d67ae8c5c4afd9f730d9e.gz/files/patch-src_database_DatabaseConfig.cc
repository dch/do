--- src/database/DatabaseConfig.cc.orig	2013-11-03 21:52:55.000000000 +0100
+++ src/database/DatabaseConfig.cc	2013-11-03 21:53:35.000000000 +0100
@@ -29,6 +29,7 @@
 //
 
 #include <stdexcept>
+#include <cstdlib>
 #include "File.h"
 #include "WordData.h"
 #include "FrequencyDBImpl.h"
