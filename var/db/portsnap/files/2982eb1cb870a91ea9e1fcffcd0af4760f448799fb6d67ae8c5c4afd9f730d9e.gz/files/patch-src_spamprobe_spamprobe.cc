--- src/spamprobe/spamprobe.cc.orig	2013-11-04 20:48:33.000000000 +0100
+++ src/spamprobe/spamprobe.cc	2013-11-04 20:48:51.000000000 +0100
@@ -28,6 +28,7 @@
 //    http://www.cooldevtools.com/qpl.html
 //
 
+#include <cstdlib>
 #include <unistd.h>
 #include <locale.h>
 #include <signal.h>
