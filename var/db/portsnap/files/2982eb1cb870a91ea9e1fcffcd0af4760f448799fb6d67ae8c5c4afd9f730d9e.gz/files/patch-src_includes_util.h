--- src/includes/util.h.orig	2013-11-03 21:42:41.000000000 +0100
+++ src/includes/util.h	2013-11-03 21:42:54.000000000 +0100
@@ -42,6 +42,7 @@
 #include <cassert>
 #include <iostream>
 #include <cstdio>
+#include <cstring>
 #include "Ptr.h"
 #include "Ref.h"
 
