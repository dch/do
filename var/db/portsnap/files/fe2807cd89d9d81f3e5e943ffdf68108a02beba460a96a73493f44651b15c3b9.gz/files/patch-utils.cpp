--- utils.cpp.orig	Tue Feb  1 08:23:17 2005
+++ utils.cpp	Tue Feb  1 08:23:27 2005
@@ -9,6 +9,7 @@
 //#endif
 
 #include <fstream>
+#include <math.h>
 
 #include "utils.h"
 #include "main.h"
