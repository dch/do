--- convert.h.orig	2005-08-14 06:40:58.000000000 +0400
+++ convert.h	2015-03-27 02:57:05.826432000 +0300
@@ -5,6 +5,7 @@
 #include <iostream>
 #include <sstream>
 #include <string>
+#include <typeinfo>
 
 #include "exceptions.h"
 #include "unicode.h"
