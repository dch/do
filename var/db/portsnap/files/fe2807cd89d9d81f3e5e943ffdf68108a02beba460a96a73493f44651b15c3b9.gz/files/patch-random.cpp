--- random.cpp.orig
+++ random.cpp
@@ -1,3 +1,5 @@
+#include "sys/time.h"
+
 #include "random.h"
 #include "utils.h"

