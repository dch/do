--- unicode.cpp.orig	2005-08-14 06:40:58.000000000 +0400
+++ unicode.cpp	2015-03-27 02:57:47.513365000 +0300
@@ -1,5 +1,6 @@
 #include <wchar.h>
 #include <stdlib.h>
+#include <string.h>
 #ifdef WIN32
 #include <windows.h>
 #endif
