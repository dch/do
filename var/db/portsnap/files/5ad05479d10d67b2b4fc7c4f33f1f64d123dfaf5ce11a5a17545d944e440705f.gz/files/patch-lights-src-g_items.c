--- ./lights/src/g_items.c.orig	Sun Feb  4 16:20:11 2007
+++ ./lights/src/g_items.c	Sun Feb  4 16:20:32 2007
@@ -1794,6 +1794,7 @@
 		60,                   /*ATTILA respwan after 60 secs*/ 
 		NULL,
 		0,
+		0,
 		NULL,
 		0,
 /* precache */ "hover/hovidle1.wav items/damage.wav items/damage2.wav items/damage3.wav"
