--- tx/TXImage.cxx.orig	2008-10-16 08:16:21.000000000 -0700
+++ tx/TXImage.cxx	2013-10-29 09:32:04.015562191 -0700
@@ -21,6 +21,7 @@
 
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <strings.h>
 #include <sys/types.h>
 #include <sys/ipc.h>
