--- xc/config/util/printver.c.orig	2003-02-26 10:21:33.000000000 +0100
+++ xc/config/util/printver.c	2008-03-16 10:07:56.000000000 +0100
@@ -8,6 +8,7 @@
 /* $XFree86: xc/config/util/printver.c,v 1.2 2003/02/26 09:21:33 dawes Exp $ */
 
 #include <stdio.h>
+#include <stdlib.h>
 #include "xf86Version.h"
 #include "xf86Date.h"
 
