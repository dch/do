--- x0vncserver/Image.cxx.orig	2008-10-16 08:16:21.000000000 -0700
+++ x0vncserver/Image.cxx	2013-10-29 09:34:58.346041892 -0700
@@ -21,6 +21,7 @@
 
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <sys/types.h>
 #include <sys/ipc.h>
 #include <sys/shm.h>
