--- LightGLAnimate.c.orig	Tue Nov 25 00:21:36 2003
+++ LightGLAnimate.c	Tue Nov 25 00:24:22 2003
@@ -25,6 +25,7 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
+#include <sys/types.h>
 #include "Light.h"
 
 #ifdef  _WITH_OPENGL
