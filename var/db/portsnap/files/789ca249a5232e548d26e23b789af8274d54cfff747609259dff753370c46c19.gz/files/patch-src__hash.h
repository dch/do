--- src/hash.h.orig	Tue Jul 15 16:53:16 2003
+++ src/hash.h	Tue Jul 15 16:53:49 2003
@@ -1,6 +1,8 @@
 #ifndef _HASH_H
 #define _HASH_H
 
+#include <sys/types.h>
+
 /*
 ------------------------------------------------------------------------
 Type Definitions
