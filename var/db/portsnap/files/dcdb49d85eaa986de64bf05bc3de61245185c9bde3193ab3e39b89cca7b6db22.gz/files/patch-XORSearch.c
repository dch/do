--- XORSearch.c.orig	Tue Dec 18 07:27:32 2007
+++ XORSearch.c	Tue Dec 18 07:27:38 2007
@@ -20,7 +20,6 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <sys/stat.h>
-#include <malloc.h>
 #include <string.h>
 #include <ctype.h>
 #include <limits.h>
