--- mix.exs.orig	2015-07-09 05:06:08 UTC
+++ mix.exs
@@ -5,7 +5,6 @@ defmodule Maru.Mixfile do
     [ app: :maru,
       version: "0.4.0",
       elixir: "~> 1.0.0",
-      deps: deps,
       description: "Elixir copy of grape for creating REST-like APIs.",
       source_url: "https://github.com/falood/maru",
       package: package,
