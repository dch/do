--- sources/medit.h.orig	2007-11-30 16:31:20.000000000 +0100
+++ sources/medit.h	2010-10-17 14:53:46.000000000 +0200
@@ -88,4 +88,4 @@
 
 
 
-#endif
\ No newline at end of file
+#endif
