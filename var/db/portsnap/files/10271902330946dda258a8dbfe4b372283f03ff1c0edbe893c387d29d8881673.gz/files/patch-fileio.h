--- fileio.h.orig	Mon Jan 12 09:13:04 1998
+++ fileio.h	Fri Mar 23 13:55:39 2001
@@ -28,7 +28,7 @@
 #ifdef LINUX
 #  define PGP_SYSTEM_DIR "/usr/lib/pgp/"
 #else
-#  define PGP_SYSTEM_DIR "/usr/local/lib/pgp/"
+#  define PGP_SYSTEM_DIR "/usr/local/lib/pgpin/"
 #endif
 #define FOPRBIN		"r"
 #define FOPRTXT		"r"
