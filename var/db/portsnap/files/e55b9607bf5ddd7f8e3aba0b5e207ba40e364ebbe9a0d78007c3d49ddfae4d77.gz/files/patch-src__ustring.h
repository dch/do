--- src/ustring.h.orig
+++ src/ustring.h
@@ -14,6 +14,7 @@
 
 #include "config.h"
 
+#include <cstring>
 #include <iostream>
 #include <map>
 #include <ext/hash_map>
