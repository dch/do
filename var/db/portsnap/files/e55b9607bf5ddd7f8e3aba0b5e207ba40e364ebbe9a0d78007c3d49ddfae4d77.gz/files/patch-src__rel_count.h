--- src/rel_count.h.orig
+++ src/rel_count.h
@@ -13,6 +13,7 @@
 #define  SSD_REL_COUNT_H
 #include "config.h"
 #include "rel_eqclass.h"
+#include <climits>
 #include <vector>
 #include <ext/hash_map>
 
