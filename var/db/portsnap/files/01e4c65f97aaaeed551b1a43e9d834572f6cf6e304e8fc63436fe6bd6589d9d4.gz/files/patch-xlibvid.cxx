--- ./xlibvid.cxx.orig	2008-03-03 23:09:06.000000000 +0800
+++ ./xlibvid.cxx	2008-03-03 23:09:16.000000000 +0800
@@ -88,6 +88,7 @@
 #include <sys/time.h>
 #include <unistd.h>
 #include <ptlib.h>
+#include <ptlib/video.h>
 #include <string.h>
 #include "xlibvid.h"
 
