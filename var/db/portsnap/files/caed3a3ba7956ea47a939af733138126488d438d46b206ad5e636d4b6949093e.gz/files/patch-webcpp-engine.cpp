--- webcpp/engine.cpp.orig	2007-04-02 10:21:46.000000000 +0400
+++ webcpp/engine.cpp	2007-04-02 10:27:11.000000000 +0400
@@ -1005,7 +1005,7 @@
 </tr><tr><td colspan=6>\n\
 <a href=\"http://webcpp.sf.net\"><center><b>\
 <font color=#ffffff>web c plus plus</font></b></center>\n\
-</a></td></tr>\n\</table>\n<br>\n</center>";
+</a></td></tr>\n</table>\n<br>\n</center>";
 
 		*IO << made;
 	}
