--- libs/pbd/pathscanner.cc.orig
+++ libs/pbd/pathscanner.cc
@@ -21,6 +21,7 @@
 #include <cstdlib>
 #include <cstdio>
 #include <cstring>
+#include <climits>
 #include <vector>
 #include <dirent.h>
 
