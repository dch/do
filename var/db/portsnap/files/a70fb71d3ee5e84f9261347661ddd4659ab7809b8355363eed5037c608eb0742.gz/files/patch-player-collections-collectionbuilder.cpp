--- player/collections/collectionbuilder.cpp.orig	2010-05-18 02:04:47.000000000 +0800
+++ player/collections/collectionbuilder.cpp	2010-05-18 18:09:23.000000000 +0800
@@ -22,9 +22,9 @@
 #include "collectionmodel.h"
 #include "databasemanager.h"
 
-#include <taglib/fileref.h>
-#include <taglib/tag.h>
-#include <taglib/tstring.h>
+#include <fileref.h>
+#include <tag.h>
+#include <tstring.h>
 
 #include <QDebug>
 
