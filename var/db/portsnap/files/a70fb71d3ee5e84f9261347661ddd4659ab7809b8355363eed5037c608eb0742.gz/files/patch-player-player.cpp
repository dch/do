--- player/player.cpp.orig	2010-05-18 02:04:47.000000000 +0800
+++ player/player.cpp	2010-05-18 18:07:34.000000000 +0800
@@ -27,9 +27,9 @@
 #include <phonon/AudioOutput>
 #include <phonon/MediaSource>
 
-#include <taglib/fileref.h>
-#include <taglib/tag.h>
-#include <taglib/tstring.h>
+#include <fileref.h>
+#include <tag.h>
+#include <tstring.h>
 
 Player::Player()
 {
