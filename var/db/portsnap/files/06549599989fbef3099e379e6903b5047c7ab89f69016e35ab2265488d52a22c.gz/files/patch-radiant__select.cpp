--- radiant/select.cpp.orig
+++ radiant/select.cpp
@@ -28,6 +28,7 @@ Foundation, Inc., 51 Franklin St, Fifth 
 #include "iundo.h"
 
 #include <vector>
+#include <stdlib.h>
 
 #include "stream/stringstream.h"
 #include "shaderlib.h"
