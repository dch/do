--- libs/cmdlib/cmdlib.cpp.orig
+++ libs/cmdlib/cmdlib.cpp
@@ -27,6 +27,7 @@ Foundation, Inc., 51 Franklin St, Fifth 
 
 #include <string.h>
 #include <stdio.h>
+#include <stdlib.h>
 
 #include "string/string.h"
 #include "os/path.h"
