--- ./libs/math/vector.h.orig	Fri Feb 10 19:01:20 2006
+++ ./libs/math/vector.h	Tue Feb 21 12:29:34 2006
@@ -25,7 +25,7 @@
 /// \file
 /// \brief Vector data types and related operations.
 
-#if 0
+#if 1
 
 #define	lrint(dbl)		((int)((dbl) + 0.5))
 #define	lrintf(flt)		((int)((flt) + 0.5))
