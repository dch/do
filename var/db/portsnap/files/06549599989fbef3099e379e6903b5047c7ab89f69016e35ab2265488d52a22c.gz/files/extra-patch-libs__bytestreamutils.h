--- libs/bytestreamutils.h.orig	Fri Feb 10 19:01:20 2006
+++ libs/bytestreamutils.h	Tue Feb 21 12:32:25 2006
@@ -39,7 +39,7 @@
 #define	__USE_ISOC9X	1
 #define	__USE_ISOC99	1
 
-#include <stdint.h>
+#include <inttypes.h>
 
 #endif
 
