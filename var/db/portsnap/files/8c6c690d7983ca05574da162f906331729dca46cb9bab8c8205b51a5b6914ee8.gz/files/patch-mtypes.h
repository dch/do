--- mtypes.h.orig	Sat Aug  7 18:19:37 1999
+++ mtypes.h	Thu Jun  1 02:43:05 2000
@@ -11,2 +11,4 @@
 
+#include "endian.h"
+
 typedef unsigned char byte;
