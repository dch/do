--- tool.c.orig	Sat May  6 23:50:17 2000
+++ tool.c	Thu Jun  1 02:43:09 2000
@@ -19,6 +19,7 @@
 #include "video.h"
 #include "tool.h"
 #include "system.h"
+#include "endian.h"
 
 unsigned long system_flags;
 
