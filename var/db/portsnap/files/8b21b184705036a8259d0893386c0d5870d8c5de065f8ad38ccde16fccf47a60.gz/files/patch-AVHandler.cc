--- src/AVHandler.cc.orig	2008-08-24 18:14:47.000000000 +0200
+++ src/AVHandler.cc	2009-02-10 09:15:25.000000000 +0100
@@ -24,6 +24,7 @@
 
 #include "AVHandler.h"
 
+#include <stdlib.h>
 #include <string>
 
 #ifdef _MSC_VER
