--- src/API_generated/oyProfile_s.h.orig	2013-01-19 14:14:14.000000000 +0400
+++ src/API_generated/oyProfile_s.h	2013-04-30 18:50:50.999894240 +0400
@@ -31,6 +31,7 @@
 
 
 
+#include <inttypes.h>
 #include <icc34.h>
   
 #include <oyranos_object.h>
