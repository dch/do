--- apps/xsplay.cc.orig	2001-02-20 20:04:07.000000000 +0100
+++ apps/xsplay.cc	2013-09-23 12:11:46.000000000 +0200
@@ -29,7 +29,7 @@
 #include <fcntl.h>
 #include <string.h>
 #include <unistd.h>
-#include <iostream.h>
+#include <iostream>
 #include <iomanip.h>
 
 #include "mpegsound.h"
