--- ./debugger/src/debug.c.orig	2012-06-16 14:42:46.000000000 +0000
+++ ./debugger/src/debug.c	2012-09-21 14:55:31.192392925 +0000
@@ -37,7 +37,6 @@
 
 #include <string.h>
 #include <unistd.h>
-#include <pty.h>
 #include <gtk/gtk.h>
 #include <gdk/gdkkeysyms.h>
 #include <vte/vte.h>
