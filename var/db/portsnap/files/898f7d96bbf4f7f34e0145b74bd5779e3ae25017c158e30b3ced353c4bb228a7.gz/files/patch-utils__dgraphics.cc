--- ./utils/dgraphics.cc.orig	2009-06-10 07:32:20.000000000 +0900
+++ ./utils/dgraphics.cc	2009-06-17 17:46:19.000000000 +0900
@@ -25,7 +25,7 @@
 
 #include <SDL/SDL.h>
 #include <SDL/SDL_gfxPrimitives.h>
-#include <SDL/SDL_image.h>
+//#include <SDL/SDL_image.h>
 #include <SDL/SDL_imageFilter.h>
 #include <SDL/SDL_rotozoom.h>
 
