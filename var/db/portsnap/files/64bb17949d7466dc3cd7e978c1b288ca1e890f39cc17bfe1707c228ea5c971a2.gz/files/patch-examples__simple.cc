--- examples/simple.cc.orig	Tue Mar 13 23:42:21 2001
+++ examples/simple.cc	Sun Dec 22 03:09:56 2002
@@ -30,6 +30,7 @@
 #include <regexx.hh>
 
 using namespace regexx;
+using namespace std;
 
 //
 // This is the function to pass to replace() in
