--- src/regexx.hh.orig	2013-11-15 21:02:42.000000000 +0900
+++ src/regexx.hh	2013-11-15 21:03:03.000000000 +0900
@@ -29,6 +29,7 @@
 #ifndef REGEXX_HH
 #define REGEXX_HH
 
+#include <cstdlib>
 #include <string>
 #include <vector>
 #include <split.hh>
