--- vaulter.cc.orig	Wed Mar 24 05:03:42 2004
+++ vaulter.cc	Sat Apr  3 21:24:37 2004
@@ -4,6 +4,7 @@
 #include <vector>
 #include <map>
 #include <string>
+#include <cassert>
 
 #include "debug.h"
 #include "error.h"
