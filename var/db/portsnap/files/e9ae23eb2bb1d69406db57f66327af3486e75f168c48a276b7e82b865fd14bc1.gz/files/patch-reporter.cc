--- reporter.cc.orig	Thu Mar 25 00:28:09 2004
+++ reporter.cc	Sat Apr  3 21:26:51 2004
@@ -4,6 +4,7 @@
 #include <string>
 #include <vector>
 #include <algorithm>
+#include <cassert>
 
 #include "debug.h"
 #include "error.h"
