--- src/rtperrors.h.orig	2011-08-29 22:43:27.000000000 +0900
+++ src/rtperrors.h	2012-09-24 22:25:22.000000000 +0900
@@ -39,6 +39,7 @@
 #define RTPERRORS_H
 
 #include "rtpconfig.h"
+#include <cstdio>
 #include <string>
 
 namespace jrtplib
