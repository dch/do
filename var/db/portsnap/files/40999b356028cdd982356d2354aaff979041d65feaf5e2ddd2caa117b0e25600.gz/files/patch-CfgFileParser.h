--- CfgFileParser.h.bak	2010-07-31 14:18:50.529980803 +0200
+++ CfgFileParser.h	2010-07-31 14:18:59.977448567 +0200
@@ -24,7 +24,6 @@
 #include "config.h"
 
 #include <sys/types.h>
-#include <regex.h>
 #include <iostream>
 #include <fstream>
 #include <string>
