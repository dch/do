--- tests/core/test_02.c.orig	2015-06-11 18:06:20 UTC
+++ tests/core/test_02.c
@@ -15,8 +15,6 @@
 
 #include "xo.h"
 
-#include "xo_humanize.h"
-
 int
 main (int argc, char **argv)
 {
