--- explode/morefds.c.orig	1991-07-13 06:11:48.000000000 +0200
+++ explode/morefds.c	2011-05-12 16:13:29.000000000 +0200
@@ -1,4 +1,4 @@
-int
+void
 morefds()
 {
 }
--- relay/morefds.c.orig	1993-03-13 07:07:14.000000000 +0100
+++ relay/morefds.c	2011-05-12 16:13:37.000000000 +0200
@@ -1,3 +1,4 @@
+void
 morefds()
 {
 }
