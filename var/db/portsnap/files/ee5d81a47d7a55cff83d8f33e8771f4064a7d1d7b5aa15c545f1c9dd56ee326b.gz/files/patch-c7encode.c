--- batch/c7encode.c.orig	1989-02-21 01:04:56.000000000 +0100
+++ batch/c7encode.c	2011-05-12 15:10:12.000000000 +0200
@@ -1,4 +1,5 @@
 #include <stdio.h>
+#include <stdlib.h>
 
 #ifdef SCCSID
 static char	*SccsId = "@(#)encode.c	1.3	5/15/85";
