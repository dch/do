--- inject/defaults.c.orig	1995-01-02 22:48:38.000000000 +0100
+++ inject/defaults.c	2011-05-12 15:31:22.000000000 +0200
@@ -3,6 +3,7 @@
  */
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <ctype.h>
 #include <string.h>
 #include <pwd.h>
