--- util/now.c.orig	1995-04-28 02:51:46.000000000 +0200
+++ util/now.c	2011-05-12 14:52:23.000000000 +0200
@@ -5,6 +5,7 @@
 #include <sys/types.h>
 #include <stdio.h>
 #include <stdlib.h>
+#include <string.h>
 #include <time.h>
 #include "libc.h"
 
