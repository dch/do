--- inject/actflag.c.orig	1993-08-22 02:52:27.000000000 +0200
+++ inject/actflag.c	2011-05-12 15:29:52.000000000 +0200
@@ -3,6 +3,7 @@
  */
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <string.h>
 #include <sys/types.h>
 #include "news.h"
