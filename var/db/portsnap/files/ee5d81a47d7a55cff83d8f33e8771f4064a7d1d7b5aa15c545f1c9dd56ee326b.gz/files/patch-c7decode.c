--- input/c7decode.c.orig	1989-02-21 23:57:32.000000000 +0100
+++ input/c7decode.c	2011-05-12 15:32:27.000000000 +0200
@@ -1,4 +1,5 @@
 #include <stdio.h>
+#include <stdlib.h>
 
 /*
  * This program is the inverse of encode
