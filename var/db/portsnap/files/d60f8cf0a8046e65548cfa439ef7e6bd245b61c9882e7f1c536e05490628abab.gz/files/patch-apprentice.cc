--- src/apprentice.cc.orig
+++ src/apprentice.cc
@@ -32,6 +32,8 @@
 #include "moves.h"
 #include "gma.h"
 
+using std::string;
+
 #define BOARD_SIZE 50
 #define MAX_DEPTH 2
 
