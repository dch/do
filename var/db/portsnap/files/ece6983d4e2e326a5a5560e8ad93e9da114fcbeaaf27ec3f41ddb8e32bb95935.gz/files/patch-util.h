--- ./util.h.orig	2003-09-16 01:37:19.000000000 +0200
+++ ./util.h	2014-02-18 11:11:32.989336888 +0100
@@ -30,6 +30,6 @@
 #ifndef _UTIL_H_
 #define _UTIL_H_
 
-char *memmem(const char *, int, const char *, int);
+char *memmemory(const char *, int, const char *, int);
 
 #endif
