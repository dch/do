--- aquarobot/MatrixMy.cpp.orig
+++ aquarobot/MatrixMy.cpp
@@ -38,7 +38,7 @@
 // Constructor
 // **************************************************************************
 //MatrixMy::MatrixMy(int r = 4, int c = 4)
-MatrixMy::MatrixMy(int r = 3, int c = 3)
+MatrixMy::MatrixMy(int r, int c)
 {
   row = r;
   column = c;
