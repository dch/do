--- include/defines.h.orig      Mon Jul 28 12:41:58 2003
+++ include/defines.h   Mon Jul 28 12:42:27 2003
@@ -45,7 +45,7 @@
 
 #define DEFAULT_MAX_REUSE	0
 
-#define DEFAULT_CONFIG_FILE ".imapproxy"
+#define DEFAULT_CONFIG_FILE "/usr/local/etc/imapproxy.conf"
 #define VERSION "v0.9-3"
 #define PROGNAME "ImapProxy"
 #define AUTHOR "Steven Van Acker <imapproxy@kuleuven.net>"
