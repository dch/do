--- tests/test-mbox.c.orig	2011-03-07 18:09:21 UTC
+++ tests/test-mbox.c
@@ -32,6 +32,7 @@
 #include <fcntl.h>
 #include <time.h>
 
+#include <config.h>
 #include <gmime/gmime.h>
 
 #include "testsuite.h"
