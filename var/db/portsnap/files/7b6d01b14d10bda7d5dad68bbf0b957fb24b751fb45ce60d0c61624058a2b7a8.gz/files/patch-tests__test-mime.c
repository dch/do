--- tests/test-mime.c.orig	2011-03-07 18:09:21 UTC
+++ tests/test-mime.c
@@ -27,6 +27,7 @@
 #include <string.h>
 #include <ctype.h>
 
+#include <config.h>
 #include <gmime/gmime.h>
 
 #include "testsuite.h"
