--- conv.c.orig
+++ conv.c
@@ -1,4 +1,5 @@
 #include <stdio.h>
+#include <stdlib.h>
 
 #define TRUE (1)
 #define FALSE (0)
