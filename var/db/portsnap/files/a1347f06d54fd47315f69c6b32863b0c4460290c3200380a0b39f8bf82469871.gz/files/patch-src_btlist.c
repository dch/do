--- src/btlist.c.orig
+++ src/btlist.c
@@ -13,6 +13,7 @@

 #include "config.h"

+#include <sys/types.h>
 #include <openssl/sha.h>
 #include <stdlib.h>
 #include <string.h>
