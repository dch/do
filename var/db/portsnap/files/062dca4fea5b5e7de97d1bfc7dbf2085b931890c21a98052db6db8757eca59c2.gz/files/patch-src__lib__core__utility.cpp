--- ./src/lib/core/utility.cpp.orig	2013-12-24 19:36:58.000000000 +0200
+++ ./src/lib/core/utility.cpp	2013-12-24 19:37:26.000000000 +0200
@@ -22,6 +22,7 @@
                                                                 **********(*)*/
 
 #include "utility.h"
+#include <cstdlib>
 
 
 /** Convert string to lower case
