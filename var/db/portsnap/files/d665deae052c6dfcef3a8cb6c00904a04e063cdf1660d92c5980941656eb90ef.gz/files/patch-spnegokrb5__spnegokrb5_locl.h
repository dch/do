--- spnegokrb5/spnegokrb5_locl.h.orig	2008-01-27 20:59:03.000000000 +0000
+++ spnegokrb5/spnegokrb5_locl.h	2008-01-27 20:59:19.000000000 +0000
@@ -1,6 +1,7 @@
 #include <stdlib.h>
 #include <errno.h>
 #include <string.h>
+#include <sys/types.h>
 
 #include "config.h"
 
