--- aboutEZFM.h.orig	Fri Aug 29 17:42:25 2003
+++ aboutEZFM.h	Fri Aug 29 17:42:55 2003
@@ -24,9 +24,9 @@
  *************************************************************************/
 
 static char  *ezfmInfoString = 
-"
-  Copyright (C) 1998   Maorong Zou
-
-  Please report bugs to Maorong Zou <mzou@math.utexas.edu>
+"\n\
+  Copyright (C) 1998   Maorong Zou\n\
+\n\
+  Please report bugs to Maorong Zou <mzou@math.utexas.edu>\n\
 ";
 
