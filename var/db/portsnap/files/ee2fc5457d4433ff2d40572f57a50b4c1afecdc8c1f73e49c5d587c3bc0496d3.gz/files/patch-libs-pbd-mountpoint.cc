--- libs/pbd/mountpoint.cc.orig
+++ libs/pbd/mountpoint.cc
@@ -19,7 +19,7 @@
 */
 
 #include <cstdio>
-#include <cstring>
+#include <cstdlib>
 #include <string>
 #include <cstring>
 #include <limits.h>
