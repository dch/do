--- src/pashut.c.orig	Sat Feb 25 00:55:09 2006
+++ src/pashut.c	Sun Feb 26 03:15:23 2006
@@ -24,6 +24,7 @@
 #include "pabar.h"
 #include "pafont.h"
 #include "pashut.h"
+#include "signals.h"
 
 
 static void shut_all(void *);
