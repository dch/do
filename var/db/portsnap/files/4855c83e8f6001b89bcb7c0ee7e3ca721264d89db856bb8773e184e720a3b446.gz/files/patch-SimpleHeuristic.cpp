--- SimpleHeuristic.cpp.orig	2004-01-01 05:21:53.000000000 +0300
+++ SimpleHeuristic.cpp	2013-09-13 20:21:14.435230147 +0400
@@ -31,6 +31,8 @@
 
 
 // Header Files #############################################################
+#include <stdio.h>
+#include <stdlib.h> // for exit()
 #include "SimpleHeuristic.h"
 
 // Macros ###################################################################
