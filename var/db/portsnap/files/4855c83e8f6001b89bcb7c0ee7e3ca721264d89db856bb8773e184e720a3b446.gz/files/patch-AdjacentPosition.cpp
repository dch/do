--- AdjacentPosition.cpp.orig	2004-01-04 09:19:04.000000000 +0300
+++ AdjacentPosition.cpp	2013-09-13 20:22:10.991226348 +0400
@@ -32,6 +32,7 @@
 
 // Header Files #############################################################
 #include <stdio.h>
+#include <stdlib.h> // for exit()
 
 #include "AdjacentPosition.h"
 
