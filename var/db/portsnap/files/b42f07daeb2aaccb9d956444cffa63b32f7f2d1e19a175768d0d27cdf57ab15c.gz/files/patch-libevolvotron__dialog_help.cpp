--- libevolvotron/dialog_help.cpp.orig
+++ libevolvotron/dialog_help.cpp
@@ -45,10 +45,10 @@
 "    Esc - Returns to normal mode from full-screen/menu-hidden mode."
 "  </li>"
 "  <li>"
-"    R - Reset (reset mutation paramters and locks)"
+"    R - Reset (reset mutation parameters and locks)"
 "  </li>"
 "  <li>"
-"    T - Restart (preserve mutation paramters and locks)"
+"    T - Restart (preserve mutation parameters and locks)"
 "  </li>"
 "  <li>"
 "    X - Remix (randomize function weights and restart)"
