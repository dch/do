--- ./util/fnrec.sh.orig	2010-06-29 21:31:33.000000000 +0200
+++ ./util/fnrec.sh	2010-08-07 16:16:04.000000000 +0200
@@ -1,4 +1,4 @@
-#!/bin/bash
+#!/bin/sh
 #
 # Copyright (C) 2010 Stefan Hajnoczi <stefanha@gmail.com>.
 #
