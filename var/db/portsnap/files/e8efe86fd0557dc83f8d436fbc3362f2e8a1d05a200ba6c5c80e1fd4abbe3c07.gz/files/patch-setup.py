--- setup.py.orig	2014-10-06 12:36:29 UTC
+++ setup.py
@@ -26,7 +26,7 @@
     ('kaa.imlib2', '\"svn co svn://svn.freevo.org/kaa/trunk/ kaa\"' ),
     ('BeautifulSoup', 'http://www.crummy.com/software/BeautifulSoup/' ),
     ('pygame', 'http://www.pygame.org'),
-    ('Image', 'http://www.pythonware.com/products/pil/'),
+    ('PIL', 'http://www.pythonware.com/products/pil/'),
     ('twisted', 'http://www.twistedmatrix.com/'),
     ('zope.interface', 'http://www.zope.org/Products/ZopeInterface'),
     ('twisted.web.microdom', 'http://www.twistedmatrix.com/'),
