--- dcmtk/ofstd/libsrc/oftime.cc.orig	2006-03-08 09:25:25 UTC
+++ dcmtk/ofstd/libsrc/oftime.cc
@@ -35,6 +35,7 @@
 
 #define INCLUDE_CSTDIO
 #define INCLUDE_CTIME
+#define INCLUDE_OSTREAM
 #include "ofstdinc.h"
 
 BEGIN_EXTERN_C
