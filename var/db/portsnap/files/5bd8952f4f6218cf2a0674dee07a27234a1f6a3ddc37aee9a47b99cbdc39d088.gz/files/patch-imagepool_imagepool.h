--- imagepool/imagepool.h.orig	2010-08-23 17:14:59.000000000 +0200
+++ imagepool/imagepool.h	2010-08-23 17:15:08.000000000 +0200
@@ -36,6 +36,7 @@
 
 #include <glibmm/slisthandle.h>
 #include <string>
+#include <libintl.h>
 
 
 class DcmDataset;
