--- configuration/aconfiguration.cpp.orig	2010-07-26 18:34:00.000000000 +0000
+++ configuration/aconfiguration.cpp	2010-07-26 18:34:14.000000000 +0000
@@ -27,6 +27,7 @@
 */
 
 #include "aconfiguration.h"
+#include <libintl.h>
 
 namespace Aeskulap {
 
