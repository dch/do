--- unix2dos.c.orig	2001-05-23 01:58:39.000000000 +0200
+++ unix2dos.c	2014-01-27 22:41:13.000000000 +0100
@@ -1,4 +1,5 @@
 #include <stdio.h>
+#include <stdlib.h>
 #include <string.h>
 #include <unistd.h>
 #include <sys/types.h>
