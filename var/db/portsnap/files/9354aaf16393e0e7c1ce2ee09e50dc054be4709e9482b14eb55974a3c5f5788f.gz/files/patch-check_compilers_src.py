--- check_compilers_src.py.orig	2013-12-19 15:44:50.000000000 +0100
+++ check_compilers_src.py	2013-12-28 15:09:39.000000000 +0100
@@ -109,6 +109,9 @@
 You must choose another compiler or change the optimization level.
 You can cancel now or make the changes later in the config.txt file of
 Code_Aster and rebuild it.
+
+About volatile patch:
+   see http://www.code-aster.org/forum2/viewtopic.php?pid=40694#p40694
 -------------------------------------------------------------------------------
 
 """,
