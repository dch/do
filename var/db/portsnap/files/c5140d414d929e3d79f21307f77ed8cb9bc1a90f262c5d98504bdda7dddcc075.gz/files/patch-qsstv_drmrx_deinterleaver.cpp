--- qsstv/drmrx/deinterleaver.cpp.orig	2014-12-06 14:41:00 UTC
+++ qsstv/drmrx/deinterleaver.cpp
@@ -30,7 +30,6 @@
 
 #include <stdio.h>
 #include <stdlib.h>
-#include <malloc.h>
 #include <math.h>
 int *deinterleaver(int xinA, int tA, int xinB, int tB)
 {
