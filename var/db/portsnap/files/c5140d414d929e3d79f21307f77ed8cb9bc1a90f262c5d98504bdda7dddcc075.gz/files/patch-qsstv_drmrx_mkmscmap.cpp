--- qsstv/drmrx/mkmscmap.cpp.orig	2014-12-06 14:41:00 UTC
+++ qsstv/drmrx/mkmscmap.cpp
@@ -32,7 +32,6 @@
 #include <stdlib.h>
 #include <sys/types.h>
 #include <math.h>
-#include <malloc.h>
 #include "drmdefs.h"
 #include "structtemplates.h"
 #include "drmproto.h"
