--- qsstv/drmrx/channeldecode.cpp.orig	2014-12-06 14:41:00 UTC
+++ qsstv/drmrx/channeldecode.cpp
@@ -29,7 +29,6 @@
 #include <stdlib.h>
 #include <sys/types.h>
 #include <math.h>
-#include <malloc.h>
 #include <float.h>
 #include "structtemplates.h"
 #include "drmproto.h"
