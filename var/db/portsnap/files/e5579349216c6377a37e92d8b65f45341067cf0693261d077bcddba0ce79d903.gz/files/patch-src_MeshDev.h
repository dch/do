--- src/MeshDev.h.orig	2013-09-26 18:00:27.000000000 +0200
+++ src/MeshDev.h	2013-09-26 18:00:43.000000000 +0200
@@ -30,7 +30,6 @@
 // C Standard Library
 #include <math.h>		// sqrt, ceil
 #include <stdlib.h>		// EXIT_SUCCESS, EXIT_FAILURE
-#include <sys/timeb.h>	// timeb, ftime
 #include <time.h>	    // time
 
 // Use C++ Standard Library namespace
