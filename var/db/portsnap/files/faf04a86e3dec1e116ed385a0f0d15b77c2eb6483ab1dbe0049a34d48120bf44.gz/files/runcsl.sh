#! /bin/sh

exec /usr/local/share/reduce/reduce $*

