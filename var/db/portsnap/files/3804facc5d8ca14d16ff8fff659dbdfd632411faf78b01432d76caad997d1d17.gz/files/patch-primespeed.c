--- primespeed.c.orig	2009-03-27 09:17:41.000000000 -0300
+++ primespeed.c	2009-03-27 09:18:54.000000000 -0300
@@ -1,3 +1,5 @@
+#include <stdio.h>
+#include <stdlib.h>
 #include "timing.h"
 #include "primegen.h"
 #include "primegen_impl.h"
