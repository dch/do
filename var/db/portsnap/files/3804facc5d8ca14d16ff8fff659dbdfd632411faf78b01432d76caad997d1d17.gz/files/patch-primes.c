--- primes.c.orig	2009-03-27 09:19:08.000000000 -0300
+++ primes.c	2009-03-27 09:19:14.000000000 -0300
@@ -1,4 +1,5 @@
 #include <stdio.h>
+#include <stdlib.h>
 #include "primegen.h"
 #include "fs64.h"
 
