--- installer/check.php.orig	2012-08-06 18:18:13.000000000 +0200
+++ installer/check.php	2012-08-13 12:36:52.000000000 +0200
@@ -39,7 +39,6 @@
     'session.auto_start'            => 0,
     'zend.ze1_compatibility_mode'   => 0,
     'mbstring.func_overload'        => 0,
-    'suhosin.session.encrypt'       => 0,
     'magic_quotes_runtime'          => 0,
     'magic_quotes_sybase'           => 0,
 );
