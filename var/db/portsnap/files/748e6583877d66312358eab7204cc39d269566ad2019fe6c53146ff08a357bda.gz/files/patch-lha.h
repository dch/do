diff -ru src.orig/lha.h src/lha.h
--- src.orig/lha.h	Thu Oct  5 10:35:38 2000
+++ src/lha.h	Sun May 11 00:31:53 2003
@@ -11,6 +11,7 @@
 		lharc.h		interface.h		slidehuf.h
 */
 #include <stdio.h>
+#include <stdlib.h>
 #include <errno.h>
 #include <ctype.h>
 #include <sys/types.h>
