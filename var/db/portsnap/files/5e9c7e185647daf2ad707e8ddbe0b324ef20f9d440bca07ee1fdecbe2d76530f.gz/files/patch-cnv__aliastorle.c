--- cnv/aliastorle.c.orig	1992-04-30 05:01:13.000000000 +0900
+++ cnv/aliastorle.c	2012-10-15 22:22:54.000000000 +0900
@@ -117,7 +117,7 @@
  *      [None]
  */
 
-void
+int
 main( argc, argv )
 int argc;
 char **argv;
