--- tools/tobw.c.orig	1995-04-15 06:55:37.000000000 +0900
+++ tools/tobw.c	2012-10-15 23:03:56.000000000 +0900
@@ -64,7 +64,7 @@
  * Algorithm:
  *	[None]
  */
-void
+int
 main( argc, argv )
 int argc;
 char **argv;
