--- tools/to8.c.orig	1994-01-20 00:35:24.000000000 +0900
+++ tools/to8.c	2012-10-15 23:03:35.000000000 +0900
@@ -73,7 +73,7 @@
  *	[None]
  */
 
-void
+int
 main( argc, argv )
 int argc;
 char **argv;
