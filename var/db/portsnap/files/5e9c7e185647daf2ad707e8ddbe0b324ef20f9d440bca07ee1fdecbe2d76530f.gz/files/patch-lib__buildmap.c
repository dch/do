--- lib/buildmap.c.orig	Fri Feb 28 06:17:01 1992
+++ lib/buildmap.c	Fri Dec 27 23:02:36 2002
@@ -26,6 +26,7 @@
  */
 
 #include <stdio.h>
+#include <stdlib.h>
 #include "rle.h"
 #include <math.h>
 
