--- gtkpool/check_pocket.h.orig	2002-07-29 09:56:57.000000000 +0900
+++ gtkpool/check_pocket.h	2011-08-19 04:36:39.000000000 +0900
@@ -17,7 +17,6 @@
 
 #ifndef CHECK_POCKET_H
 #define CHECK_POCKET_H
-#include "ball.h"
 #include "game.h"
 
 
