--- gtkpool/game.cpp.orig	2002-07-29 06:58:05.000000000 +0900
+++ gtkpool/game.cpp	2011-08-19 04:36:31.000000000 +0900
@@ -16,6 +16,7 @@
  ***************************************************************************/
 
 #include "game.h"
+#include "moving.h"
 #include <algorithm>
 
 Game::Game(){
