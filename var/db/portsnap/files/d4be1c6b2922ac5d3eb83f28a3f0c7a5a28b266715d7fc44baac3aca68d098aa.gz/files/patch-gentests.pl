--- conformance/interfaces/sigaction/gentests.pl~	Mon Nov 10 11:37:15 2003
+++ conformance/interfaces/sigaction/gentests.pl	Mon Nov 10 11:43:01 2003
@@ -11,7 +11,7 @@
 my (@signals) = ("SIGABRT", "SIGALRM", "SIGBUS", "SIGCHLD", "SIGCONT", 
 		 "SIGFPE", "SIGHUP", "SIGILL", "SIGINT", "SIGPIPE",
 		 "SIGQUIT", "SIGSEGV", "SIGTERM", "SIGTSTP", "SIGTTIN",
-		 "SIGTTOU", "SIGUSR1", "SIGUSR2", "SIGPOLL", "SIGPROF",
+		 "SIGTTOU", "SIGUSR1", "SIGUSR2", "SIGPROF",
 		 "SIGSYS", "SIGTRAP", "SIGURG", "SIGVTALRM", "SIGXCPU",
 		 "SIGXFSZ");
 
