--- ./exfunc.c.orig	2003-01-05 15:58:05.000000000 +0100
+++ ./exfunc.c	2011-06-21 16:03:11.000000000 +0200
@@ -41,7 +41,7 @@
 
 #include <stdio.h>
 #include <string.h>
-#include <malloc.h>
+#include <stdlib.h>
 #include <ctype.h>
 #include "headers.h"
 
