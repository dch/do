--- ./zipdecrypt.c.orig	2003-01-05 15:58:05.000000000 +0100
+++ ./zipdecrypt.c	2011-06-21 16:03:11.000000000 +0200
@@ -84,7 +84,6 @@
 
 #include <sys/stat.h>
 #include <fcntl.h>
-#include <malloc.h>
 #include <string.h>
 #include "pkctypes.h"
 #include "crc.h"
