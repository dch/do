--- include/version.h.orig	2014-08-19 15:35:02.000000000 +0900
+++ include/version.h	2014-08-25 02:37:52.000000000 +0900
@@ -48,4 +48,4 @@
  * $OpenXM: OpenXM_contrib2/asir2000/include/version.h,v 1.366 2014/08/19 06:35:02 noro Exp $ 
 */
 #define ASIR_VERSION 20140819
-#define ASIR_DISTRIBUTION "Kobe"
+#define ASIR_DISTRIBUTION "Plotting Group"
