--- src/indent.h.orig	2008-03-11 19:50:42.000000000 +0100
+++ src/indent.h	2013-11-04 06:57:00.000000000 +0100
@@ -135,9 +135,9 @@ typedef enum bb_code
   bb_cast
 } bb_code_ty;
 
-#define DEFAULT_RIGHT_MARGIN 78
+#define DEFAULT_RIGHT_MARGIN 79
 
-#define DEFAULT_RIGHT_COMMENT_MARGIN 78
+#define DEFAULT_RIGHT_COMMENT_MARGIN 79
 
 #define DEFAULT_LABEL_INDENT -2
 
