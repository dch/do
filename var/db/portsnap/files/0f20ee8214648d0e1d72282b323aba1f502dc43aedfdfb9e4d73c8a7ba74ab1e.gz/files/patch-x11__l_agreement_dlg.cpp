--- x11/l_agreement_dlg.cpp.orig	2012-05-27 06:52:29.000000000 +0900
+++ x11/l_agreement_dlg.cpp	2012-05-27 06:52:59.000000000 +0900
@@ -31,7 +31,6 @@
 #include <X11/Xatom.h>
 }
 
-#include <strstream.h>
 
 #include "xdata.h"
 #include "panel.h"
