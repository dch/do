--- scandir.c.orig
+++ scandir.c
@@ -12,6 +12,8 @@
 **									
 *************************************************************************/
 #include	<stdio.h>
+#include	<ctype.h>
+#include	<stdlib.h>
 #include	"dir.H"
 #include	"misc.h"
 
