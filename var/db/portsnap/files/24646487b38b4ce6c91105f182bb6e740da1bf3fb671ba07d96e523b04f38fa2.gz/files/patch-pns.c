--- pns.c.orig
+++ pns.c
@@ -39,7 +39,7 @@
 extern Widget HaKonBox;
 extern Widget HaKonMenuLabel;
 
-main( argc, argv)
+int main( argc, argv)
   int 	argc;
   char 	**argv;
 {
