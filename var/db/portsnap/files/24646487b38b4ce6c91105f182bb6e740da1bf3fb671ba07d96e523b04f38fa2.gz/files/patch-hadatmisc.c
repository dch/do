--- hadatmisc.c.orig
+++ hadatmisc.c
@@ -14,6 +14,8 @@
 #include	"hawin.h"
 #include	"diwin.h"
 
+#include <stdlib.h>
+
 
 
 /*************************************************************************
