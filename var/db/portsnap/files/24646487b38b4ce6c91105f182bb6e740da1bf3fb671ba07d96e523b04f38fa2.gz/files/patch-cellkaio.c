--- cellkaio.c.orig
+++ cellkaio.c
@@ -21,6 +21,7 @@
 
 
 #include <stdio.h>
+#include <stdlib.h>
 
 
 
