--- filesteio.c.orig
+++ filesteio.c
@@ -18,6 +18,7 @@
 
 #include	<string.h>
 #include	<stdio.h>
+#include	<stdlib.h>
 
 
 
