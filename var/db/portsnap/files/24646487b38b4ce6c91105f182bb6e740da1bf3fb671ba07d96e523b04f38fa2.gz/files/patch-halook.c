--- halook.c.orig
+++ halook.c
@@ -18,7 +18,7 @@
 #include	"stewin.h"
 
 #include <stdio.h>
-
+#include <stdlib.h>
 
 
 
