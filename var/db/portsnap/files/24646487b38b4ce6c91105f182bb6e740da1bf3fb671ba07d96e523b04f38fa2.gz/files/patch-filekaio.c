--- filekaio.c.orig
+++ filekaio.c
@@ -19,6 +19,7 @@
 
 #include	<string.h>
 #include	<stdio.h>
+#include	<stdlib.h>
 
 
 
