--- cellein.c.orig
+++ cellein.c
@@ -14,6 +14,7 @@
 #include	"celltype.h"
 
 #include <stdio.h>
+#include <stdlib.h>
 
 
 /*************************************************************************
