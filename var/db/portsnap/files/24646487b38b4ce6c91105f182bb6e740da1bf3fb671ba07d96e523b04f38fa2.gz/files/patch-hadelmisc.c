--- hadelmisc.c.orig
+++ hadelmisc.c
@@ -22,6 +22,7 @@
 #include 	"cellget.h"
 
 #include <stdio.h>
+#include <stdlib.h>
 
 
 /*************************************************************************
