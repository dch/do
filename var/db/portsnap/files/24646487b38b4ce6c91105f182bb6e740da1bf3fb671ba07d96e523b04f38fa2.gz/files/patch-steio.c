--- steio.c.orig
+++ steio.c
@@ -15,6 +15,7 @@
 #include	"celltype.h"
 #include	"netsize.h"
 #include	<stdio.h>
+#include	<stdlib.h>
 
 
 #define DEFAULT_STEN_X_DISP	-HA_STE_RAD
