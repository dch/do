--- cellorg.c.orig
+++ cellorg.c
@@ -16,6 +16,8 @@
 #include	"tra.h"
 #include	"ka.h"
 
+#include <stdlib.h>
+
 
 
 
