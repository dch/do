--- harefreshx.c.orig
+++ harefreshx.c
@@ -25,6 +25,7 @@
 #include	"hastename.h"
 
 #include <stdio.h>
+#include <stdlib.h>
 
 #ifdef HALLO
 
