--- hakasete.c.orig
+++ hakasete.c
@@ -18,6 +18,8 @@
 #include	"celltype.h"
 #include	"katype.h"
 
+#include <stdlib.h>
+
 
 
 
