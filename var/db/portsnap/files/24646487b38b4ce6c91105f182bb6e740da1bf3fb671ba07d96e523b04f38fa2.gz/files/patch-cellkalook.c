--- cellkalook.c.orig
+++ cellkalook.c
@@ -16,6 +16,7 @@
 
 
 #include <stdio.h>
+#include <stdlib.h>
 
 
 
