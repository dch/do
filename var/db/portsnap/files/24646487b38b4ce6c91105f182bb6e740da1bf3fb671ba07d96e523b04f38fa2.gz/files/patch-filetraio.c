--- filetraio.c.orig
+++ filetraio.c
@@ -17,6 +17,7 @@
 
 #include	<string.h>
 #include	<stdio.h>
+#include	<stdlib.h>
 
 
 
