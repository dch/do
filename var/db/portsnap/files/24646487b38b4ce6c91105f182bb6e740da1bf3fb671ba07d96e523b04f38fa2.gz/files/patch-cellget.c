--- cellget.c.orig
+++ cellget.c
@@ -16,6 +16,7 @@
 
 
 #include <stdio.h>
+#include <stdlib.h>
 
 
 static OBJECT	*pSte, *pTra, *pK;
