--- simbreak.c.orig
+++ simbreak.c
@@ -15,6 +15,8 @@
 #include	"celltype.h"
 #include	"misc.h"
 
+#include <stdlib.h>
+
 
 /*************************************************************************
 ** FUNKTION:	SimBreakInit
