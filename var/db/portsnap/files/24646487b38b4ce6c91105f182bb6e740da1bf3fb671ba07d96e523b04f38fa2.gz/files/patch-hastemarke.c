--- hastemarke.c.orig
+++ hastemarke.c
@@ -17,6 +17,8 @@
 #include	"hagraph.h"
 #include	"misc.h"
 
+#include <stdlib.h>
+
 
 #define yDISP			5
 
