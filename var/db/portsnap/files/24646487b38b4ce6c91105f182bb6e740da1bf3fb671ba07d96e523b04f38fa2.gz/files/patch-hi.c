--- hi.c.orig
+++ hi.c
@@ -22,6 +22,7 @@
 #include 	<X11/Xaw/Viewport.h>
 #include 	<X11/Xaw/Paned.h>
 #include	<stdio.h>
+#include	<stdlib.h>
 
 Widget		HiCom;
 Widget		HiShell;
