--- cellmisc.c.orig
+++ cellmisc.c
@@ -14,6 +14,8 @@
 #include 	"cell.h"
 #include	"misc.h"
 
+#include <stdlib.h>
+
 
 
 
