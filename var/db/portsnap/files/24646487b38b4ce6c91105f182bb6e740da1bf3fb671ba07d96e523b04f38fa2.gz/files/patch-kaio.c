--- kaio.c.orig
+++ kaio.c
@@ -17,6 +17,8 @@
 #include	"ste.h"
 #include	"tra.h"
 
+#include <stdlib.h>
+
 
 
 /*************************************************************************
