--- kawinpop.c.orig
+++ kawinpop.c
@@ -12,6 +12,7 @@
 *************************************************************************/
 #include 	"kawin.H"
 #include	<stdio.h>
+#include	<stdlib.h>
 
 
 
