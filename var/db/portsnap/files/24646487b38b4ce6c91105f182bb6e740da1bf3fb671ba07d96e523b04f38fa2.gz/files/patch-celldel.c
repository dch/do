--- celldel.c.orig
+++ celldel.c
@@ -17,6 +17,7 @@
 #include	"cellrefr.h"
 
 #include <stdio.h>
+#include <stdlib.h>
 
 
 #define CellOListToRList( v)   do {					\
