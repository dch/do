--- cellrefr.c.orig
+++ cellrefr.c
@@ -15,6 +15,7 @@
 
 
 #include <stdio.h>
+#include <stdlib.h>
 
 
 /*************************************************************************
