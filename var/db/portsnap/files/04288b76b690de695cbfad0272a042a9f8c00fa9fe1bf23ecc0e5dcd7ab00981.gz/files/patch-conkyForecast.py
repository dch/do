--- conkyForecast.py.orig	2011-09-12 16:53:29.846760560 +0400
+++ conkyForecast.py	2011-09-12 16:53:37.428868063 +0400
@@ -1,4 +1,4 @@
-#!/usr/bin/env python2
+#!/usr/bin/env python
 # -*- coding: utf-8 -*-
 ###############################################################################
 # conkyForecast.py is a (not so) simple (anymore) python script to gather 
