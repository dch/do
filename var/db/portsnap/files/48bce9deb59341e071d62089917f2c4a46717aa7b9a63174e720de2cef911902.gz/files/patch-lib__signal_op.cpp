--- ./lib/signal_op.cpp.orig	2011-03-18 11:01:22.000000000 -0400
+++ ./lib/signal_op.cpp	2011-03-18 11:01:39.000000000 -0400
@@ -13,6 +13,7 @@
 
 
 #include <math.h>
+#include <stdlib.h>
 #include "signal_op.h"
 #include "AFLIB/aflibConverter.h"
 #include "error_op.h"
