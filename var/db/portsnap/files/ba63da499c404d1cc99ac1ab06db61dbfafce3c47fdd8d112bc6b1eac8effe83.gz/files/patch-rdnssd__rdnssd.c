--- rdnssd/rdnssd.c.orig	2011-09-10 14:20:44.451134584 +0400
+++ rdnssd/rdnssd.c	2011-09-10 14:21:09.758658207 +0400
@@ -29,6 +29,7 @@
 #include <stdbool.h>
 #include <locale.h>
 #include <signal.h>
+#include <stdint.h>
 
 #include <sys/types.h>
 #include <sys/stat.h>
