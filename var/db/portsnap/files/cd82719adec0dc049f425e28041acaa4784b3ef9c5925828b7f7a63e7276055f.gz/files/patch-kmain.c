--- kmain.c.orig	1994-07-26 18:30:35.000000000 +0900
+++ kmain.c	2010-02-16 19:33:47.000000000 +0900
@@ -6,6 +6,8 @@
 /* v1.30  1994  4/16	*/
 
 #include	<stdio.h>
+#include	<stdlib.h>
+#include	<string.h>
 
 #include	"kanjicode.h"
 #include	"ackstring.h"
