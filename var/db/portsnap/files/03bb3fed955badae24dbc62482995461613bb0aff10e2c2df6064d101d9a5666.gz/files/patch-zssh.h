--- zssh.h
+++ zssh.h
@@ -36,19 +36,18 @@
 #include "config.h"
 
 #ifdef STDC_HEADERS
+#include <sys/types.h>
 #include <stdlib.h>
 #include <stdio.h>
 #include <errno.h>
 #include <string.h>
 #include <time.h>
 #include <grp.h>
-#include <utmp.h>
 #include <signal.h>
 #include <ctype.h>
 
 /*#include <term.h> alpha */
 
-#include <sys/types.h>
 #include <sys/stat.h>
 #endif /* STDC_HEADERS */
 
