--- src/texture.cpp.orig	2012-12-02 16:22:54 UTC
+++ src/texture.cpp
@@ -4,6 +4,7 @@
  *  Created on: 2010-02-07
  *      Author: krzysztof
  */
+#include <cstring>
 #include <stdio.h>
 #include "texture.hpp"
 #include "files.h"
