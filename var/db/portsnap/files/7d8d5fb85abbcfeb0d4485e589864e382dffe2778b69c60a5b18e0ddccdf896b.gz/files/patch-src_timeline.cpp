--- src/timeline.cpp.orig	2012-12-02 16:22:54 UTC
+++ src/timeline.cpp
@@ -6,6 +6,7 @@
  */
 
 #include <cstdlib>
+#include <cstring>
 
 #include "timeline.hpp"
 #include "files.h"
