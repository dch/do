--- icc_helfer.cpp.orig	2013-05-01 21:42:51.000000000 +0400
+++ icc_helfer.cpp	2013-05-01 21:43:35.000000000 +0400
@@ -34,6 +34,7 @@
 # define DEBUG_ICCFUNKT
 #endif
 
+#include <inttypes.h>
 #include <icc34.h>
 #include "icc_utils.h"
 #include "icc_formeln.h"
