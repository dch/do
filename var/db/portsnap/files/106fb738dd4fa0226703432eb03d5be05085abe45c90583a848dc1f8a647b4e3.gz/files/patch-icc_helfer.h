--- icc_helfer.h.orig	2013-05-01 21:39:58.000000000 +0400
+++ icc_helfer.h	2013-05-01 21:40:51.000000000 +0400
@@ -30,6 +30,7 @@
 #ifndef ICC_HELFER_H
 #define ICC_HELFER_H
 
+#include <inttypes.h>
 #include <icc34.h>
 
 #include "icc_utils.h"
