--- lib/Crypt/OpenSSL/DSA.pm.orig	Thu Sep 26 09:18:37 2002
+++ lib/Crypt/OpenSSL/DSA.pm	Thu Oct 31 18:45:29 2002
@@ -1,7 +1,6 @@
 package Crypt::OpenSSL::DSA;
 
 use strict;
-use warnings;
 
 require DynaLoader;
 
