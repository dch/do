--- ./aksetup_helper.py.orig	2013-03-21 22:56:24.000000000 +0100
+++ ./aksetup_helper.py	2013-03-21 22:56:29.000000000 +0100
@@ -1,6 +1,6 @@
 # dealings with ez_setup ------------------------------------------------------
-import distribute_setup
-distribute_setup.use_setuptools()
+#import distribute_setup
+#distribute_setup.use_setuptools()
 
 import setuptools
 from setuptools import Extension
