--- richmail/richset.c.orig	Wed Oct 21 19:04:19 1992
+++ richmail/richset.c	Mon Dec 18 11:46:22 2006
@@ -34,6 +34,7 @@
 -------------------------------------------------------------------------*/
 
 #include <stdio.h>
+#include <stdlib.h>
 #include "richlex.h"
 #include "richset.h"
 
