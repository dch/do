--- richmail/richlex.c.orig	Thu Feb  3 03:29:37 1994
+++ richmail/richlex.c	Mon Dec 18 11:46:22 2006
@@ -42,6 +42,7 @@
 -------------------------------------------------------------------------*/
 
 #include <stdio.h>
+#include <string.h>
 #include <ctype.h>
 #include "richlex.h"
 #include "richset.h"
