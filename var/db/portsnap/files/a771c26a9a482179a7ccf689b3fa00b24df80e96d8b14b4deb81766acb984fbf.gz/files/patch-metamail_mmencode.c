--- metamail/mmencode.c.orig	Wed Jan 26 19:47:37 1994
+++ metamail/mmencode.c	Mon Dec 18 11:46:22 2006
@@ -13,6 +13,7 @@
 WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES.
 */
 #include <stdio.h>
+#include <stdlib.h>
 #include <config.h>
 #ifdef MSDOS
 #include <fcntl.h>
