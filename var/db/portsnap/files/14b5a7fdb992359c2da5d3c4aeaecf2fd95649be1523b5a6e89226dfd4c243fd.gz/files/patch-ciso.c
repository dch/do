--- ciso.c-orig	2013-09-08 13:47:13.000000000 +0000
+++ ciso.c	2013-09-08 13:48:03.000000000 +0000
@@ -24,6 +24,7 @@
 #include <stdlib.h>
 #include <zlib.h>               /* /usr(/local)/include/zlib.h */
 #include <zconf.h>
+#include <string.h>
 
 #include "ciso.h"
 
