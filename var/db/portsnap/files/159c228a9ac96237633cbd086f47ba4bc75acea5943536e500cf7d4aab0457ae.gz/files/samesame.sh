#!/bin/sh
#
# $FreeBSD: head/sysutils/samesame/files/samesame.sh 340872 2014-01-24 00:14:07Z mat $
#

case "$1" in
start)
	rm -rf /tmp/samefile /tmp/samearchive
	;;
esac

