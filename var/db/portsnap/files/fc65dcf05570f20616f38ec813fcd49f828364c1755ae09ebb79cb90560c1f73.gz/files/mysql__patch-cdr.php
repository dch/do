--- cdr.php.orig        Mon Mar  7 19:20:48 2005
+++ cdr.php     Thu Jul 20 23:47:46 2006
@@ -36,7 +36,7 @@
 	<head>            
 		<title>Asterisk CDR</title>
 		<meta http-equiv="Content-Type" content="text/html">
-		<link rel="stylesheet" type="text/css" media="print" href="/css/print.css">
+		<link rel="stylesheet" type="text/css" media="print" href="css/print.css">
 		<SCRIPT LANGUAGE="JavaScript" SRC="./encrypt.js"></SCRIPT>
 		<style type="text/css" media="screen">
 			@import url("css/layout.css");
