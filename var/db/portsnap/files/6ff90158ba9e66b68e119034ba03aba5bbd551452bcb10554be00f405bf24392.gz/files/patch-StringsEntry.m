--- StringsEntry.m.orig	2004-04-20 17:06:56.000000000 +0200
+++ StringsEntry.m	2008-05-03 09:31:51.000000000 +0200
@@ -20,6 +20,7 @@
 
 #include <Foundation/NSObject.h>
 #include <Foundation/NSArray.h>
+#include <Foundation/NSString.h>
 
 #include "StringsEntry.h"
 
