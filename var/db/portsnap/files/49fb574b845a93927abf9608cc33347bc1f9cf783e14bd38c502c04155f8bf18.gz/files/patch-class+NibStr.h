--- class/NibStr.h	3 Nov 2004 06:57:51 -0000	1.1
+++ class/NibStr.h	3 Nov 2004 07:25:35 -0000	1.2
@@ -57,6 +57,6 @@
 
 BIstream & operator>> (BIstream & in, NibStr & n);
 
-#endif NibStr_h
+#endif /* NibStr_h */
 
 
