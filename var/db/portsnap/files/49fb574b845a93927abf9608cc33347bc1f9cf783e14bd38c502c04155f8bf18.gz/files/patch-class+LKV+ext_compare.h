--- class/LKV/ext_compare.h	3 Nov 2004 06:57:51 -0000	1.1
+++ class/LKV/ext_compare.h	3 Nov 2004 07:25:07 -0000	1.2
@@ -20,5 +20,5 @@
 	return res;
 }
 
-#endif ext_compare_h
+#endif /* ext_compare_h */
 
