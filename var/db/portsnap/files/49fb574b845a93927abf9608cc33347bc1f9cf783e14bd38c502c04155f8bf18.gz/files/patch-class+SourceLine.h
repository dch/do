--- class/SourceLine.h	3 Nov 2004 06:57:51 -0000	1.1
+++ class/SourceLine.h	3 Nov 2004 07:25:35 -0000	1.2
@@ -30,5 +30,5 @@
 };
 
 
-#endif SourceLine_h
+#endif /* SourceLine_h */
 
