--- class/clld.h	3 Nov 2004 06:57:51 -0000	1.1
+++ class/clld.h	3 Nov 2004 07:25:35 -0000	1.2
@@ -76,6 +76,6 @@
 extern bool verbose; // should we talk to the user?
 extern bool shared; // are we linking into a shared library rather than an executable?
 
-#endif clld_h
+#endif /* clld_h */
 
 
