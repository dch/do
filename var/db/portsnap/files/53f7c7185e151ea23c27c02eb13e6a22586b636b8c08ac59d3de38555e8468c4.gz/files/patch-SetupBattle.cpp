--- SetupBattle.cpp.orig	Fri Jul  6 01:44:52 2007
+++ SetupBattle.cpp	Fri Jul  6 01:52:29 2007
@@ -18,7 +18,7 @@
 #include "PreBattle.h"
 
 #include <sstream>
-#include <boost/filesystem/exception.hpp>
+#include <boost/filesystem.hpp>
 
 using std::stringstream;
 using std::getline;
