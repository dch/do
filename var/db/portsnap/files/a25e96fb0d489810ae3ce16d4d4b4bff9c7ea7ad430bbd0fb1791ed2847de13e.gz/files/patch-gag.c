--- gag.c.orig	Mon May 12 15:15:07 2003
+++ gag.c	Mon May 12 15:15:09 2003
@@ -16,8 +16,7 @@
  *
  */
 
-#if YOU_HAVE_NOT_READ_THIS_YET
-
+/*
 This software should only be used in compliance with all applicable laws and
 the policies and preferences of the owners of any networks, systems, or hosts
 scanned with the software
@@ -34,8 +33,7 @@
 DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 ACTION OF CONTRACT, TORT (INCLUDING NEGLIGENCE) OR STRICT LIABILITY, ARISING
 OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.  
-
-#endif
+*/
 
 #define GAG "gesundheit!"
 #define VERSION "$Revision: 2.9 $"
