--- libicq2000/src/ContactTree.cpp.orig	2010-10-26 21:19:06.000000000 +0400
+++ libicq2000/src/ContactTree.cpp	2014-01-21 07:26:17.940860269 +0400
@@ -19,6 +19,8 @@
  *
  */
 
+#include <cstdlib>
+
 #include "ContactTree.h"
 #include "events.h"
 
