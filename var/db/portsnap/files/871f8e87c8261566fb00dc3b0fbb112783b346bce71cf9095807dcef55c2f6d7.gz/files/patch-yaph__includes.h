--- yaph/includes.h.orig	Sat Jun 14 14:18:47 2003
+++ yaph/includes.h	Sat Jun 14 14:18:58 2003
@@ -23,6 +23,7 @@
 #include <sys/stat.h>
 #include <string.h>
 #include <errno.h>
+#include <netinet/in.h>
 #include <arpa/inet.h>
 #include <pthread.h>
 #include <signal.h>
