--- text.c.orig	Wed Dec 10 20:36:09 2003
+++ text.c	Wed Dec 10 20:36:57 2003
@@ -3,7 +3,6 @@
    $Date: 2002/06/24 04:04:32 $
 */
 
-#include <malloc.h>
 #include <stdlib.h>
 #include <unistd.h>
 #include <string.h>
