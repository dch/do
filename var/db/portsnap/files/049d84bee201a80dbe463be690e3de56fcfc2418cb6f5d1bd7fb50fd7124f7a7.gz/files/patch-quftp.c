--- quftp.c.orig	Wed Dec 10 20:37:19 2003
+++ quftp.c	Wed Dec 10 20:37:27 2003
@@ -8,7 +8,6 @@
  */
 
 #include <stdio.h>
-#include <malloc.h>
 #include <string.h>
 #include <errno.h>
 #include <unistd.h>
