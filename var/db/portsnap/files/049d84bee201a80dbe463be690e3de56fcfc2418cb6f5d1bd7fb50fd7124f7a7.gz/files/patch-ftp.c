--- ftp.c.orig	Mon Mar 10 19:28:11 2003
+++ ftp.c	Wed Dec 10 20:33:55 2003
@@ -7,12 +7,10 @@
 #define _XOPEN_SOURCE 500
 
 #include <stdlib.h>
-#include <features.h>
 #include <stdio.h>
 #include <errno.h>
 #include <fcntl.h>
 #include <ctype.h>
-#include <malloc.h>
 #include <unistd.h>
 #include <sys/types.h>
 #include <sys/stat.h>
