--- rc.c.orig	Wed Dec 10 20:36:15 2003
+++ rc.c	Wed Dec 10 20:36:32 2003
@@ -5,7 +5,6 @@
  * $Date: 2002/06/13 07:00:33 $
  */
 
-#include <malloc.h>
 #include <stdlib.h>
 #include <string.h>
 #include <stdio.h>
