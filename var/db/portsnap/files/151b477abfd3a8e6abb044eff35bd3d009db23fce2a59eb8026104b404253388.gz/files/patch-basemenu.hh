--- basemenu.hh.orig	Mon Aug 19 17:53:47 2002
+++ basemenu.hh	Tue Apr  8 19:53:56 2003
@@ -24,6 +24,8 @@
 #ifndef _BASEMENU_HH_
 #define _BASEMENU_HH_
 
+using namespace std;
+
 // Parts below borrowed from fspanel.c
 static unsigned short cols[] = {
 	0xd75c, 0xd75c, 0xd75c,		  /* 0. light gray */
