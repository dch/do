--- goodies/appbar/main.cc.orig	2007-12-06 20:48:09.000000000 +0100
+++ goodies/appbar/main.cc	2007-12-06 20:48:46.000000000 +0100
@@ -33,6 +33,9 @@
  * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
  */
 
+#include <iostream>
+using namespace std;
+
 #include "appbar.hh"
 
 int main(int argc, char* argv[])
