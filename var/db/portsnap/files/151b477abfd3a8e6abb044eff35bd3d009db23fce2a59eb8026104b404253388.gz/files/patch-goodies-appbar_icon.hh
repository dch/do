--- goodies/appbar/icon.hh.orig	2007-12-06 21:10:35.000000000 +0100
+++ goodies/appbar/icon.hh	2007-12-06 21:12:21.000000000 +0100
@@ -43,8 +43,6 @@
 #include <X11/extensions/shape.h>
 #include <stdlib.h>
 
-extern char * default_icon_xpm[];
-
 class Icon 
 {
 private:
