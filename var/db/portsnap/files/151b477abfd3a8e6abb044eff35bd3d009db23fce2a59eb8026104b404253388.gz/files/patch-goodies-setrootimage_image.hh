--- goodies/setrootimage/image.hh.orig	2007-12-06 21:28:22.000000000 +0100
+++ goodies/setrootimage/image.hh	2007-12-06 21:34:53.000000000 +0100
@@ -27,6 +27,7 @@
 #include <cstdio>
 
 #include <list>
+using namespace std;
 
 class BImageControl;
 class BImage;
