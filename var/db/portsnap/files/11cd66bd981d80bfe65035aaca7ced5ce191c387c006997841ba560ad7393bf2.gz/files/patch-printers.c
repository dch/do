--- lib/printers.c.orig	Tue Oct 12 00:01:59 1999
+++ lib/printers.c	Wed May  2 11:23:25 2001
@@ -315,8 +315,8 @@
   res->ppd = NULL;		/* Printer's ppd are not read yet */
 
   /* Output */
-  /* Default is to send to default printer */
-  res->flag_output_is_printer = true;
+  /* Default is to send to stdout */
+  res->flag_output_is_printer = false;
   res->flag_output_name = NULL;
   res->output_is_file = true;
   res->output_name = NULL;
