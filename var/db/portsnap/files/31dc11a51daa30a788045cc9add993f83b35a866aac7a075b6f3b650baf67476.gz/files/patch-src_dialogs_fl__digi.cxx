--- src/dialogs/fl_digi.cxx.orig	2015-04-23 11:39:24 UTC
+++ src/dialogs/fl_digi.cxx
@@ -26,6 +26,7 @@
 #include <config.h>
 
 #include <sys/types.h>
+#include <time.h>
 
 #ifdef __WOE32__
 #  ifdef __CYGWIN__
