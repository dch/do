--- src/misc/newinstall.cxx.orig	2015-03-21 00:29:03 UTC
+++ src/misc/newinstall.cxx
@@ -84,7 +84,7 @@ Age:   \n\
 Rig:   \n\
 Pwr:   \n\
 Ant:   \n\
-OS:    Linux\n\
+OS:    FreeBSD\n\
 Soft:  <VER>\n\
 Web:   \n\
 Email: ";
