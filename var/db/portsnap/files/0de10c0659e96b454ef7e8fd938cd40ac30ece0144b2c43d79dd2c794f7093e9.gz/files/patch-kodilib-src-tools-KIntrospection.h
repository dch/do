--- kodilib/src/tools/KIntrospection.h.orig	2003-04-09 06:56:03.000000000 +0400
+++ kodilib/src/tools/KIntrospection.h	2013-12-18 23:04:00.089825283 +0400
@@ -11,6 +11,7 @@
 #endif
 
 #include <string>
+#include <cstring>
 
 // --------------------------------------------------------------------------------------------------------
 class KClassInfo
