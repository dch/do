--- kodilib/src/tools/KStringTools.h.orig	2003-04-09 06:56:04.000000000 +0400
+++ kodilib/src/tools/KStringTools.h	2013-12-18 23:05:02.025190391 +0400
@@ -7,6 +7,7 @@
 #define __KStringTools
 
 #include <string>
+#include <cstring>
 #include <vector>
 #include <stdarg.h>
 
