--- src/main/KikiPythonWidget.h.orig	Wed Apr  9 06:58:18 2003
+++ src/main/KikiPythonWidget.h	Sat Sep 30 00:08:07 2006
@@ -7,6 +7,7 @@
 #define __KikiPythonWidget
 
 #include "KikiPos.h"
+#include "KikiPython.h"
 #include <KTextField.h>
 
 class KikiPythonWidget : public KTextField
