--- configuration.hpp.orig	2010-09-28 18:09:56.000000000 +0000
+++ configuration.hpp
@@ -26,6 +26,7 @@
 #define CONFIGURATION_HPP
 
 #include <fstream>
+#include <stdlib.h>
 #include <limits>
 #include <map>
 #include <string>
