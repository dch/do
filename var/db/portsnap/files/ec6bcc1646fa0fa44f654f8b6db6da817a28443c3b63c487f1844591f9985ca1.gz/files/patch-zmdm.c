--- ./zmdm.c.orig	1996-12-11 23:24:08.000000000 -0800
+++ ./zmdm.c	2011-07-22 17:33:19.603250928 -0700
@@ -18,6 +18,7 @@
  */
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <termios.h>
 #include <signal.h>
 #ifdef UNITE
