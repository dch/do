--- ladder.h.org	Wed Feb 18 19:19:51 1998
+++ ladder.h	Wed Feb 18 19:26:29 1998
@@ -1,4 +1,4 @@
-#include <ncurses/curses.h>
+#include <ncurses.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <signal.h>
