--- ./src/http_client.c.orig	2012-09-24 12:05:51.000000000 -0400
+++ ./src/http_client.c	2012-09-24 12:05:58.000000000 -0400
@@ -44,6 +44,7 @@
 #include "alloc-inl.h"
 #include "string-inl.h"
 #include "database.h"
+#include "config.h"
 
 #include "http_client.h"
 
