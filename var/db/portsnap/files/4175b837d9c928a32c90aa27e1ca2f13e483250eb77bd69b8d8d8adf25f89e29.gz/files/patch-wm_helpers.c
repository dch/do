--- wm_helpers.c.orig	Sun Aug  8 21:05:58 1999
+++ wm_helpers.c	Sun Aug  8 21:06:12 1999
@@ -30,7 +30,7 @@
 
 #include <stdio.h>
 #include <string.h>
-#include <malloc.h>
+#include <stdlib.h>
 #include <errno.h>
 #include <stdarg.h>
 #include <sys/time.h>
