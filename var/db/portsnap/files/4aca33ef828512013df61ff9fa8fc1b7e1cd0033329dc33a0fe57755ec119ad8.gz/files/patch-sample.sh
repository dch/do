--- sample.sh	Sat Aug 31 03:27:52 1996
+++ sample.sh.new	Mon Sep 18 00:07:47 2000
@@ -7,7 +7,7 @@
 *cursor		[~~~~~~]
 *screen saver	[~~~~~~~~~~~~~]		*time out	[~~~~]
 
-#v=keymap#s=:`cd /usr/share/syscons/keymaps;echo *.kbd|sed 's/ /:/g'`:#d=jp.106.kbd#
+#v=keymap#d=jp.106.kbd#
 #v=keyrate#s=:slow:normal:fast:default:#
 #v=cursor#s=:normal:blink:destructive:NO:#
 #v=saver#s=:green:blank:snake:star:#d=green#v=blanktime#a=rf#d=600#
