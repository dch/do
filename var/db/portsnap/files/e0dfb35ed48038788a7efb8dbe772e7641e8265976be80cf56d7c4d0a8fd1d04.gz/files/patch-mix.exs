--- mix.exs.orig	2015-07-10 07:31:12 UTC
+++ mix.exs
@@ -6,8 +6,7 @@ defmodule Timex.Mixfile do
       version: "0.16.1",
       elixir: "~> 1.0.0",
       description: "A date/time library for Elixir",
-      package: package,
-      deps: deps ]
+      package: package]
 
   end
 
