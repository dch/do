--- mix.exs.orig	2015-07-05 09:01:37 UTC
+++ mix.exs
@@ -12,7 +12,6 @@ defmodule HTTPoison.Mixfile do
       name: "HTTPoison",
       description: @description,
       package: package,
-      deps: deps,
       source_url: "https://github.com/edgurgel/httpoison" ]
   end
 
