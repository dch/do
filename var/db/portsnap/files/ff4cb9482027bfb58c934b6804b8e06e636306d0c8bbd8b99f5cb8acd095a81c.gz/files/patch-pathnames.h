--- pathnames.h.orig	2003-06-03 03:01:41 UTC
+++ pathnames.h
@@ -35,4 +35,4 @@
  *	@(#)pathnames.h	8.1 (Berkeley) 5/31/93
  */
 
-#define _PATH_SCOREFILE	"/var/games/tetris.scores"
+#define _PATH_SCOREFILE	"/var/games/bsdtris.scores"
