--- tools/isdv4-serial-debugger.c~
+++ tools/isdv4-serial-debugger.c
@@ -25,7 +25,6 @@
 
 #include <errno.h>
 #include <fcntl.h>
-#include <linux/serial.h>
 #include <getopt.h>
 #include <poll.h>
 #include <stdio.h>
