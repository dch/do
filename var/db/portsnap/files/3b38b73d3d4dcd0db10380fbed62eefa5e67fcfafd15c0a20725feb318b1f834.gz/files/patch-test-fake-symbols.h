--- test/fake-symbols.h~
+++ test/fake-symbols.h
@@ -2,7 +2,6 @@
 #include <dix.h>
 #include <os.h>
 #include <exevents.h>
-#include <Xprintf.h>
 #include <xf86.h>
 #include <xf86Xinput.h>
 #include <xf86_OSproc.h>
