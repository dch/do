--- ./setup.py.orig	2013-11-27 16:56:21.489321513 -0200
+++ ./setup.py	2013-11-27 16:57:06.823319522 -0200
@@ -1,7 +1,5 @@
 
 import sys
-import distribute_setup
-distribute_setup.use_setuptools()
 from setuptools import setup, find_packages
 
 
