--- po-checktrans.py.orig	Wed Sep 24 21:32:42 2003
+++ po-checktrans.py	Wed Sep 24 21:33:03 2003
@@ -1,4 +1,4 @@
-#!/usr/bin/python
+#!/usr/bin/env python
 #
 # This quick hack gives translation statistics (from the core translation
 # files).
