--- src/elmoconf.pl.orig	Sat Aug  7 11:30:51 2004
+++ src/elmoconf.pl	Sat Aug  7 11:32:44 2004
@@ -26,7 +26,6 @@
 #  This script sets up user's config file based on few simple questions.
 
 use strict;
-use warnings;
 
 use constant VERSION => "1.48";
 
