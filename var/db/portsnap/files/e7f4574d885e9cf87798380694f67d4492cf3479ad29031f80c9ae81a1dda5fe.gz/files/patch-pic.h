--- pic.h.orig	Wed Apr  3 10:27:42 2002
+++ pic.h	Wed Apr  3 10:29:33 2002
@@ -128,4 +128,3 @@
 extern	struct pushstack stack[];
 extern	int	nstack;
 
-extern float atof();
