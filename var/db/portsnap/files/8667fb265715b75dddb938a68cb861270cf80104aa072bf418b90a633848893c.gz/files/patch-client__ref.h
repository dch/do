--- ./client/ref.h.orig	Sun Jan  1 15:05:04 2006
+++ ./client/ref.h	Sat Dec 30 17:36:46 2006
@@ -36,7 +36,7 @@
 #define	MAX_LIGHTSTYLES	256
 
 #define MAX_DECAL_VERTS			128
-#define MAX_DECAL_FRAGMENTS		64
+#define MAX_DECAL_FRAGMENTS		32
 
 #define POWERSUIT_SCALE		4.0F
 
