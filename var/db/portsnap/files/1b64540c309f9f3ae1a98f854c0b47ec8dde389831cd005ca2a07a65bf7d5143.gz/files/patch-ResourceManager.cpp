--- utils/ResourceManager.cpp.orig
+++ utils/ResourceManager.cpp
@@ -13,6 +13,7 @@
 // FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details
 //
 #include <unistd.h>
+#include <cstring>
 #include <iomanip>
 #include <dirent.h>
 #include <sys/types.h>
