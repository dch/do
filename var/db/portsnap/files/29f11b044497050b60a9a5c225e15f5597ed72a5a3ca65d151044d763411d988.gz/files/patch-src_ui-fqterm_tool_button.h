--- src/ui/fqterm_tool_button.h.orig	2008-05-18 08:46:46.000000000 +0800
+++ src/ui/fqterm_tool_button.h	2008-06-21 08:52:08.000000000 +0800
@@ -21,7 +21,7 @@
 #ifndef FQTERM_TOOL_BUTTON_H
 #define FQTERM_TOOL_BUTTON_H
 
-#include <qtoolbutton.h>
+#include <QToolButton>
 
 namespace FQTerm {
 
