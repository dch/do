--- include/avbin.h.orig	2008-09-21 10:45:33.000000000 +0400
+++ include/avbin.h	2009-04-03 06:49:52.000000000 +0400
@@ -69,6 +69,7 @@
 #define AVBIN_H
 
 #include <stdint.h>
+#include <sys/types.h>
 
 /** 
  * Error-checked function result.
