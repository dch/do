--- src/Dock.cc.orig	2011-03-29 19:48:36 UTC
+++ src/Dock.cc
@@ -32,6 +32,7 @@
 #include <stdio.h>
 #include <unistd.h>
 #include <iostream>
+#include <cstring>
 #include <string>
 
 #include "Dock.hh"
