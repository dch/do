--- ./ratmen.c.orig	2007-10-25 09:13:39.000000000 -0300
+++ ./ratmen.c	2008-02-20 17:08:21.000000000 -0300
@@ -128,7 +128,6 @@
 
 
 /* function prototypes */
-int  strcasecmp(char*, char*);                 /* string comparison */
 void ask_wm_for_delete(void);
 void reap(int);
 void redraw_snazzy(int, int, int);
