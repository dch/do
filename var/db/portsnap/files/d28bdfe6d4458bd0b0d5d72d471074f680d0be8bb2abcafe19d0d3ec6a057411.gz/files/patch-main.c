--- main.c.orig	Sun Feb  1 19:51:55 2004
+++ main.c	Sun Feb  1 19:52:11 2004
@@ -11,6 +11,7 @@
 #include <netinet/in.h>
 #include <arpa/inet.h>
 #include <netdb.h>
+#include <sys/time.h>
 
 Prototype int VerboseOpt;
 
