--- ./util.h.orig	2010-12-06 18:35:50.000000000 +0100
+++ ./util.h	2014-01-11 04:44:10.000000000 +0100
@@ -8,7 +8,6 @@
 
 #include <stdio.h>
 #include <sys/types.h>
-#include <sys/timeb.h>
 #include <sys/stat.h>
 
 // defines
