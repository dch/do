--- xpp.h.orig	2011-11-29 13:02:26.198230347 -0800
+++ xpp.h	2011-11-29 13:07:43.783229272 -0800
@@ -34,6 +34,7 @@
 #include <stdlib.h>
 #include <string.h>
 #include <cups/cups.h>
+#include <cups/ppd.h>
 #include <cups/ipp.h>
 #include <cups/language.h>
 #include <FL/Fl.H>
