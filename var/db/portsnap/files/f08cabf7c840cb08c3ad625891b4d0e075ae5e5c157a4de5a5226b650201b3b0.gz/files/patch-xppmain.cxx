--- xppmain.cxx.orig	2004-11-30 17:28:01.000000000 -0800
+++ xppmain.cxx	2011-12-03 22:13:39.744180523 -0800
@@ -32,7 +32,7 @@
  */
 
 #include "mainwindow.h"
-#include <Fl/Fl_Shared_Image.h>
+#include <FL/Fl_Shared_Image.H>
 
 /*
  * 'main()' - Do all what xpp should do
