--- dwatch.c.orig	Wed Aug 14 16:52:28 2002
+++ dwatch.c	Wed Aug 14 16:52:34 2002
@@ -17,6 +17,7 @@
    MA 02111-1307, USA.
 */
 
+#include <sys/types.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
