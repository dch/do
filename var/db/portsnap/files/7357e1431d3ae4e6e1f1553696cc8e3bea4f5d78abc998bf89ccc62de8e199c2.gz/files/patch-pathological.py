--- pathological.py.orig	2003-07-17 18:12:30.000000000 +0400
+++ pathological.py	2008-02-05 04:09:49.000000000 +0300
@@ -1847,7 +1847,7 @@
 	scroller_font_height = 28
 	scroller_rect = (10,550,780,scroller_font_height)
 	scroller_text = \
-		"   Copyright � 2003  John-Paul Gignac.   "+ \
+		"   Copyright (C) 2003  John-Paul Gignac.   "+ \
 		"   Soundtrack by Matthias Le Bidan.   "+ \
 		"   Board designs contributed by Mike Brenneman and Kim Gignac.   "+ \
 		"   To contribute your own board designs, see the website:  "+ \
