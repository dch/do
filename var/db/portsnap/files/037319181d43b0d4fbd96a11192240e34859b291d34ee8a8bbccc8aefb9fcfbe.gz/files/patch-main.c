*** main.c.orig	Sat Nov 16 14:37:16 1996
--- main.c	Thu Jan 15 00:00:00 2000
***************
*** 66,72 ****
    /***  set s_map  ***/
    gameMainFlg.s_map = False;
    nowDataRec.nowMap.gameSpeed = 90;
!   nowDataRec.nowMap.dirname[0] == 0x00;
  
    for(i =1; i  < argc; i++)
      {
--- 66,72 ----
    /***  set s_map  ***/
    gameMainFlg.s_map = False;
    nowDataRec.nowMap.gameSpeed = 90;
!   strcpy(nowDataRec.nowMap.dirname, "%%PREFIX%%/lib/X11/xdeblock/mapf");
  
    for(i =1; i  < argc; i++)
      {
