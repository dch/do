Index: bgpctl/irr_output.c
===================================================================
RCS file: /home/cvs/private/hrs/openbgpd/bgpctl/irr_output.c,v
retrieving revision 1.1.1.1
retrieving revision 1.1.1.2
diff -u -p -r1.1.1.1 -r1.1.1.2
--- bgpctl/irr_output.c	30 Jun 2009 05:46:15 -0000	1.1.1.1
+++ bgpctl/irr_output.c	13 Oct 2012 18:22:52 -0000	1.1.1.2
@@ -1,4 +1,4 @@
-/*	$OpenBSD: irr_output.c,v 1.13 2007/03/05 17:28:21 henning Exp $ */
+/*	$OpenBSD: irr_output.c,v 1.12 2007/03/05 15:02:05 henning Exp $ */
 
 /*
  * Copyright (c) 2007 Henning Brauer <henning@openbsd.org>
