Index: bgpctl/irr_asset.c
===================================================================
RCS file: /home/cvs/private/hrs/openbgpd/bgpctl/irr_asset.c,v
retrieving revision 1.1.1.2
retrieving revision 1.1.1.3
diff -u -p -r1.1.1.2 -r1.1.1.3
--- bgpctl/irr_asset.c	9 Jul 2009 16:49:55 -0000	1.1.1.2
+++ bgpctl/irr_asset.c	13 Oct 2012 18:22:52 -0000	1.1.1.3
@@ -1,4 +1,4 @@
-/*	$OpenBSD: irr_asset.c,v 1.8 2009/04/14 21:10:54 jj Exp $ */
+/*	$OpenBSD: irr_asset.c,v 1.7 2007/03/31 12:46:55 henning Exp $ */
 
 /*
  * Copyright (c) 2007 Henning Brauer <henning@openbsd.org>
