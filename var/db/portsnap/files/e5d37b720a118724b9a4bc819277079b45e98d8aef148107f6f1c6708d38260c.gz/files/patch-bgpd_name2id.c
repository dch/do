Index: bgpd/name2id.c
===================================================================
RCS file: /home/cvs/private/hrs/openbgpd/bgpd/name2id.c,v
retrieving revision 1.1.1.2
retrieving revision 1.1.1.3
diff -u -p -r1.1.1.2 -r1.1.1.3
--- bgpd/name2id.c	9 Jul 2009 16:49:54 -0000	1.1.1.2
+++ bgpd/name2id.c	13 Oct 2012 18:22:43 -0000	1.1.1.3
@@ -1,4 +1,4 @@
-/*	$OpenBSD: name2id.c,v 1.9 2009/06/04 04:46:42 claudio Exp $ */
+/*	$OpenBSD: name2id.c,v 1.8 2009/05/17 12:25:15 claudio Exp $ */
 
 /*
  * Copyright (c) 2004, 2005 Henning Brauer <henning@openbsd.org>
