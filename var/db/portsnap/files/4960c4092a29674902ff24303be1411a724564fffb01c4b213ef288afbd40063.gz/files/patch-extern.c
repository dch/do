--- extern.c.orig	Wed Jul  8 11:32:47 1987
+++ extern.c	Fri Jun 15 02:20:34 2007
@@ -45,7 +45,7 @@
 		1,	/* C_DRIVE_SAFE */
 		1,	/* C_RIGHT_WAY */
 		0	/* C_INIT */
-	};
+	},
 	Numneed[NUM_CARDS] = {	/* number of cards needed per hand	*/
 		0,	/* C_25 */
 		0,	/* C_50 */
