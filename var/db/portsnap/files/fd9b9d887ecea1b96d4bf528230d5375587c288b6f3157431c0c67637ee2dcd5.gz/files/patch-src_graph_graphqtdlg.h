--- src/graph/graphqtdlg.h.orig	Fri Jul 14 00:33:51 2006
+++ src/graph/graphqtdlg.h	Fri Jul 14 00:34:01 2006
@@ -59,6 +59,7 @@
 class QSignalMapper;
 class EScrollField;
 class EDialogPrivate;
+class EDialog;
 
 class EDialogPrivate: public QDialog
 {
