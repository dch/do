--- lib/stride/stride.h-xxx	Fri Dec 17 18:18:07 2004
+++ lib/stride/stride.h	Fri Dec 17 18:18:30 2004
@@ -40,7 +40,7 @@
 #define MAX_BOND                  100
 #define MAX_ASSIGN                300
 #define MAX_INFO                  100
-#define MAX_AT_IN_RES             50
+#define MAX_AT_IN_RES             75
 #define MAX_AT_IN_HETERORES       200
 #define MAXRESDNR                 6
 #define MAXRESACC                 6 
