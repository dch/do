--- output-swf.c.orig	Sun Dec 23 22:10:59 2001
+++ output-swf.c	Thu Dec 27 14:45:31 2001
@@ -2,7 +2,7 @@
 
 #include "spline.h"
 #include "output-swf.h"
-#include <ming.h>
+#include <ming/libming.h>
 
 #define FPS 24.0
 #define IMGID 1
