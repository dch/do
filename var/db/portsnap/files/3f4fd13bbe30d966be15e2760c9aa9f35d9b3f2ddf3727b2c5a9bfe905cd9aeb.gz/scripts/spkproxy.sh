#!/bin/sh
DIR=`pwd`
cd DATADIR
./spkproxy.py
cd $DIR
