--- vaul/dunit.cc.orig	2005-12-14 08:23:06.000000000 +0000
+++ vaul/dunit.cc
@@ -27,6 +27,7 @@
 
 #include <errno.h>
 #include <string.h>
+#include <stdlib.h>
 #if HAVE_MALLOC_H
 #include <malloc.h>
 #endif
