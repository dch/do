--- TrustedPickle.py.orig	Tue May  2 14:20:14 2006
+++ TrustedPickle.py	Tue May  2 14:20:24 2006
@@ -82,6 +82,7 @@
 Low-level functions in this module you should not need to call:
 
 Hash(): used in signing a string
+"""
 
 import cPickle
 import getpass
