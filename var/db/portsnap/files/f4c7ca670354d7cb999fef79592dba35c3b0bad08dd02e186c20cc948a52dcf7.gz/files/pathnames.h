/*
 * For licence, see nologinmsg.c
 *
 * $Id: pathnames.h,v 1.1 2002/07/10 16:39:35 rik Exp $
 */

#define NOLOGINMSG_PATH "/usr/local/etc/nologinmsgs/"
