--- RawSock.pm.orig	Mon Feb  3 14:28:08 2003
+++ RawSock.pm	Mon Feb  3 14:28:30 2003
@@ -41,7 +41,7 @@
 
 =head1 AUTHOR
 
-Stephane Aubert E<lt>Stephane.Aubert@hsc-labs.frE<gt>
+Stephane Aubert E<lt>Stephane.Aubert@hsc-labs.comE<gt>
 
 =cut
 
