--- ./he2/hebString.cxx.orig	Wed Mar 14 10:04:03 2001
+++ ./he2/hebString.cxx	Thu Jun 10 21:31:44 2004
@@ -21,7 +21,7 @@
 
 #include "hebString.h"
 #include <string.h>
-#include <iostream.h>
+#include <iostream>
 #include <assert.h>
 
 
