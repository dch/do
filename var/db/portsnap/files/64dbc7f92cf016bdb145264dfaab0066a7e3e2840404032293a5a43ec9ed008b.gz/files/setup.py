from distutils.core import setup

setup(
    name = 'plex',
    version = "%%PORTVERSION%%",
    packages = ['Plex'],
    )
