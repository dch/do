--- mix.exs.orig	2015-07-06 14:47:27 UTC
+++ mix.exs
@@ -6,8 +6,7 @@ defmodule Protobuf.Mixfile do
      version: "0.10.0",
      elixir: "~> 1.0.0",
      description: description,
-     package: package,
-     deps: deps]
+     package: package]
   end
 
   def application do
