--- progs/scramble.c.orig	2013-04-30 08:28:30.000000000 -0400
+++ progs/scramble.c	2013-04-30 08:28:43.000000000 -0400
@@ -1,3 +1,4 @@
+#include <unistd.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
