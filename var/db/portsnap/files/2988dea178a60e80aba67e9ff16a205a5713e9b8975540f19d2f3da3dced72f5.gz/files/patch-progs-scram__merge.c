--- progs/scram_merge.c.orig	2013-04-30 08:30:10.000000000 -0400
+++ progs/scram_merge.c	2013-04-30 08:30:23.000000000 -0400
@@ -1,3 +1,4 @@
+#include <unistd.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
