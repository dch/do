--- ./SyntopiaCore/GLEngine/Sphere.h~	2012-05-20 01:25:41.000000000 -0300
+++ ./SyntopiaCore/GLEngine/Sphere.h	2012-05-20 01:25:59.000000000 -0300
@@ -3,6 +3,8 @@
 #include "SyntopiaCore/Math/Vector3.h"
 #include "Object3D.h"
 
+#include <GL/glu.h>
+
 namespace SyntopiaCore {
 	namespace GLEngine {	
 
