--- ./SyntopiaCore/GLEngine/Raytracer/RayTracer.cpp~	2012-05-20 01:28:31.000000000 -0300
+++ ./SyntopiaCore/GLEngine/Raytracer/RayTracer.cpp	2012-05-20 01:28:47.000000000 -0300
@@ -7,6 +7,8 @@
 #include "SyntopiaCore/Logging/Logging.h"
 #include "SyntopiaCore/Misc/MiniParser.h"
 
+#include <GL/glu.h>
+
 using namespace SyntopiaCore::Math;
 using namespace SyntopiaCore::Misc;
 
