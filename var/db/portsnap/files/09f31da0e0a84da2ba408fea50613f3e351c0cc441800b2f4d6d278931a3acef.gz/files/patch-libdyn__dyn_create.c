diff -ur ../../xbuffy-3.3.bl.3/libdyn/dyn_create.c ./libdyn/dyn_create.c
--- ../../xbuffy-3.3.bl.3/libdyn/dyn_create.c	Fri Feb 20 17:54:14 1998
+++ ./libdyn/dyn_create.c	Tue May  8 13:13:43 2001
@@ -12,6 +12,7 @@
  */
 
 #include <stdio.h>
+#include <stdlib.h>
 
 #include "dynP.h"
 
