diff -ur ../../xbuffy-3.3.bl.3/nntp.c ./nntp.c
--- ../../xbuffy-3.3.bl.3/nntp.c	Wed Jul  1 19:12:51 1998
+++ ./nntp.c	Tue May  8 16:43:06 2001
@@ -294,12 +294,9 @@
 	DynObject headerString;
 	Boolean *beenTouched;
 {
-	int sock, err, len;
 	char line[1024];
-	long ipaddr;
 	char *from;
 	char *subject;
-	long firstScanArticle;
 	long firstArticle;
 	long lastArticle;
 	long retVal;
