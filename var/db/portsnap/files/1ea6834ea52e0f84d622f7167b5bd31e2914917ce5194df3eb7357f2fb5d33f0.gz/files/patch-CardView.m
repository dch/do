--- CardView.m.orig	2005-03-13 18:52:24.000000000 +0100
+++ CardView.m	2008-05-03 09:38:44.000000000 +0200
@@ -11,6 +11,7 @@
 #import "CardView.h"
 
 #import <Foundation/NSDictionary.h>
+#import <AppKit/NSAttributedString.h>
 #import <AppKit/NSColor.h>
 #import <AppKit/NSFont.h>
 #import <AppKit/NSTextStorage.h>
