--- libgnomecups/gnome-cups-init.h.orig	2012-06-07 10:56:20.000000000 +0200
+++ libgnomecups/gnome-cups-init.h	2012-06-07 10:56:30.000000000 +0200
@@ -1,8 +1,7 @@
 #ifndef GNOME_CUPS_INIT
 #define GNOME_CUPS_INIT
 
-#include <glib/gtypes.h>
-#include <glib/gmacros.h>
+#include <glib.h>
 
 G_BEGIN_DECLS
 
