--- libgnomecups/gnome-cups-i18n.c.orig	2012-06-07 10:55:30.000000000 +0200
+++ libgnomecups/gnome-cups-i18n.c	2012-06-07 10:55:37.000000000 +0200
@@ -1,5 +1,5 @@
 #include <config.h>
-#include <glib/gmacros.h>
+#include <glib.h>
 #include "gnome-cups-i18n.h"
 
 #ifdef ENABLE_NLS
