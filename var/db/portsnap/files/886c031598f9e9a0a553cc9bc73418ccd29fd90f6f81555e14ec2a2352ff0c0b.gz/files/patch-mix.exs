--- mix.exs.orig	2015-07-14 14:26:45 UTC
+++ mix.exs
@@ -68,7 +68,6 @@ defmodule Comeonin.Mixfile do
       package: package,
       source_url: "https://github.com/elixircnx/comeonin",
       compilers: [:comeonin, :elixir, :app],
-      deps: deps
     ]
   end
 
