--- PackageSetup.py.orig	2013-07-08 01:21:09 UTC
+++ PackageSetup.py
@@ -1,6 +1,5 @@
-#!python
+#!/usr/bin/env python
 
-from __future__ import with_statement
 import glob
 import os.path
 import shutil
