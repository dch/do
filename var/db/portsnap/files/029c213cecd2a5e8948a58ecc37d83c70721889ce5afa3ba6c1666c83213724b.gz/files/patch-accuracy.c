--- accuracy.c.orig	2009-03-27 09:48:32.000000000 -0300
+++ accuracy.c	2009-03-27 09:48:45.000000000 -0300
@@ -1,4 +1,5 @@
 #include <stdio.h>
+#include <stdlib.h>
 #include <math.h>
 #include "fftc4.h"
 #include "fftc8.h"
