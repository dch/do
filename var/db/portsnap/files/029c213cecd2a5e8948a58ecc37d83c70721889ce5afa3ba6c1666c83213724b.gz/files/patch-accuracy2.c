--- accuracy2.c.orig	2009-03-27 09:49:20.000000000 -0300
+++ accuracy2.c	2009-03-27 09:49:29.000000000 -0300
@@ -1,4 +1,5 @@
 #include <stdio.h>
+#include <stdlib.h>
 #include <math.h>
 #include "fftc4.h"
 #include "fftc8.h"
