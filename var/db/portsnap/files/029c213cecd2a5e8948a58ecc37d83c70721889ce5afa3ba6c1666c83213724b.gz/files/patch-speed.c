--- speed.c.orig	2009-03-27 09:49:42.000000000 -0300
+++ speed.c	2009-03-27 09:49:57.000000000 -0300
@@ -1,4 +1,5 @@
 #include <stdio.h>
+#include <stdlib.h>
 #include "fftr4.h"
 #include "fftr8.h"
 #include "fftc4.h"
