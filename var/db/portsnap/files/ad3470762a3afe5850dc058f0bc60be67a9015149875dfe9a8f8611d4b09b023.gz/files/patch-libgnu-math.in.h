--- libgnu/math.in.h.orig	2013-02-21 21:21:17.000000000 +0100
+++ libgnu/math.in.h	2013-11-22 12:35:47.000000000 +0100
@@ -17,7 +17,7 @@
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.  */
 
-#ifndef _@GUARD_PREFIX@_MATH_H
+#if 1
 
 #if __GNUC__ >= 3
 @PRAGMA_SYSTEM_HEADER@
