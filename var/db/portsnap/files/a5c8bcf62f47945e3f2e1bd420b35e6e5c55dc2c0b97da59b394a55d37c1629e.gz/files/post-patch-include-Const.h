--- include/Const.h.orig	2008-10-26 23:35:29.000000000 +0900
+++ include/Const.h	2008-10-26 23:35:44.000000000 +0900
@@ -68,6 +68,7 @@
 #define	MaxClientNum		512
 #define	LogOutFile		NULL	
 #define	PortName		"sj3"
+#define ServerName              "localhost"
 #ifdef TLI
 #define LocalHost               "localhost"
 #define ProtoName               "tcp"
