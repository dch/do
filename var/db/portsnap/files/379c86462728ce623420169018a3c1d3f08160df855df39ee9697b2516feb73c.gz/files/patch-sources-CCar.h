--- sources/CCar.h.orig	2006-02-11 13:48:14.000000000 +0300
+++ sources/CCar.h	2008-05-15 00:17:13.000000000 +0400
@@ -119,6 +119,8 @@
 
 };
 
+class F1SpiritGame;
+class CTrack;
 
 class CCar {
 	friend class EnemyCCar;
