--- sources/F1Shttp.cpp.orig	2012-03-06 23:15:25.728704383 +0400
+++ sources/F1Shttp.cpp	2012-03-06 23:15:45.193266324 +0400
@@ -3,7 +3,6 @@
 #include "string.h"
 
 #include <curl/curl.h>
-#include <curl/types.h>
 #include <curl/easy.h>
 
 #include "F1Shttp.h"
