--- sysdep.h.orig	Mon Jul 20 16:39:19 1998
+++ sysdep.h	Mon Jul 20 16:40:08 1998
@@ -154,6 +154,7 @@
 # define USE_FSYNC	1
 # define USE_FSTAT	1
 # define USE_FCHMOD	1
+# define USE_CTYPE	1
 #endif
 
 #ifdef IRIX
