*** mouse.c.org	Thu Mar  7 12:34:43 1996
--- mouse.c	Thu Jun 25 14:17:16 1998
***************
*** 266,272 ****
  	/* Format of command to xterm to start or stop mouse hilite tracking:
  	 * ^[ [ func ; startx ; starty ; firstrow ; lastrow T
  	 */
! #define XTERMBUG
  #ifdef XTERMBUG
  	static const char	hl_fmt[] = "\033[%d;%d;%d;%d;%dTX";
  #else
--- 266,272 ----
  	/* Format of command to xterm to start or stop mouse hilite tracking:
  	 * ^[ [ func ; startx ; starty ; firstrow ; lastrow T
  	 */
! /* #undef XTERMBUG */
  #ifdef XTERMBUG
  	static const char	hl_fmt[] = "\033[%d;%d;%d;%d;%dTX";
  #else
