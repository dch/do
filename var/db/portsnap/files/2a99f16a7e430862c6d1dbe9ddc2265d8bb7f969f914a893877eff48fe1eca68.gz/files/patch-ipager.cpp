--- ./ipager.cpp.orig	2013-10-02 17:32:19.537257981 +0200
+++ ./ipager.cpp	2013-10-02 17:32:46.295254941 +0200
@@ -31,6 +31,7 @@
 
 #include <iostream>
 #include <string>
+#include <unistd.h>
 using namespace std;
 
 #include "pager.h"
