--- ftc/kjofol/kjofol.cpp.orig	2014-02-18 17:48:40.481824991 +0100
+++ ftc/kjofol/kjofol.cpp	2014-02-18 17:49:16.578764197 +0100
@@ -47,6 +47,7 @@
 
 #include <sys/types.h>
 #include <sys/stat.h>
+#include <stdlib.h>
 
 #include "path_max.h"
 
