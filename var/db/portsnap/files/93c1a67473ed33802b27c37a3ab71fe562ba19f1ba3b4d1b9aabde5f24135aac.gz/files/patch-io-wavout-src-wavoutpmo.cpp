--- io/wavout/src/wavoutpmo.cpp.orig	Sat Mar 15 10:01:51 2003
+++ io/wavout/src/wavoutpmo.cpp	Mon Aug 18 17:25:07 2003
@@ -28,7 +28,6 @@
 #endif
 #include <stdio.h>
 #include <stdlib.h>
-#include <malloc.h>
 #include <string>
 
 /* project headers */
