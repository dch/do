--- plm/metadata/vorbis/vorbis.cpp.orig	Wed Jan  1 08:29:35 2003
+++ plm/metadata/vorbis/vorbis.cpp	Sat Jan 11 05:32:18 2003
@@ -23,6 +23,7 @@
 
 #include <stdio.h>
 #include <stdlib.h>
+#include <unistd.h>
 #include <math.h>
 #include <assert.h>
 #include <string>
