--- src/Clock.h.orig	2013-10-28 17:23:32.000000000 +0100
+++ src/Clock.h	2013-10-28 17:28:11.000000000 +0100
@@ -19,6 +19,7 @@
 
 #pragma once
 
+#include <ctime>
 #include <string>
 
 /*! \class Clock
