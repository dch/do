--- src/RenderManager.cpp.orig	2012-08-07 18:22:07.000000000 +0200
+++ src/RenderManager.cpp	2012-08-07 18:22:19.000000000 +0200
@@ -1,4 +1,4 @@
-﻿/*=============================================================================
+/*=============================================================================
 Blobby Volley 2
 Copyright (C) 2006 Jonathan Sieber (jonathan_sieber@yahoo.de)
 Copyright (C) 2006 Daniel Knobe (daniel-knobe@web.de)
