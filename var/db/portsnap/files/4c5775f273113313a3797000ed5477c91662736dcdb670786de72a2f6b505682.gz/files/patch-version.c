--- version.c.orig	Sun Mar 14 00:00:00 1999
+++ version.c	Sun Feb 13 16:07:25 2000
@@ -42,7 +42,7 @@
 #endif
 
 #ifdef TRANS
-const char	Modify[] = "Modified for ����̾/OS̾ by �ܿ���̾";
+const char	Modify[] = "Modified for FreeBSD2.0.5R by pcs51674@asciinet.or.jp";
 #endif
 
 #endif /* !_T_WINDOWS */
