--- calendar.c.orig	Sun Mar 14 00:00:00 1999
+++ calendar.c	Sun Feb 13 15:43:52 2000
@@ -848,7 +848,7 @@
 
 	va_start(ap, fmt);
 
-	fprintf(stderr, "calendar: ");
+	fprintf(stderr, "calendar: %s");
 	if (level != ERR_INFO) {
 		fprintf(stderr, "%s: ", statname[level - ERR_WARN]);
 	}
