--- ftparchive/contents.cc.orig	Thu Mar  2 06:06:31 2006
+++ ftparchive/contents.cc	Tue Nov 14 17:13:30 2006
@@ -41,7 +41,6 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
-#include <malloc.h>    
 									/*}}}*/
 
 // GenContents::~GenContents - Free allocated memory			/*{{{*/
