--- libffmpegthumbnailer/jpegwriter.h.orig	2014-05-30 02:04:59.000000000 -0700
+++ libffmpegthumbnailer/jpegwriter.h	2014-12-02 18:20:46.000000000 -0800
@@ -17,6 +17,7 @@
 #ifndef JPEG_WRITER_H
 #define JPEG_WRITER_H
 
+#include <cstdio>
 #include <string>
 #include <vector>
 
