--- ./src/replace.cpp.orig	2014-01-20 16:50:27.000000000 -0200
+++ ./src/replace.cpp	2014-01-20 16:50:38.000000000 -0200
@@ -1,4 +1,5 @@
 #include <cstring>
+#include <cstdio>
 #include "replace.h"
 
 int Replace::run (
