--- src/recodext.h	2001-01-04 09:36:54.000000000 -0500
+++ src/recodext.h	2013-05-13 16:14:46.000000000 -0400
@@ -219,5 +219,5 @@
 
     /* Non zero if this one should be ignored.  */
-    bool ignore : 2;
+    bool ignore : 1;
   };
 
