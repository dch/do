--- base/errors.h.orig	2007-06-06 07:23:38.000000000 +0900
+++ base/errors.h	2009-03-29 03:53:40.000000000 +0900
@@ -21,6 +21,6 @@
  */
 
 /* We include that file here to backward compatibility */
-#include "ierrors.h"
+#include "../psi/ierrors.h"
 
 #endif /* errors_INCLUDED */
