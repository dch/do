--- bin/zorbacmd.cpp.orig	2014-09-12 09:26:04.000000000 +0200
+++ bin/zorbacmd.cpp	2014-09-12 09:26:23.000000000 +0200
@@ -16,6 +16,8 @@
 
 #include "zorbacmdproperties.h"
 
+#include <stdlib.h>
+
 #include <memory>
 #include <iostream>
 #include <fstream>
