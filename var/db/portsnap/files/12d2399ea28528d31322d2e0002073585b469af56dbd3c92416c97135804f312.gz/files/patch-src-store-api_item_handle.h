--- src/store/api/item_handle.h.orig	2014-06-13 15:24:23.000000000 +0200
+++ src/store/api/item_handle.h	2014-06-13 15:34:05.000000000 +0200
@@ -16,6 +16,8 @@
 #ifndef ZORBA_STORE_ITEM_HANDLE_H
 #define ZORBA_STORE_ITEM_HANDLE_H
 
+#include <string>
+#include <sstream>
 
 
 namespace zorba 
