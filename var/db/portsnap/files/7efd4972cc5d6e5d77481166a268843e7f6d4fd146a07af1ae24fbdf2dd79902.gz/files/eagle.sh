#!/bin/sh
#
# $FreeBSD: head/cad/linux-eagle5/files/eagle.sh 340851 2014-01-23 19:55:14Z mat $

EAGLEBIN=%%DATADIR%%/bin/eagle

$EAGLEBIN "$@"
