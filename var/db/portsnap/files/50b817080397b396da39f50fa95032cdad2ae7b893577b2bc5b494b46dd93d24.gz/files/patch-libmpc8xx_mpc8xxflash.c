--- libmpc8xx/mpc8xxflash.c.orig	Sat Jun 24 12:55:50 2006
+++ libmpc8xx/mpc8xxflash.c	Sat Jun 24 12:55:57 2006
@@ -14,7 +14,6 @@
 
 #include <stdio.h>
 #include <string.h>
-#include <malloc.h>
 #include <ctype.h>
 #include <stdlib.h>
 
