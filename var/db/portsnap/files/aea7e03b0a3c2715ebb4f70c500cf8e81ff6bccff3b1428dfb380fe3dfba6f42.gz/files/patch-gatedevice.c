--- gatedevice.c.orig	2010-11-26 17:54:07.000000000 +0300
+++ gatedevice.c	2010-11-26 17:55:02.000000000 +0300
@@ -1,3 +1,5 @@
+#include <stdio.h>
+#include <string.h>
 #include <syslog.h>
 #include <stdlib.h>
 #include <upnp/ixml.h>
