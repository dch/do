--- src/main.c.orig	2011-07-01 09:34:23.000000000 +0200
+++ src/main.c	2011-07-01 09:34:37.000000000 +0200
@@ -43,7 +43,7 @@
 
 
 
-void main(int argc, char **argv)
+int main(int argc, char **argv)
 {
   MyProgram mydata;
 
