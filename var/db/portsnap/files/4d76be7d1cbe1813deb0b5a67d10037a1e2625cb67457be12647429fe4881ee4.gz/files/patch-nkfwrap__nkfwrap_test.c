--- nkfwrap/nkfwrap_test.c.orig	2008-07-02 12:30:10.000000000 +0900
+++ nkfwrap/nkfwrap_test.c	2008-07-02 13:13:52.000000000 +0900
@@ -1,4 +1,5 @@
 #include <stdio.h>
+#include <string.h>
 #include "nkfwrap.h"
 
 int main()
