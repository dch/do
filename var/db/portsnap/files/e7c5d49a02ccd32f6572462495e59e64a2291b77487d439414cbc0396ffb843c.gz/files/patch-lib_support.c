--- lib/support.c.orig	2008-02-21 11:31:42.000000000 +0900
+++ lib/support.c	2008-08-02 02:18:10.000000000 +0900
@@ -44,6 +44,7 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <syslog.h>
+#include <unistd.h>
 #include <time.h>
 #include <fcntl.h>
 
