diff -ruN include/h4601.h.orig include/h4601.h
--- include/h4601.h.orig    2006-06-08 09:26:16.000000000 -0400
+++ include/h4601.h        2007-12-31 15:10:41.000000000 -0500
@@ -61,6 +61,7 @@

 #include "h225.h"
 #include "transports.h"
+#include <ptlib/pluginmgr.h>
 #include <ptclib/url.h>



