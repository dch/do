--- xli.h.orig	1999-10-24 21:15:07.000000000 -0500
+++ xli.h	2011-04-08 03:00:16.026090836 -0500
@@ -13,6 +13,7 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <math.h>
+#include <string.h>
 #ifndef VMS
 #include <unistd.h>
 #endif
