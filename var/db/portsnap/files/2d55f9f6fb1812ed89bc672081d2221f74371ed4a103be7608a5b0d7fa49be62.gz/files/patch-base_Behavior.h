--- base/Behavior.h.orig	2003-11-20 16:46:16.000000000 +0000
+++ base/Behavior.h
@@ -10,6 +10,7 @@
 #ifndef BEHAVIOR_H
 #define BEHAVIOR_H
 
+#include <unistd.h>
 #include "EMath.h"
 
 class Group;
