--- overlay_gl/overlay.c~	2011-02-19 16:35:15.000000000 -0500
+++ overlay_gl/overlay.c	2011-02-27 16:04:32.000000000 -0500
@@ -45,6 +45,7 @@
 #include <sys/ipc.h>
 #include <sys/time.h>
 #include <sys/socket.h>
+#include <sys/stat.h>
 #include <sys/un.h>
 #include <time.h>
 #include <semaphore.h>
