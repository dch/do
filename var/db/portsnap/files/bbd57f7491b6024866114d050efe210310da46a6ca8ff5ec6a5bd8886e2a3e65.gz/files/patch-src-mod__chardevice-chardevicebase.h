--- src/mod_chardevice/chardevicebase.h.orig	2010-06-02 23:58:04.000000000 +0400
+++ src/mod_chardevice/chardevicebase.h	2013-09-13 21:32:52.875235168 +0400
@@ -46,6 +46,8 @@
 #endif
 
 
+#include <string>
+
 #include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
