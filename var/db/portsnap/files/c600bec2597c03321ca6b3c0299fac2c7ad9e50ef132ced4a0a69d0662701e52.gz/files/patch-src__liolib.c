--- src/liolib.c.orig	2015-04-03 18:41:57 UTC
+++ src/liolib.c
@@ -16,6 +16,7 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
+#include <unistd.h>
 
 #include "lua.h"
 
