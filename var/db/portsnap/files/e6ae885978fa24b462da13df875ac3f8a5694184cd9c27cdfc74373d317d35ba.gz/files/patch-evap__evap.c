--- evap/evap.c.dist	Sun Aug 25 08:36:46 1996
+++ evap/evap.c	Sat Apr 28 16:24:54 2001
@@ -19,7 +19,6 @@
 
 #include <stdio.h>
 #include <ctype.h>
-#include <malloc.h>
 #include <sys/types.h>
 #include <pwd.h>
 #include <string.h>
