--- src/DownloadEngine.cc.orig	2014-07-22 14:33:38 UTC
+++ src/DownloadEngine.cc
@@ -37,6 +37,7 @@
 #include <signal.h>
 
 #include <cstring>
+#include <cstdlib>
 #include <cerrno>
 #include <algorithm>
 #include <numeric>
