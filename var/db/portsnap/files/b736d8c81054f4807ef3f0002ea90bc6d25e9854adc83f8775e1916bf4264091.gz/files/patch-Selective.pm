--- Selective.pm.orig	Wed May  8 01:45:28 2002
+++ Selective.pm	Mon Apr 25 14:48:59 2005
@@ -412,8 +412,6 @@
 
 =cut
 
-{};	## Get emacs to indent correctly. Sigh.
-
 use Data::Dumper;
 
 BEGIN
