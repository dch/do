--- src/dlgutils.cc.orig	Sun Jun 12 02:34:25 2005
+++ src/dlgutils.cc	Mon Jun 20 23:50:40 2005
@@ -27,7 +27,7 @@
 
 #include "include/dlgutils.h"
 #include <unistd.h>
-#include <libintl.h>
+#include <ctype.h>
 #include "include/main.h"
 #include "include/preferences.h"
 #include "config.h"
