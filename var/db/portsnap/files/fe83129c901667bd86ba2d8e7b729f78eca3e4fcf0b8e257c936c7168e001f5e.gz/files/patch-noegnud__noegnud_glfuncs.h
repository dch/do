--- noegnud/noegnud_glfuncs.h.orig	Wed Apr  7 13:46:11 2004
+++ noegnud/noegnud_glfuncs.h	Wed Apr  7 13:46:27 2004
@@ -2,8 +2,8 @@
 #define _GLFUNCS_H_
 
 #include <GL/gl.h>
-#include <SDL/SDL.h>
-#include <SDL/SDL_image.h>
+#include <SDL.h>
+#include <SDL_image.h>
 
 typedef struct {
     int width,height;
