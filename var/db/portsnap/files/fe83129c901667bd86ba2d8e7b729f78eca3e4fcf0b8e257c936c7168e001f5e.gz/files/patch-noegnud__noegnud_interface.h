--- noegnud/noegnud_interface.h.orig	Wed Apr  7 13:47:53 2004
+++ noegnud/noegnud_interface.h	Wed Apr  7 13:48:07 2004
@@ -1,8 +1,8 @@
 #ifndef _NOEGNUD_INTERFACE_H_
 #define _NOEGNUD_INTERFACE_H_
 
-#include <SDL/SDL.h>
-#include <SDL/SDL_image.h>
+#include <SDL.h>
+#include <SDL_image.h>
 #include <GL/gl.h>
 #include <GL/glu.h>
 
