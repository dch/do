--- lib/unpthread.h.orig	Thu Sep 30 11:13:20 1999
+++ lib/unpthread.h	Thu Sep 30 11:13:41 1999
@@ -4,7 +4,7 @@
 #ifndef	__unp_pthread_h
 #define	__unp_pthread_h
 
-#include	"unp.h"
+#include	<unp.h>
 
 void	Pthread_create(pthread_t *, const pthread_attr_t *,
 					   void * (*)(void *), void *);
