--- lib/unpifi.h.orig	Thu Sep 30 11:13:10 1999
+++ lib/unpifi.h	Thu Sep 30 11:13:43 1999
@@ -4,7 +4,7 @@
 #ifndef	__unp_ifi_h
 #define	__unp_ifi_h
 
-#include	"unp.h"
+#include	<unp.h>
 #include	<net/if.h>
 
 #define	IFI_NAME	16			/* same as IFNAMSIZ in <net/if.h> */
