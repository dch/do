--- setup.py.orig	2010-06-25 10:22:29.000000000 +0800
+++ setup.py	2010-06-25 10:22:39.000000000 +0800
@@ -1,6 +1,4 @@
 #!/usr/bin/env python
-from distribute_setup import use_setuptools
-use_setuptools(version="0.6.17")
 
 from setuptools import setup, find_packages
 import os
