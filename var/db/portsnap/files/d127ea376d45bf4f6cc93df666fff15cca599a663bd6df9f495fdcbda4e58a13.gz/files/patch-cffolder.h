--- cffolder.h.orig	1999-10-24 02:13:29.000000000 -0400
+++ cffolder.h	2014-02-21 15:52:05.724747639 -0500
@@ -15,7 +15,7 @@
 #define __CFFOLDER_H__
 
 #include <string.h>
-#include <fstream.h>
+#include <fstream>
 #include "cftypes.h"
 #include "cfheader.h"
 
@@ -89,4 +89,5 @@
 
 ////////////////////////////////////////////////////////////////////////////////
 
-#endif
\ No newline at end of file
+#endif
+
