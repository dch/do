--- cffdrmgr.h.orig	2014-02-21 15:51:05.912257936 -0500
+++ cffdrmgr.h	2014-02-21 15:51:13.426256130 -0500
@@ -9,7 +9,7 @@
 #ifndef __CFFDRMGR_H__
 #define __CFFDRMGR_H__
 
-#include <fstream.h>
+#include <fstream>
 #include "zlib.h"
 #include "cftypes.h"
 #include "cfdblock.h"
