--- darray.h.orig	Sun Aug 31 05:55:31 2003
+++ darray.h	Sun Aug 31 05:55:32 2003
@@ -155,4 +155,4 @@
 
 ///////////////////////////////////////***************************************
 
-#endif
\ No newline at end of file
+#endif
