--- cfreader.h.orig	2014-02-21 16:11:11.770180090 -0500
+++ cfreader.h	2014-02-21 16:10:41.259844074 -0500
@@ -11,7 +11,7 @@
 #ifndef __CFREADER_H__
 #define __CFREADER_H__
 
-#include <fstream.h>
+#include <fstream>
 #include "darray.h"
 #include "cffile.h"
 #include "cffdrmgr.h"
