--- cffile.cpp.orig	2014-02-21 15:52:54.235249989 -0500
+++ cffile.cpp	2014-02-21 15:53:02.965814752 -0500
@@ -17,7 +17,7 @@
 #ifndef __CFFILE_CPP__
 #define __CFFILE_CPP__
 
-#include <fstream.h>
+#include <fstream>
 #include "cffile.h"
 #include "cftypes.h"
 #include "cfheader.h"
