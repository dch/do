--- cfdblock.h.orig	2014-02-21 15:49:53.526262379 -0500
+++ cfdblock.h	2014-02-21 15:50:02.511261600 -0500
@@ -14,7 +14,7 @@
 #ifndef __CFDBLOCK_H__
 #define __CFDBLOCK_H__
 
-#include <fstream.h>
+#include <fstream>
 #include "cftypes.h"
 #include "cfheader.h"
 
