--- cffdrmgr.cpp.orig	2014-02-21 15:50:45.048258834 -0500
+++ cffdrmgr.cpp	2014-02-21 15:50:53.033257685 -0500
@@ -12,7 +12,7 @@
 #ifndef __CFFDRMGR_CPP__
 #define __CFFDRMGR_CPP__
 
-#include <fstream.h>
+#include <fstream>
 #include "zlib.h"
 #include "cftypes.h"
 #include "cfdblock.h"
