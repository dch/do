--- src/main.cc.orig	Mon Mar  3 17:10:41 1997
+++ src/main.cc	Sun Oct 20 17:41:25 2002
@@ -18,10 +18,10 @@
  */
 
 #include <errno.h>
-#include <grp.h>
 #include <pwd.h>
 #include <signal.h>
 #include <stdio.h>
+#include <stdlib.h>
 #include <unistd.h>
 #include <sys/socket.h>
 #include <sys/types.h>
