Index: reclp_main.c
@@ -18,7 +18,7 @@
 #include <curses.h>
 #endif
 
-#define BRECCMD "/usr/lib/gramofile/brec_gramo"
+#define BRECCMD "brec_gramo"
 
 void
 record_from_lp (char *startdir)
