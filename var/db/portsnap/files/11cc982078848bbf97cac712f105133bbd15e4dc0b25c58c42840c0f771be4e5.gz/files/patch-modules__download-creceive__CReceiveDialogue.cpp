--- modules/download-creceive/CReceiveDialogue.cpp.orig
+++ modules/download-creceive/CReceiveDialogue.cpp
@@ -27,6 +27,8 @@
 
  /* $Id: CReceiveDialogue.cpp 836 2007-02-06 15:16:50Z common $ */
 
+#include <cstdio>
+
 #include "CReceiveDialogue.hpp"
 
 #include "SocketManager.hpp"
