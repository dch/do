--- nepenthes-core/include/SocketManager.hpp.orig
+++ nepenthes-core/include/SocketManager.hpp
@@ -32,6 +32,7 @@
 
 #include <list>
 #include <stdint.h>
+#include <ctime>
 
 #include "Manager.hpp"
 
