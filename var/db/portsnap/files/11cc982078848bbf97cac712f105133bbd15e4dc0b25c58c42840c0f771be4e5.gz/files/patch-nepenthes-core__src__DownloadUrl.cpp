--- nepenthes-core/src/DownloadUrl.cpp.orig
+++ nepenthes-core/src/DownloadUrl.cpp
@@ -26,6 +26,8 @@
  *******************************************************************************/
  /* $id */
 
+#include <cstdlib>
+
 #ifdef WIN32
 
 #else
