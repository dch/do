--- modules/shellemu-winnt/VFSCommand.hpp.orig
+++ modules/shellemu-winnt/VFSCommand.hpp
@@ -33,6 +33,7 @@
 #include <list>
 #include <string>
 #include <vector>
+#include <inttypes.h>
 
 #include "VFSNode.hpp"
 
