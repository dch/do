--- modules/x-5/x-5.cpp.orig
+++ modules/x-5/x-5.cpp
@@ -27,6 +27,7 @@
 
  /* $Id: x-5.cpp 1410 2007-10-12 13:07:23Z common $ */
 
+#include <cstdlib>
 #include "x-5.hpp"
 #include "LogManager.hpp"
 #include "EventManager.hpp"
