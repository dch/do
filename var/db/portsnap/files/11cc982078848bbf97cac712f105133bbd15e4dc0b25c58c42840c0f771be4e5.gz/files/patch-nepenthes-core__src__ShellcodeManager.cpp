--- nepenthes-core/src/ShellcodeManager.cpp.orig
+++ nepenthes-core/src/ShellcodeManager.cpp
@@ -27,6 +27,7 @@
 
 /* $Id: ShellcodeManager.cpp 505 2006-04-09 16:39:36Z oxff $ */
 
+#include <cstdio>
 #include "ShellcodeManager.hpp"
 #include "ShellcodeHandler.hpp"
 #include "Nepenthes.hpp"
