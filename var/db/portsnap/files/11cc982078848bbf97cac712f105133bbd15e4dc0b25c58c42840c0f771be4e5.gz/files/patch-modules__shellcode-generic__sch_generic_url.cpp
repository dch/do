--- modules/shellcode-generic/sch_generic_url.cpp.orig
+++ modules/shellcode-generic/sch_generic_url.cpp
@@ -40,6 +40,7 @@
 
 
  
+#include <cstdio>
 #include "sch_generic_url.hpp"
 #include "LogManager.hpp"
 #include "Message.hpp"
