--- modules/shellcode-generic/sch_generic_xor.cpp.orig
+++ modules/shellcode-generic/sch_generic_xor.cpp
@@ -40,6 +40,8 @@
 
 
 
+#include <cstdio>
+
 #include "sch_generic_xor.hpp"
 
 #include "Nepenthes.hpp"
