--- nepenthes-core/include/Nepenthes.hpp.orig
+++ nepenthes-core/include/Nepenthes.hpp
@@ -40,6 +40,7 @@
 
 #include <stdint.h>
 #include <string>
+#include <sys/types.h>
 
 typedef unsigned char byte;
 
