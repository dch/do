--- modules/submit-norman/submit-norman.cpp.orig
+++ modules/submit-norman/submit-norman.cpp
@@ -28,6 +28,8 @@
  /* $Id: submit-norman.cpp 674 2006-10-23 01:31:53Z common $ */
 
 
+#include <cstdlib>
+
 #include "submit-norman.hpp"
 #include "Download.hpp"
 #include "DownloadUrl.hpp"
