--- sndserv/wadread.c.orig	Sat Oct  8 17:15:05 2005
+++ sndserv/wadread.c	Sat Oct  8 17:15:09 2005
@@ -39,7 +39,7 @@
 
 
 
-#include <malloc.h>
+#include <stdlib.h>
 #include <fcntl.h>
 #include <sys/stat.h>
 #include <stdio.h>
