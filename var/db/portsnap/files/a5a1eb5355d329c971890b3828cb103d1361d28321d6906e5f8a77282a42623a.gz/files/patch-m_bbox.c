--- linuxdoom-1.10/m_bbox.c~	Mon Dec 22 21:40:50 1997
+++ linuxdoom-1.10/m_bbox.c	Mon Dec 14 03:44:53 1998
@@ -1,3 +1,5 @@
+#define MAXINT 0x7fffffff
+#define MININT 0x80000000
 // Emacs style mode select   -*- C++ -*- 
 //-----------------------------------------------------------------------------
 //
