--- sndserv/soundsrv.c.orig	Sat Oct  8 17:15:28 2005
+++ sndserv/soundsrv.c	Sat Oct  8 17:15:33 2005
@@ -47,7 +47,7 @@
 #include <sys/ioctl.h>
 #include <unistd.h>
 #include <stdlib.h>
-#include <malloc.h>
+#include <stdlib.h>
 #include <sys/stat.h>
 #include <sys/time.h>
 
