--- classes/x11/x11src.cc.orig
+++ classes/x11/x11src.cc
@@ -49,6 +49,7 @@
 #define Uses_signal
 #define Uses_fcntl // open
 #define Uses_snprintf
+#define Uses_sys_stat
 #define Uses_AllocLocal
 #define Uses_TDisplay
 #define Uses_TScreen
