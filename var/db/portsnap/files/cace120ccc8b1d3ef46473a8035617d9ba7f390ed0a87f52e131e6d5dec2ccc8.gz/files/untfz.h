#ifndef INCLUDED_UNTFZ_H
#define INCLUDED_UNTFZ_H

long
untfz(long int inunit, long int outunit, double *factor);

#endif  /* INCLUDED_UNTFZ_H */
