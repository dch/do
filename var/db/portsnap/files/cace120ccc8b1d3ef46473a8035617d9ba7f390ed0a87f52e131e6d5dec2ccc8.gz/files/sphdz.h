#ifndef INCLUDED_SPHDZ_H
#define INCLUDED_SPHDZ_H

int
sphdz(long int isph, double *parm, double *r_major, double *r_minor, double *radius);

#endif  /* INCLUDED_SPHDZ_H */
