#ifndef INCLUDED_FOR_INIT_H
#define INCLUDED_FOR_INIT_H

void
for_init(long int outsys, long int outzone, double *outparm, 
         long int outdatum, char *fn27, char *fn83, long int *iflg,
         ForwardTransFunc for_trans[]);

#endif   /* INCLUDED_FOR_INIT_H */
