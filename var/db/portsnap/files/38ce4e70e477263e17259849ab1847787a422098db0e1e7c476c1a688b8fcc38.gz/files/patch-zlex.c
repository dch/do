--- src/zlex.c.orig	Tue May 14 02:39:53 2002
+++ src/zlex.c	Tue May 14 02:40:04 2002
@@ -33,7 +33,6 @@
 #include <ctype.h>
 //#include <varargs.h>
 #include <stdarg.h>
-#include <printf.h>
 #include "avl.h"
 #include "zlex.h"
 #include "mem.h"
