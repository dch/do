--- ./ocr-utils/narray-io.h.orig	2009-06-01 05:18:41.000000000 +0900
+++ ./ocr-utils/narray-io.h	2009-06-17 19:44:58.000000000 +0900
@@ -31,6 +31,7 @@
 
 #include <stdio.h>
 #include <stdlib.h>
+#include <stdint.h>
 #include "ocropus.h"
 
 namespace ocropus {
