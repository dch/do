--- src/lha.h.orig	Sun Sep 21 15:58:52 2003
+++ src/lha.h	Thu Sep 23 07:10:33 2004
@@ -16,6 +16,7 @@
 #endif
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <errno.h>
 #include <ctype.h>
 #include <sys/types.h>
