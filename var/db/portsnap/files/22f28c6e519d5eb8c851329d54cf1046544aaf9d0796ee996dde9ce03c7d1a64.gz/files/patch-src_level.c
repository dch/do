--- src/level.c.orig	2013-09-05 15:33:47.000000000 +0200
+++ src/level.c	2013-09-05 15:33:52.000000000 +0200
@@ -12,7 +12,6 @@
 **/
 
 #include "gnocl.h"
-#include "./level/gtklevel.h"
 
 static GnoclOption levelOptions[] =
 {
