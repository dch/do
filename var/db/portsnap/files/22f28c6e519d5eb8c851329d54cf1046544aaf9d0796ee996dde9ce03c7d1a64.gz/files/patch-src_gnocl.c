--- src/gnocl.c.orig	2013-09-17 10:11:31.000000000 +0200
+++ src/gnocl.c	2013-09-17 10:11:50.000000000 +0200
@@ -669,7 +669,7 @@
 	/* non-gtk widgets */
 	{ "spinner", gnoclSpinnerCmd },
 	{ "dial", gnoclDialCmd },
-	{ "level", gnoclLevelCmd },
+//	{ "level", gnoclLevelCmd },
 	{ "tickerTape", gnoclTickerTapeCmd },
 	{ "richTextToolBar", gnoclRichTextToolBarCmd },
 
