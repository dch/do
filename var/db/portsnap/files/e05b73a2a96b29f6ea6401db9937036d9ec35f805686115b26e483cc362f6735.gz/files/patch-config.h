--- config.h.orig	Sat Jul 17 10:37:03 1999
+++ config.h	Fri Mar 30 21:11:09 2001
@@ -30,7 +30,7 @@
 /* Comment this out to disable the joystick code. This code currently only
    works on Linux, and only uses one joystick */
 
-#define USEJOYSTICK
+#undef USEJOYSTICK
 
 /* Don't enable the joystick by default. Otherwise, it defaults to
    controlling player 1. Uncomment this if your joystick doesn't work
