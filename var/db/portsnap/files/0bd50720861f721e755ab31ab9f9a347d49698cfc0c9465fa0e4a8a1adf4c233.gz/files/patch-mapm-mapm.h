--- mapm/mapm.h.orig	2008-04-04 20:05:29.000000000 +0000
+++ mapm/mapm.h	2008-03-16 13:53:32.000000000 +0000
@@ -19,7 +19,7 @@
 #define command void /* needed if INC_SHELL was not defined */
 #endif
 
-#include "system.h"
+#include "../lib/system.h"
 
 
 /***************** MAPM Constants *****************/
