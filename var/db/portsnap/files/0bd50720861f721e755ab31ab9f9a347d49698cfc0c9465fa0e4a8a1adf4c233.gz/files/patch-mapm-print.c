--- mapm/print.c.orig	2008-04-04 20:05:29.000000000 +0000
+++ mapm/print.c	2008-03-27 21:34:40.000000000 +0000
@@ -540,7 +540,7 @@
     }    
 }
 
-#define MAPPING_HEAD1\
+#define MAPPING_HEAD1 \
 "                                                      2nd    Left "
 #define MAPPING_HEAD2 \
 " Num  Name      Assignment Chrom     LOD   Mapping    Like   Locus     Errors"
