--- ./src/string.cpp.orig	2014-05-06 16:01:31.219239454 +0200
+++ ./src/string.cpp	2014-05-06 15:59:03.134249779 +0200
@@ -19,6 +19,7 @@
 #include "support/win32/support.h"
 #endif // _LIBCPP_MSVCRT
 #include <stdio.h>
+#include <stdlib.h>
 
 _LIBCPP_BEGIN_NAMESPACE_STD
 
