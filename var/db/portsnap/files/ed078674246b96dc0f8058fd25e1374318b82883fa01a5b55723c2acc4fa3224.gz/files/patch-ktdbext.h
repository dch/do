--- ktdbext.h.orig	2012-05-25 01:44:34.000000000 +0800
+++ ktdbext.h	2013-12-28 01:21:30.081508681 +0800
@@ -16,6 +16,7 @@
 #ifndef _KTDBEXT_H                       // duplication check
 #define _KTDBEXT_H
 
+#include <myconf.h>
 #include <ktcommon.h>
 #include <ktutil.h>
 #include <ktulog.h>
