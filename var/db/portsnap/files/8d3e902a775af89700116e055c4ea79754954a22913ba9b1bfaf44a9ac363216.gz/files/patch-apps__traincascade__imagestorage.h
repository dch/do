--- ./apps/traincascade/imagestorage.h.orig	2013-07-10 07:49:00.000000000 -0400
+++ ./apps/traincascade/imagestorage.h	2013-10-23 23:52:32.000000000 -0400
@@ -1,6 +1,7 @@
 #ifndef _OPENCV_IMAGESTORAGE_H_
 #define _OPENCV_IMAGESTORAGE_H_
 
+#include <cstdio>
 #include "highgui.h"
 
 using namespace cv;
