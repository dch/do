--- ./samples/cpp/tutorial_code/core/how_to_scan_images/how_to_scan_images.cpp.orig	2013-10-26 09:51:39.000000000 -0400
+++ ./samples/cpp/tutorial_code/core/how_to_scan_images/how_to_scan_images.cpp	2013-10-26 09:51:47.000000000 -0400
@@ -1,4 +1,4 @@
-﻿#include <opencv2/core/core.hpp>
+#include <opencv2/core/core.hpp>
 #include <opencv2/highgui/highgui.hpp>
 #include <iostream>
 #include <sstream>
@@ -213,4 +213,4 @@
     }
 
     return I;
-}
\ No newline at end of file
+}
