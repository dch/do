--- ./modules/contrib/src/spinimages.cpp.orig	2013-10-26 07:55:45.000000000 -0400
+++ ./modules/contrib/src/spinimages.cpp	2013-10-26 07:56:13.000000000 -0400
@@ -46,6 +46,7 @@
 #include <functional>
 #include <fstream>
 #include <limits>
+#include <numeric>
 #include <set>
 
 using namespace cv;
