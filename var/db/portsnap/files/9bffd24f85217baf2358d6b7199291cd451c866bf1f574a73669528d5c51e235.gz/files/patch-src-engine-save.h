--- src/engine/save.h.orig	2009-12-29 03:43:28.000000000 +0300
+++ src/engine/save.h	2013-09-14 07:46:32.762415408 +0400
@@ -22,6 +22,7 @@
 #include "singleton.h"
 #include <irrlicht/irrlicht.h>
 #include <map>
+#include <ctime>
 
 // Namespaces
 using namespace irr;
