--- include/libast.h.orig	Tue Oct  1 00:43:38 2002
+++ include/libast.h	Sat Oct  5 19:11:22 2002
@@ -40,6 +40,7 @@
 # endif
 #endif
 
+#include <limits.h>
 #include <stdio.h>
 #include <stdlib.h>
 #include <time.h>
