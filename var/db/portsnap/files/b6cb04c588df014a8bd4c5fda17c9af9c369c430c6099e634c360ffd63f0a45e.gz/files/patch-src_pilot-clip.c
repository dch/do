--- src/pilot-clip.c.orig	Sun Aug  6 16:55:58 2006
+++ src/pilot-clip.c	Tue Nov 21 19:24:15 2006
@@ -18,6 +18,7 @@
  */
 
 #include <stdio.h>
+#include <sys/types.h>
 #include <netinet/in.h>
 
 #include "pi-source.h"
