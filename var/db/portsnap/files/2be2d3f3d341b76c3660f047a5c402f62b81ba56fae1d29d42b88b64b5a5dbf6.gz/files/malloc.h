#ifndef _MALLOC_H
#define	_MALLOC_H
#include <stdlib.h>
#endif /* _MALLOC_H */
