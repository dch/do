--- ecasound/eca-curses.cpp.orig	2009-04-11 09:44:06.000000000 +0000
+++ ecasound/eca-curses.cpp
@@ -27,6 +27,7 @@
 #include <cstdlib>
 #include <iostream>
 #include <map>
+#include <cstring>
 #include <string>
 
 #if defined(ECA_PLATFORM_CURSES) 
