diff -ru src.orig/structures/linkedlist.c src/structures/linkedlist.c
--- src.orig/structures/linkedlist.c	Fri May 27 23:17:45 2005
+++ src/structures/linkedlist.c	Sun Sep 16 01:14:37 2007
@@ -26,7 +26,6 @@
 #include "linkedlist.h"
 
 #include <stdlib.h>
-#include <malloc.h>
 #include <string.h>
 
 /** An empty item. */
