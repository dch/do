--- src/libsync/syncjournalfilerecord.h.orig	2015-03-16 14:28:58 UTC
+++ src/libsync/syncjournalfilerecord.h
@@ -14,6 +14,7 @@
 #ifndef SYNCJOURNALFILERECORD_H
 #define SYNCJOURNALFILERECORD_H
 
+#include <time.h>
 #include <QString>
 #include <QDateTime>
 
