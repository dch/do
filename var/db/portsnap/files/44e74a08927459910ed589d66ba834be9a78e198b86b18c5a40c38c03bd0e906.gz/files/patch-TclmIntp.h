--- TclmIntp.h.orig	2013-05-14 11:24:39.000000000 +0200
+++ TclmIntp.h	2013-05-14 11:25:36.000000000 +0200
@@ -64,6 +64,5 @@
 	int current_song;
 	int current_dev;
 	int current_patch;
-	Event *next_event;
 };
 #endif
