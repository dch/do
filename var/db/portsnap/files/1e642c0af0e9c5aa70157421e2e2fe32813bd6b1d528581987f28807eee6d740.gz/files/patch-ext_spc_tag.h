--- ext/spc/tag.h.orig	2013-03-10 09:54:22.000000000 +0000
+++ ext/spc/tag.h	2013-03-10 09:54:34.000000000 +0000
@@ -16,7 +16,6 @@
  * Boston, MA 02111-1307, USA.
  */
 
-#include <glib/gtypes.h>
 #include <glib.h>
 
 typedef struct
