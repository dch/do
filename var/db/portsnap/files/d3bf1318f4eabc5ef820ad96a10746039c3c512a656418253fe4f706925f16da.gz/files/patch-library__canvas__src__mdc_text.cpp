--- ./library/canvas/src/mdc_text.cpp.orig	2014-08-20 19:34:24.000000000 -0400
+++ ./library/canvas/src/mdc_text.cpp	2014-08-20 19:35:12.000000000 -0400
@@ -1,4 +1,5 @@
 #include <cstring>
+#include <cstdlib>
 #include "stdafx.h"
 
 #include <string.h>
