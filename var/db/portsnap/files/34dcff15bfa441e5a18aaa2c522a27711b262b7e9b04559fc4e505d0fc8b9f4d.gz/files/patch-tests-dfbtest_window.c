--- tests/dfbtest_window.c
+++ tests/dfbtest_window.c
@@ -41,6 +41,7 @@
 #include <stdlib.h>
 #include <string.h>
 #include <unistd.h>
+#include <signal.h>
 
 #include <direct/messages.h>
 #include <direct/util.h>
