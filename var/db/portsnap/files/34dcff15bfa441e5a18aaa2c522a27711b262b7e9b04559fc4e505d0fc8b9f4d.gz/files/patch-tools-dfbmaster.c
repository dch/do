--- tools/dfbmaster.c
+++ tools/dfbmaster.c
@@ -26,6 +26,7 @@
 */
 
 #include <config.h>
+#include <signal.h>
 
 #include <direct/messages.h>
 
