--- lib/direct/conf.c
+++ lib/direct/conf.c
@@ -30,6 +30,7 @@
 
 #include <stdlib.h>
 #include <string.h>
+#include <signal.h>
 
 #include <direct/conf.h>
 #include <direct/mem.h>
