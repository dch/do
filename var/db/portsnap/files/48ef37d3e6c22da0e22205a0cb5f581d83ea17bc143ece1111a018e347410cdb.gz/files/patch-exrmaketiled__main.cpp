--- ./exrmaketiled/main.cpp.orig	2013-11-25 20:49:56.000000000 +0100
+++ ./exrmaketiled/main.cpp	2014-03-24 18:28:37.916466529 +0100
@@ -43,6 +43,7 @@
 #include "makeTiled.h"
 
 #include <iostream>
+#include <cstring>
 #include <exception>
 #include <string>
 #include <string.h>
