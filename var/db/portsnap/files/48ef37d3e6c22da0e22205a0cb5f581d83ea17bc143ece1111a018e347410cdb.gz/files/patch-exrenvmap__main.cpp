--- ./exrenvmap/main.cpp.orig	2013-11-25 20:49:55.000000000 +0100
+++ ./exrenvmap/main.cpp	2014-03-24 18:28:37.906458972 +0100
@@ -47,6 +47,7 @@
 #include <ImfHeader.h>
 
 #include <iostream>
+#include <cstring>
 #include <exception>
 #include <string>
 #include <string.h>
