--- hints/freebsd.sh.orig	Thu Jun  4 09:45:34 1998
+++ hints/freebsd.sh	Thu Jun  4 09:44:16 1998
@@ -1 +1,2 @@
 i_sysfilio='undef'
+plibpth='$plibpth /usr/lib/aout'
