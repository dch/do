--- src/tray.c.orig	2005-01-29 19:34:17.000000000 +0100
+++ src/tray.c	2010-12-01 22:20:00.000000000 +0100
@@ -20,6 +20,7 @@
  * USA
  */
 
+#include "common.h"
 #include "tray.h"
 #include "../pixmaps/rip1.xpm"
 #include "../pixmaps/menuplay.xpm"
