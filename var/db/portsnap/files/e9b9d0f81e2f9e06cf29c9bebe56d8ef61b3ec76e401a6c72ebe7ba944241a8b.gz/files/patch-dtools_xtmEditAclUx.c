--- dtools/xtmEditAclUx.c	Sun May  4 18:25:10 1997
+++ dtools/xtmEditAclUx.c	Mon Jul 23 20:34:40 2001
@@ -37,2 +37,3 @@
 
+#include <sys/types.h>
 #include <grp.h>
