--- asprint.c~	Tue Mar 11 22:52:39 1997
+++ asprint.c	Sat Aug 16 20:00:57 1997
@@ -19,6 +19,7 @@
 #include <string.h>
 #include <stdlib.h>
 #include <sys/stat.h>
+#include <limits.h>
 #include <dirent.h>
 #include <unistd.h>
 
