--- net/net-ipv6.cpp	Thu Apr 24 10:53:26 2003
+++ net/net-ipv6.cpp	Thu Sep 23 19:08:53 2004
@@ -59,7 +59,6 @@
 #include "config.h"
 #include "net.h"
 #include "vic_tcl.h"
-#include "inet_ntop.h"
 
 #include "inet6.h"
 #include "net-addr.h"
