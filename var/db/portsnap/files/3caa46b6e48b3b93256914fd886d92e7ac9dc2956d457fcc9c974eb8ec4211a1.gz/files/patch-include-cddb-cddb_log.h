--- include/cddb/cddb_log.h.orig	2005-03-11 22:29:29.000000000 +0100
+++ include/cddb/cddb_log.h	2014-03-20 16:00:15.000000000 +0100
@@ -19,7 +19,7 @@
     Boston, MA  02111-1307, USA.
 */
 
-#ifndef CDDB_LOH_H
+#ifndef CDDB_LOG_H
 #define CDDB_LOG_H
 
 #ifdef __cplusplus
