--- include/cddb/cddb_log_ni.h.orig	2005-03-11 22:29:29.000000000 +0100
+++ include/cddb/cddb_log_ni.h	2014-03-20 16:00:24.000000000 +0100
@@ -19,7 +19,7 @@
     Boston, MA  02111-1307, USA.
 */
 
-#ifndef CDDB_LOH_NI_H
+#ifndef CDDB_LOG_NI_H
 #define CDDB_LOG_NI_H
 
 #ifdef __cplusplus
