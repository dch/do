--- widgets.c.orig	2011-07-09 18:51:18.000000000 +0900
+++ widgets.c	2012-08-14 04:13:36.000000000 +0900
@@ -1,6 +1,5 @@
 #include <unistd.h>
 #include <sys/types.h>
-#include <sys/timeb.h>
 #include <sys/stat.h>
 #include <string.h>
 
