--- tildepath.c.orig	Fri Aug 24 07:06:53 2001
+++ tildepath.c	Fri Aug 24 07:06:59 2001
@@ -38,7 +38,6 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <pwd.h>
-#include <malloc.h>
 #include <string.h>
 
 /*
