--- logview/logview-manager.c.orig	2009-03-21 17:25:27.000000000 -0400
+++ logview/logview-manager.c	2009-03-21 17:25:37.000000000 -0400
@@ -25,6 +25,7 @@
 
 #include <glib/gi18n.h>
 
+#include "logview-app.h"
 #include "logview-prefs.h"
 #include "logview-marshal.h"
 
