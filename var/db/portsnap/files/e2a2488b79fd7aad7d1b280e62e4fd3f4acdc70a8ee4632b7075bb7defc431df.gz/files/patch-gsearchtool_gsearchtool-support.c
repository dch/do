--- gsearchtool/gsearchtool-support.c.orig	2008-12-19 16:53:22.000000000 -0500
+++ gsearchtool/gsearchtool-support.c	2009-02-27 17:30:06.000000000 -0500
@@ -32,6 +32,7 @@
 #include <string.h>
 #include <glib/gi18n.h>
 #include <glib.h>
+#include <sys/types.h>
 #include <regex.h>
 #include <gdk/gdkx.h>
 #include <libart_lgpl/art_rgb.h>
