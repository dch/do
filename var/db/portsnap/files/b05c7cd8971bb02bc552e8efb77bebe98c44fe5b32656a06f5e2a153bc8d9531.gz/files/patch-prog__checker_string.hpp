--- prog/hecker_string.hpp.orig	2011-07-02 23:09:09.000000000 +0200
+++ prog/checker_string.hpp	2014-02-11 22:42:24.000000000 +0100
@@ -6,6 +6,7 @@
 
 #include <stdio.h>
 
+#include "errors.hpp"
 #include "aspell.h"
 
 #include "vector.hpp"
