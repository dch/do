--- prog/checker_string.cpp.orig	Thu Jul 17 19:39:02 2003
+++ prog/checker_string.cpp	Thu Jul 17 19:39:09 2003
@@ -4,6 +4,7 @@
 // license along with this library if you did not you can find
 // it at http://www.gnu.org/.
 
+#include <assert.h>
 #include "checker_string.hpp"
 #include "speller.hpp"
 #include "document_checker.hpp"
