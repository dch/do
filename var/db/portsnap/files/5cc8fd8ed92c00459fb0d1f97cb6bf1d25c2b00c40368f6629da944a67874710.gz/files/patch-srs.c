--- srs.c-orig	2014-07-17 22:31:53.000000000 +0200
+++ srs.c	2014-07-17 22:32:29.000000000 +0200
@@ -283,7 +283,7 @@
 */
 int display_help(void)
 {
-    printf("srs - libsrs_alt library http://srs.mirtol.com/\n(C)2004 Miles Wilton\n\n");
+    printf("srs - libsrs_alt library http://opsec.eu/src/srs/\n(C)2004 Miles Wilton\n\n");
     printf("Syntax: srs <flags> <address>+\n\n");
     printf("    Actions\n");
     printf("        -d               Run daemon\n");
