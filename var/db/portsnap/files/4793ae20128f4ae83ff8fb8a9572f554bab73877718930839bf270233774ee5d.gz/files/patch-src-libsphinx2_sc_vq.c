--- src/libsphinx2/sc_vq.c.orig	2007-12-06 18:38:16.000000000 +0100
+++ src/libsphinx2/sc_vq.c	2007-12-06 18:38:36.000000000 +0100
@@ -64,6 +64,7 @@
 
 #include <stdio.h>
 #include <stdlib.h>
+#include <string.h>
 #include <assert.h>
 #include <limits.h>
 
