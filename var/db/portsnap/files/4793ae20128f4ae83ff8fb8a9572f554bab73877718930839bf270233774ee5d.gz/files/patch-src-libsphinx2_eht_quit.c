--- src/libsphinx2/eht_quit.c.orig	2007-12-06 18:21:53.000000000 +0100
+++ src/libsphinx2/eht_quit.c	2007-12-06 18:22:13.000000000 +0100
@@ -85,6 +85,7 @@
  */
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <stdarg.h>
 
 void
