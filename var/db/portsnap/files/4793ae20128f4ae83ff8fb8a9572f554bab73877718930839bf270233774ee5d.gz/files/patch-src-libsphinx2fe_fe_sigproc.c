--- src/libsphinx2fe/fe_sigproc.c.orig	2007-12-06 18:34:10.000000000 +0100
+++ src/libsphinx2fe/fe_sigproc.c	2007-12-06 18:34:25.000000000 +0100
@@ -43,7 +43,7 @@
 
 #ifndef	M_PI
 #define M_PI	(3.14159265358979323846)
-#endif	M_PI
+#endif
 
 #define FORWARD_FFT 1
 #define INVERSE_FFT -1
