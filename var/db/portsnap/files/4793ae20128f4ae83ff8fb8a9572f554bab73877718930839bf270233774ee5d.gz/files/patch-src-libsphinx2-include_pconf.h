--- src/libsphinx2/include/pconf.h.orig	2007-12-06 18:24:09.000000000 +0100
+++ src/libsphinx2/include/pconf.h	2007-12-06 18:24:20.000000000 +0100
@@ -124,4 +124,4 @@
 	   char * (*GetDefault)(char const *, char const *), char last);
 void pusage(char *prog, Config_t *cp);
 
-#endif _PCONF_
+#endif
