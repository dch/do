--- src/libsphinx2/r_agc_noise.c.orig	2007-12-06 18:28:21.000000000 +0100
+++ src/libsphinx2/r_agc_noise.c	2007-12-06 18:28:49.000000000 +0100
@@ -34,6 +34,7 @@
  *
  */
 #include <stdio.h>
+#include <string.h>
 
 #include "s2types.h"
 #include "c.h"
