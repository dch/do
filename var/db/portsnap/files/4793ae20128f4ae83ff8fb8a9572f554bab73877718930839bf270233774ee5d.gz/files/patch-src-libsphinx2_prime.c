--- src/libsphinx2/prime.c.orig	2007-12-06 18:27:41.000000000 +0100
+++ src/libsphinx2/prime.c	2007-12-06 18:27:51.000000000 +0100
@@ -75,5 +75,4 @@
     }
 }
 
-#endif MAIN
-
+#endif
