--- gnome-pty-helper/gnome-pty-helper.c
+++ gnome-pty-helper/gnome-pty-helper.c
@@ -51,7 +51,6 @@
 #include <stdlib.h>
 #include <string.h>
 #include <stdio.h>
-#include <utmp.h>
 #include <grp.h>
 #include "gnome-pty.h"
 #include "gnome-login-support.h"
