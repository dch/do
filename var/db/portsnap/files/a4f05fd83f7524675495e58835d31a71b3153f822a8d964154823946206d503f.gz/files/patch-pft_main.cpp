--- pft/main.cpp.orig	Tue Jan  4 13:01:00 2005
+++ pft/main.cpp	Sun May 22 19:22:22 2005
@@ -28,6 +28,7 @@
 #include <sys/types.h>			// open(), close(), write()
 #include <sys/stat.h>
 #include <fcntl.h>
+#include <string.h>
 #endif //UNIX
 
 #include "fxstrings.h"
