--- pivotx/data.php.orig	2011-08-05 02:40:39.000000000 +0900
+++ pivotx/data.php	2011-08-16 10:55:32.000000000 +0900
@@ -616,6 +616,7 @@
         'allow_comments' => '1',
         'allow_paragraphs' => '0',
         'chmod' => '0644',
+        'chmod_dir' => '0755',
         'cookie_length' => '1814400',
         'db_version' => $dbversion,
         'debug' => 0,
