--- src/feature.h.orig	Sat Sep 15 17:19:46 2001
+++ src/feature.h	Sat Sep 15 17:20:24 2001
@@ -254,8 +254,8 @@
 #define APL_NAME	"Eterm"
 
 /* COLORTERM, TERM environment variables */
-#define TERMENV       "Eterm"
-#define COLORTERMENV  "Eterm"
+#define TERMENV       "kterm"
+#define COLORTERMENV  "kterm"
 
 #ifdef NO_MOUSE_REPORT
 # ifndef NO_MOUSE_REPORT_SCROLLBAR
