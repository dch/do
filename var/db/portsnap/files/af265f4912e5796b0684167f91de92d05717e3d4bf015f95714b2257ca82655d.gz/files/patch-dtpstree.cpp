--- dtpstree.cpp.orig	2010-08-05 16:01:47.000000000 +0800
+++ dtpstree.cpp	2013-10-19 19:48:34.750149337 +0800
@@ -21,6 +21,7 @@
 
 #include <cerrno>
 #include <climits>
+#include <clocale>
 #include <cstdarg>
 #include <cstdio>
 #include <cstdlib>
