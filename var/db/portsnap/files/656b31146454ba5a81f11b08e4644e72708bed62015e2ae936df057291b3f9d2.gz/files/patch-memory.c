--- memory.c.orig	Sun Sep 14 23:24:09 2008
+++ memory.c	Sun Sep 14 21:58:40 2008
@@ -12,6 +12,7 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <assert.h>
+#include <string.h>
 
 #include "enigma.h"
 
