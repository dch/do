--- compress.c.old	2008-01-17 17:19:55.000000000 -0200
+++ compress.c	2008-01-17 17:20:09.000000000 -0200
@@ -15,7 +15,7 @@
 
 #include <stdlib.h>
 #include <stdio.h>
-#include <utime.h>
+#include <time.h>
 #include <unistd.h>
 #include <zlib.h>
 
