--- src/cbedic.cpp.old	Fri Dec 12 04:51:13 2003
+++ src/cbedic.cpp	Fri Dec 12 04:51:35 2003
@@ -24,10 +24,12 @@
 **********************************************************************/
 
 
-#include <iostream.h>
+#include <iostream>
 #include <stdlib.h>
 #include <unistd.h>
 #include <string.h>
+
+using namespace std;
 
 #include "defaults.h"
 #include "translator.h"
