--- DNS/Type.py.orig	2011-03-16 23:06:39.000000000 +0300
+++ DNS/Type.py	2011-03-29 12:44:27.000000000 +0400
@@ -74,7 +74,7 @@
 # added identifying header to top of each file
 #
 # Revision 1.3  2001/07/19 07:38:28  anthony
-# added type code for SRV. From Michael Str�der.
+# added type code for SRV. From Michael Ströder.
 #
 # Revision 1.2  2001/07/19 06:57:07  anthony
 # cvs keywords added
