--- DNS/Lib.py.orig	2011-03-16 23:06:39.000000000 +0300
+++ DNS/Lib.py	2011-03-29 12:42:45.000000000 +0400
@@ -706,10 +706,10 @@
 # added identifying header to top of each file
 #
 # Revision 1.7  2001/07/19 07:50:44  anthony
-# Added SRV (RFC 2782) support. Code from Michael Str�der.
+# Added SRV (RFC 2782) support. Code from Michael Ströder.
 #
 # Revision 1.6  2001/07/19 07:39:18  anthony
-# 'type' -> 'rrtype' in getRRheader(). Fix from Michael Str�der.
+# 'type' -> 'rrtype' in getRRheader(). Fix from Michael Ströder.
 #
 # Revision 1.5  2001/07/19 07:34:19  anthony
 # oops. glitch in storeRR (fixed now).
