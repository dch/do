--- input/vorbis/oggstat.cpp.orig
+++ input/vorbis/oggstat.cpp
@@ -1,3 +1,4 @@
+#include <cstdlib>
 #include "oggstat.h"
 
 using namespace std;
