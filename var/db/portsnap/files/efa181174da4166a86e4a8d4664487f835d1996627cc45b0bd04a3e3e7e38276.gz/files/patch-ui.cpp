--- ui.cpp.orig	Fri Sep 17 09:54:41 2004
+++ ui.cpp	Tue Sep 21 20:28:28 2004
@@ -1,4 +1,5 @@
 #include "ui.h"
+#include <cstdio>
 
 using namespace std;
 
