--- base.cpp.orig
+++ base.cpp
@@ -1,4 +1,5 @@
-#include <stdio.h>
+#include <cstdio>
+#include <cstdlib>
 #include <dlfcn.h>
 #include <dirent.h>
 
