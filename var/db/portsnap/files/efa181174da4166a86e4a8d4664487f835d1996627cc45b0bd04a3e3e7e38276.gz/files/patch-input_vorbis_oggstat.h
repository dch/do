--- input/vorbis/oggstat.h.orig	Thu Sep 16 08:03:59 2004
+++ input/vorbis/oggstat.h	Tue Sep 21 21:08:41 2004
@@ -5,6 +5,7 @@
 #include <sys/mman.h>
 #include <fcntl.h>
 #include <string>
+#include <cstdio>
 #include <vorbis/codec.h>
 
 #include "input.h"
