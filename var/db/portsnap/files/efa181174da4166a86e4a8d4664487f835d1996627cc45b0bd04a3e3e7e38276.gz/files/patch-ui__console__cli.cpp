--- ui/console/cli.cpp.orig
+++ ui/console/cli.cpp
@@ -1,4 +1,5 @@
-#include <stdio.h>
+#include <cstdio>
+#include <cstdlib>
 #include "cli.h"
 
 using namespace std;
