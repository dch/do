--- serial.h.bak	Fri Feb 20 07:26:31 2004
+++ serial.h	Fri Feb 20 07:26:45 2004
@@ -65,6 +65,6 @@
 	void
 );
 
-#define DATA_DUMP_FILE "dump"
+/* #define DATA_DUMP_FILE "dump" */
 
 #endif
