*** nspmod.h.orig	Wed Sep  3 14:58:53 1997
--- nspmod.h	Wed Sep  3 13:47:40 1997
***************
*** 3,8 ****
--- 3,9 ----
  #endif
  
  typedef struct {
+     i15x bits;		/* -b # */
      i15x onlyCh;	/* -c # */
      i15x showEvents;	/* -e, -ee */
      u16x outRate;	/* -f # */
