*** dacio.h.orig	Wed Sep  3 14:58:39 1997
--- dacio.h	Wed Sep  3 13:49:32 1997
***************
*** 3,8 ****
--- 3,9 ----
  #endif
  
  typedef struct {
+     int bits;
      int speed;
      int stereo;
  } DacioConfInfo;
