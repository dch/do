--- mix.exs.orig	2015-07-02 13:24:56 UTC
+++ mix.exs
@@ -30,7 +30,6 @@ defmodule LagerLogger.Mixfile do
 
   defp deps do
     [
-      {:lager, ">= 2.1.0"},
     ]
   end
 end
