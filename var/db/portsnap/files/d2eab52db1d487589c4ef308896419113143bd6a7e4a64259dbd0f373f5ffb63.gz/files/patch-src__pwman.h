--- ./src/pwman.h.orig	2009-08-26 16:18:55.000000000 +0000
+++ ./src/pwman.h	2010-09-14 02:40:40.029593205 +0000
@@ -26,6 +26,7 @@
 #include <string.h>
 #include <config.h>
 #include <time.h>
+#include <stdlib.h>
 #include <stdarg.h>
 
 #define CONF_FILE 	".pwmanrc" 
