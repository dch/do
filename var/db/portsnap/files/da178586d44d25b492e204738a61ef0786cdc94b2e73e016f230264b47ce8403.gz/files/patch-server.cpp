--- server.cpp	Fri Sep 10 14:43:24 2004
+++ server.cpp.new	Sat Oct 23 15:40:21 2004
@@ -19,6 +19,8 @@
 *
 ***/
 
+#include <sys/time.h>
+
 #include "bnbt.h"
 #include "client.h"
 #include "config.h"
