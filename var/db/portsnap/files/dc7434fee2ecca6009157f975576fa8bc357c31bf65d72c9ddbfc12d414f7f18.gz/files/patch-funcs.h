--- funcs.h.orig	Mon Feb 24 12:45:37 1992
+++ funcs.h	Sat May 20 01:41:19 2000
@@ -54,3 +54,3 @@
 	public void vbell ();
-	public void clear ();
+	public void clearscr ();
 	public void clear_eol ();
