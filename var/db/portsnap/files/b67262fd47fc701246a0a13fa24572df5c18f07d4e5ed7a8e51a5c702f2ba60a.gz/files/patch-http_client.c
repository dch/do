--- http_client.c.orig	Fri Dec 17 00:27:43 2004
+++ http_client.c	Wed Feb  2 21:33:28 2005
@@ -37,6 +37,7 @@
 # include <sys/socket.h>
 # include <sys/select.h>
 # include <netdb.h>
+# include <netinet/in.h>
 # include <fcntl.h>
 #elif defined(SYSTEM_WIN32)
 # include <winsock2.h>
