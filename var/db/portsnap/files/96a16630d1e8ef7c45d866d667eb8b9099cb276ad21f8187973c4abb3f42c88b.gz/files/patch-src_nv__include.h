--- src/nv_include.h.orig	2012-07-17 06:48:19 UTC
+++ src/nv_include.h
@@ -24,9 +24,6 @@
 /* All drivers initialising the SW cursor need this */
 #include "mipointer.h"
 
-/* All drivers implementing backing store need this */
-#include "mibstore.h"
-
 #include "micmap.h"
 
 #include "xf86DDC.h"
