--- src/riva_include.h.orig	2012-07-17 06:48:45 UTC
+++ src/riva_include.h
@@ -22,9 +22,6 @@
 /* All drivers initialising the SW cursor need this */
 #include "mipointer.h"
 
-/* All drivers implementing backing store need this */
-#include "mibstore.h"
-
 #include "micmap.h"
 
 #include "xf86DDC.h"
