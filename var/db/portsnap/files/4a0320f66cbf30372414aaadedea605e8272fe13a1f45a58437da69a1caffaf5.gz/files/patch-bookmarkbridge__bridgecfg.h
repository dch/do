--- bookmarkbridge/bridgecfg.h.orig	2013-12-06 03:29:29.000000000 +0900
+++ bookmarkbridge/bridgecfg.h	2013-12-06 03:29:46.000000000 +0900
@@ -31,6 +31,7 @@
 #include "bknode.h"
 #include "bkexcept.h"
 
+#include <cstdlib>
 #include <vector>
 #include <qstring.h>
