--- src/support.h.orig	2014-02-11 08:51:06.175251265 +0100
+++ src/support.h	2014-02-11 08:51:14.270248604 +0100
@@ -20,7 +20,7 @@
 #ifndef __IMAGINATION_SUPPORT_H
 #define __IMAGINATION_SUPPORT_H
 
-#define PLUGINS_INSTALLED 0
+#define PLUGINS_INSTALLED 1
 
 #ifdef HAVE_CONFIG_H
 #  include <config.h>
