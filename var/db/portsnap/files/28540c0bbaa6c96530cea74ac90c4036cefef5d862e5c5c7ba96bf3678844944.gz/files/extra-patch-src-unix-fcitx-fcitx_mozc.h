--- src/unix/fcitx/fcitx_mozc.h.bak	2015-07-13 04:37:03.716155000 +0900
+++ src/unix/fcitx/fcitx_mozc.h	2015-07-13 04:37:03.758916000 +0900
@@ -39,7 +39,7 @@
 
 #include "base/port.h"
 #include "base/run_level.h"
-#include "session/commands.pb.h"
+#include "protocol/commands.pb.h"
 #include "client/client_interface.h"
 #include "mozc_connection.h"
 
