--- src/unix/fcitx/fcitx_key_translator.h.bak	2015-07-13 04:37:03.714894000 +0900
+++ src/unix/fcitx/fcitx_key_translator.h	2015-07-13 04:37:03.756571000 +0900
@@ -38,7 +38,7 @@
 #include <fcitx-config/hotkey.h>
 
 #include "base/port.h"
-#include "session/commands.pb.h"
+#include "protocol/commands.pb.h"
 #include <fcitx/ime.h>
 
 namespace mozc {
