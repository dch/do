--- src/unix/fcitx/mozc_connection.h.bak	2015-07-13 04:37:03.717225000 +0900
+++ src/unix/fcitx/mozc_connection.h	2015-07-13 04:37:03.761331000 +0900
@@ -38,7 +38,7 @@
 #include <fcitx/instance.h>
 
 #include "base/port.h"
-#include "session/commands.pb.h"
+#include "protocol/commands.pb.h"
 #include "unix/fcitx/fcitx_key_event_handler.h"
 
 namespace mozc {
