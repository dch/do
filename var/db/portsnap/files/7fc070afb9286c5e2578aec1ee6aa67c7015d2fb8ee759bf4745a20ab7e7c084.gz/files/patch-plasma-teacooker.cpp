--- ./plasma-teacooker.cpp.orig	2009-02-10 02:04:18.000000000 -0500
+++ ./plasma-teacooker.cpp	2009-02-10 02:04:35.000000000 -0500
@@ -44,7 +44,6 @@
 
 #include <plasma/svg.h>
 #include <plasma/theme.h>
-#include <plasma/widgets/icon.h>
 #include <plasma/containment.h>
 // #include <plasma/tooltipmanager.h>
 
