--- VkProgram.C.orig
+++ VkProgram.C
@@ -34,6 +34,8 @@
 #endif
 = "$Id: VkProgram.C,v 1.8 2009/03/21 11:44:34 jostle Exp $";
 
+#include <cstdlib>
+
 #include <Vk/VkProgram.h>
 
 using namespace std;
