--- GUI/Widgets/Fl_Loop.h.orig	Wed Nov 22 13:00:49 2006
+++ GUI/Widgets/Fl_Loop.h	Wed Nov 22 13:01:09 2006
@@ -18,7 +18,7 @@
 
 #include <FL/Fl.H>
 #include <FL/Fl_Double_Window.H>
-#include <iostream.h>
+#include <iostream>
 
 #ifndef LOOPWIDGET
 #define LOOPWIDGET
