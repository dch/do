--- kbd.c.orig	2013-03-12 19:47:22.000000000 +0400
+++ kbd.c	2013-03-12 19:47:24.000000000 +0400
@@ -582,10 +582,10 @@
 				case 'B': ev.x = KBD_DOWN; break;
 				case 'C': ev.x = KBD_RIGHT; break;
 				case 'D': ev.x = KBD_LEFT; break;
-				case 'F':
+				case 'F': ev.x = KBD_END; break;
 				case 'K':
 				case 'e': ev.x = KBD_END; break;
-				case 'H':
+				case 'H': ev.x = KBD_HOME; break;
 				case 0: ev.x = KBD_HOME; break;
 				case 'V':
 				case 'I': ev.x = KBD_PAGE_UP; break;
