--- ./sys_linux.c.orig	Sat Jun 10 12:08:13 2006
+++ ./sys_linux.c	Sat Jun 10 12:08:13 2006
@@ -27,7 +27,7 @@
 // user preference directory
 
 #if defined (USERPREF_DIR)
-char *prefdir=  ".quake";
+char *prefdir=  ".tenebrae";
 #endif
 
 #if defined (BASEDIR)
