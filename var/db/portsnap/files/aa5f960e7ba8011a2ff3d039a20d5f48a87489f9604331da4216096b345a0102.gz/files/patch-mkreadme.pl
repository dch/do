--- mkreadme.pl.orig	Tue Feb 28 21:37:42 2006
+++ mkreadme.pl	Tue Feb 28 21:38:32 2006
@@ -413,7 +413,7 @@
 =unix
      TMPDIR
           Root of directory to store partial messages awaiting 
-          reassembly.  Default is "/usr/tmp".   Partial messages
+          reassembly.  Default is "/tmp".   Partial messages
 	  are stored in subdirectories of $TMPDIR/m-prts-$USER/
 
 =pc os2
