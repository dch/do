--- lib/coding.c.orig	1997-01-24 16:08:40.000000000 +0900
+++ lib/coding.c	2012-05-10 00:14:28.797032559 +0900
@@ -28,6 +28,7 @@
 #include	<config.h>
 
 #include	<stdio.h>
+#include	<string.h>
 #include	<errno.h>
 
 #include	<interface.h>
