--- src/display/s3.c.orig	1997-01-24 09:38:24.000000000 +0900
+++ src/display/s3.c	2012-05-10 00:14:28.885871613 +0900
@@ -43,7 +43,6 @@
 #include	<sys/mman.h>
 #include	<linux/mm.h>
 #include	<sys/kd.h>
-#undef free
 #include	<stdlib.h>
 
 #include	<mem.h>
