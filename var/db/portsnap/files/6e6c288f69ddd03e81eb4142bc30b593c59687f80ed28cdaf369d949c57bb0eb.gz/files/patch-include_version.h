--- include/version.h.orig	1997-01-30 10:30:50.000000000 +0900
+++ include/version.h	2012-05-10 00:14:28.566551540 +0900
@@ -1 +1 @@
-#define VERSION "ver.0.3 (01/28)"
+#define VERSION "ver.0.3 (1998/10/31)"
