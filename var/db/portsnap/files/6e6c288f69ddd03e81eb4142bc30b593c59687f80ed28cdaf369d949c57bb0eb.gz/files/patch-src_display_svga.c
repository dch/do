--- src/display/svga.c.orig	1997-01-25 17:33:29.000000000 +0900
+++ src/display/svga.c	2012-05-10 00:14:28.898552112 +0900
@@ -45,7 +45,6 @@
 /* #include	<linux/mm.h> */
 #include	<sys/kd.h>
 #endif
-#undef free
 #include	<stdlib.h>
 
 #include	<mem.h>
