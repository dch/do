--- kca2et.c.orig	2011-09-05 11:37:39.000000000 +0800
+++ kca2et.c	2011-09-05 11:37:51.000000000 +0800
@@ -10,7 +10,7 @@
 #include <stdio.h>
 #include <stdlib.h>
 
-void main(int argc, char **argv)
+int main(int argc, char **argv)
 {
 	int i;
 	unsigned char tmp[60];
