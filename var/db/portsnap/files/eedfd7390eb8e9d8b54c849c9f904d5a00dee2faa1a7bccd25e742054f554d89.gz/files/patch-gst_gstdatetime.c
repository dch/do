--- gst/gstdatetime.c.orig	2011-12-11 18:45:55 UTC
+++ gst/gstdatetime.c
@@ -21,8 +21,8 @@
 #include "config.h"
 #endif
 
-#include "glib-compat-private.h"
 #include "gst_private.h"
+#include "glib-compat-private.h"
 #include "gstdatetime.h"
 #include <glib.h>
 #include <math.h>
