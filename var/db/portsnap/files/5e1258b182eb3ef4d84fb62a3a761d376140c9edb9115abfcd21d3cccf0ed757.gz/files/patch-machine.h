--- machine.h.orig	Wed Oct 12 07:19:52 1994
+++ machine.h	Tue Feb  3 23:50:25 1998
@@ -11,4 +11,4 @@
  *	PC88VA		PC-88VA
  */
 
-#define Sun
+#define SUN
