--- cd-console.cpp.orig	Mon Jun  3 19:46:12 2002
+++ cd-console.cpp	Mon Jun  3 19:46:01 2002
@@ -1,4 +1,5 @@
 #include <stdlib.h>
+#include <string.h>
 #include <unistd.h>
 
 #ifdef OS_BSD
