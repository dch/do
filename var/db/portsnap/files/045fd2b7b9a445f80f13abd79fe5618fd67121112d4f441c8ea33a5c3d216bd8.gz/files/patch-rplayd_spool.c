--- rplayd/spool.c.orig	Thu Mar 11 06:14:38 1999
+++ rplayd/spool.c	Wed Jun 21 23:20:13 2000
@@ -1127,8 +1127,8 @@
 				spool_flow_pause(sp);
 			    }
 			}
-#endif /* HAVE_CDROM */
 		    }
+#endif /* HAVE_CDROM */
 		}
 		else
 		{
