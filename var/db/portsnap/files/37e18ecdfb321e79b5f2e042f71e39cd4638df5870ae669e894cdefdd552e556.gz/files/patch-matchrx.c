--- matchrx.c.orig	Wed Jun 21 01:12:18 2000
+++ matchrx.c	Thu Jun 16 17:31:09 2005
@@ -23,6 +23,7 @@
 
 
 #include <stdio.h>
+#include <sys/types.h>
 #include <regex.h>
 #include <stdarg.h>
 #include <stdlib.h>
