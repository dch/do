--- config.h.orig	2014-06-08 18:25:19.000000000 +0200
+++ config.h	2014-06-08 18:25:39.000000000 +0200
@@ -8,7 +8,7 @@
 
 /* Configuration file */
 /*
-#define CONFIG_FILE "/etc/whois.conf"
+#define CONFIG_FILE "%%MWHOISCONF%%"
 */
 
 
