--- mix.exs.orig	2015-07-05 09:09:05 UTC
+++ mix.exs
@@ -6,7 +6,6 @@ defmodule HTTPotion.Mixfile do
      version: "2.1.0",
      elixir:  "~> 1.0",
      description: description,
-     deps: deps,
      package: package]
   end
 
