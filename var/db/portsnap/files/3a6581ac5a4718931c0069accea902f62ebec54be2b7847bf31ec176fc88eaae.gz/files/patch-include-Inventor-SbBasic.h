--- include/Inventor/SbBasic.h.orig	2010-03-02 21:20:09.000000000 +0800
+++ include/Inventor/SbBasic.h	2013-12-01 05:17:51.275860731 +0800
@@ -25,6 +25,7 @@
 \**************************************************************************/
 
 #include <Inventor/C/basic.h>
+#include <Inventor/C/errors/debugerror.h>
 
 /* ********************************************************************** */
 /* Trap people trying to use Inventor headers while compiling C source code.
