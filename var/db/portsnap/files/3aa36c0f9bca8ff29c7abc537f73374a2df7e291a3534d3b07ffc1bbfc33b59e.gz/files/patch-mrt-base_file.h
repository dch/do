--- mrt/base_file.h.orig	2013-11-16 13:43:12.000000000 +0100
+++ mrt/base_file.h	2013-11-16 13:44:09.000000000 +0100
@@ -20,6 +20,7 @@
 */
 
 #include <string>
+#include <sys/types.h>
 #include "export_mrt.h"
 
 namespace mrt {
