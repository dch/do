--- rf/ustr.cpp.orig	2007-11-13 23:46:12.000000000 +0100
+++ rf/ustr.cpp	2007-11-13 23:46:29.000000000 +0100
@@ -428,4 +428,5 @@
 	newvalue[len] = '\0';
 	
 	return newvalue;
-}
\ No newline at end of file
+}
+
