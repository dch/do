--- Xvnc/include/Xos.h.orig	Sat Jul 13 02:14:08 2002
+++ Xvnc/include/Xos.h	Sat Jul 13 02:14:15 2002
@@ -151,7 +151,6 @@
 #endif /* X_NOT_POSIX else */
 
 #ifdef CSRG_BASED
-#include <stdlib.h>
 #include <unistd.h>
 #endif /* CSRG_BASED */
 
