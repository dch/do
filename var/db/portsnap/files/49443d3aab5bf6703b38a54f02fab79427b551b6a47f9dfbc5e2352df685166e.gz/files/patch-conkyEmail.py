--- conkyEmail.py.orig	2009-06-27 22:45:20.000000000 +0800
+++ conkyEmail.py	2010-05-08 02:31:30.000000000 +0800
@@ -1,4 +1,4 @@
-#!/usr/bin/python
+#!/usr/bin/env python
 # -*- coding: utf-8 -*-
 ###############################################################################
 # conkyEmail.py is a simple python script to gather
