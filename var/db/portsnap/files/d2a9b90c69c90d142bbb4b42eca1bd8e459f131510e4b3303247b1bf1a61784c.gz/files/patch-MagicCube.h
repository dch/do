*** MagicCube.h.BACKUP	Mon Sep 25 19:46:07 2000
--- MagicCube.h	Mon Sep 25 19:46:39 2000
***************
*** 22,28 ****
  #include <assert.h>
  #include <math.h>
  #include <string.h>
! #include <malloc.h>
  #include "Vec.h"
  
  // Version number of this program.  Must also be updated in
--- 22,28 ----
  #include <assert.h>
  #include <math.h>
  #include <string.h>
! #include <stdlib.h>
  #include "Vec.h"
  
  // Version number of this program.  Must also be updated in
