--- libs-external/USI++/src/ip.cc~
+++ libs-external/USI++/src/ip.cc
@@ -15,6 +15,7 @@
 #include "config.h"
 #include <iostream>
 #include <string.h>
+#include <cstdlib>
 #include <errno.h>
 #include <new>
 #include <vector>
