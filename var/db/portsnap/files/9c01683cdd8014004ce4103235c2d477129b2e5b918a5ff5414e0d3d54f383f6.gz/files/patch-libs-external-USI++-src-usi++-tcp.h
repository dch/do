--- libs-external/USI++/usi++/tcp.h~
+++ libs-external/USI++/usi++/tcp.h
@@ -12,6 +12,8 @@
 #ifndef _TCP_H_
 #define _TCP_H_
 
+#include <cstring>
+
 #include "usi-structs.h"
 #include "datalink.h"
 #include "ip.h"
