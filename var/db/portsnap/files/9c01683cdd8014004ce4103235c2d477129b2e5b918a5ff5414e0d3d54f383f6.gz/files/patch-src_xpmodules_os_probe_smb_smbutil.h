--- src/xpmodules/os_probe/smb/smbutil.h.orig	Thu Aug  4 11:44:20 2005
+++ src/xpmodules/os_probe/smb/smbutil.h	Thu Aug  4 11:44:28 2005
@@ -39,8 +39,8 @@
 #include <stdlib.h>
 #include <string.h>
 #include <ctype.h>
-#include <sys/socket.h>
 #include <sys/types.h>
+#include <sys/socket.h>
 
 using namespace std;
 
