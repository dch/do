--- libs-external/USI++/src/misc.cc~
+++ libs-external/USI++/src/misc.cc
@@ -1,6 +1,7 @@
 #include "usi++/usi++"
 #include "usi++/usi-structs.h"
 #include <string.h>
+#include <cstdlib>
 #include <unistd.h>
 #include <sys/ioctl.h>
 #include <errno.h>
