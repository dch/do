--- src/array.erl.orig	2015-06-24 22:14:48 UTC
+++ src/array.erl
@@ -155,7 +155,7 @@
 %% structure and the types of its fields.  So, please make sure that any
 %% changes to its structure are also propagated to erl_types.erl.
 %%
-%% -opaque array() :: #array{}.
+-opaque array() :: #array{}.
 
 %%
 %% Types
