--- setup.py.orig
+++ setup.py
@@ -144,8 +144,7 @@
 
     setup_requires = [
         #'Sphinx >= 1.0.6',
-        'nose >= 0.10.4',
-        'setuptools-git >= 0.3.4'
+        'nose >= 0.10.4'
     ],
 
     test_suite = 'nose.collector',
