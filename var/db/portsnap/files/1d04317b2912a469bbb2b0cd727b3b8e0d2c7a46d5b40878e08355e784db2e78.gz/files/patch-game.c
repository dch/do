--- game.c.orig	2013-10-18 03:58:23.000000000 +1100
+++ game.c	2013-10-18 04:00:19.000000000 +1100
@@ -59,7 +59,6 @@
 extern int mapResult;
 extern bool crashed;
 extern aiStruct AI;
-extern FILE *log;
 extern char livesString[10];
 extern char mapString[15];
 extern char *hiString;
