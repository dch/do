--- include/cln/exception.h.orig	2013-09-12 12:47:22.000000000 +0000
+++ include/cln/exception.h	2013-09-12 12:43:48.000000000 +0000
@@ -4,6 +4,7 @@
 #define _CL_EXCEPTION_H
 
 #include <stdexcept>
+#include <string>
 
 namespace cln {
 
