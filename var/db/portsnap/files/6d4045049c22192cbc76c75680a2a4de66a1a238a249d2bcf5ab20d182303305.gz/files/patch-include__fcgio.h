--- ./include/fcgio.h.orig	2011-01-21 12:26:36.000000000 +0000
+++ ./include/fcgio.h	2011-01-21 12:27:29.000000000 +0000
@@ -31,6 +31,7 @@
 #define FCGIO_H
 
 #include <iostream>
+#include <cstdio>
 
 #include "fcgiapp.h"
 
