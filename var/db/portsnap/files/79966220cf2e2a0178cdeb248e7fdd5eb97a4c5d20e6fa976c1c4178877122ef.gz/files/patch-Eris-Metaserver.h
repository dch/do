--- Eris/Metaserver.h.orig	2014-03-10 19:49:32.000000000 +0100
+++ Eris/Metaserver.h	2014-03-10 19:49:47.000000000 +0100
@@ -12,6 +12,8 @@
 #include <sigc++/signal.h>
 #include <memory>
 
+#include <ios>
+
 #include <stdint.h>
 
 // Forward decls
