--- ./Eris/View.h.orig	2014-03-10 19:30:34.000000000 +0100
+++ ./Eris/View.h	2014-03-10 19:30:56.000000000 +0100
@@ -13,6 +13,7 @@
 #include <sigc++/connection.h>
 
 // std
+#include <string>
 #include <deque>
 #include <map>
 #include <set>
