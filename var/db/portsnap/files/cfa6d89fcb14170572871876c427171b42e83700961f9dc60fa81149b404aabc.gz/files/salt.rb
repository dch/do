gem 'smart_proxy_salt'
