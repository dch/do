--- sigact.c.orig	1996-03-07 09:41:43.000000000 -0800
+++ sigact.c	2012-06-01 09:54:31.000000000 -0700
@@ -104 +104 @@
- *      Simon J. Gerraty <sjg@zen.void.oz.au>
+ *      Simon J. Gerraty <sjg@crufty.net>
@@ -120 +120 @@
- *      sjg@zen.void.oz.au
+ *      sjg@crufty.net
