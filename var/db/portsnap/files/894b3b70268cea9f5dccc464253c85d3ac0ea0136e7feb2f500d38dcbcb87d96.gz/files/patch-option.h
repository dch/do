--- src/options.h.orig	Fri Jan 19 16:13:40 2007
+++ src/options.h	Fri Jan 19 16:14:41 2007
@@ -97,9 +97,9 @@
 #define options_shared_data_path   "/usr/local/shared/foobillard"
 
 #define options_player_fontname    "iomanoid.ttf"
-#define options_help_fontname      "youregon.ttf"
-#define options_menu_fontname      "youregon.ttf"
-#define options_winner_fontname    "youregon.ttf"
+#define options_help_fontname      "bluebold.ttf"
+#define options_menu_fontname      "bluebold.ttf"
+#define options_winner_fontname    "bluebold.ttf"
 #define options_ball_fontname      "bluebold.ttf"
 #define options_score_fontname     "bluebold.ttf"
 #define options_roster_fontname    "bluebold.ttf"
