--- src/meep/mympi.hpp.orig	2009-12-26 13:03:30.000000000 +0600
+++ src/meep/mympi.hpp	2009-12-26 13:04:39.000000000 +0600
@@ -19,6 +19,7 @@
 #define MEEP_MY_MPI_H
 
 #include <complex>
+#include <stdio.h>
 using namespace std;
 
 namespace meep {
