--- src/texture.c.orig	Tue Jul  9 02:02:23 2002
+++ src/texture.c	Tue Oct 26 17:04:03 2004
@@ -21,10 +21,10 @@
 #include <string.h>
 #undef GTK_DISABLE_DEPRECATED
 #warning GTK_DISABLE_DEPRECATED
-#include "giram.h"
-#include "utils.h"
 #include "widgets/gtkcolorbutton.h"
 #include "widgets/gtkcolormapbutton.h"
+#include "giram.h"
+#include "utils.h"
 #include "texture.h"
 
 #include "widgets/giramwidgets.h"
