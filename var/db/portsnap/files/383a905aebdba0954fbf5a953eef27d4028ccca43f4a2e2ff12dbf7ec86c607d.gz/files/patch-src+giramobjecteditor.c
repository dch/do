--- src/giramobjecteditor.c.orig	Tue Jul 23 00:32:37 2002
+++ src/giramobjecteditor.c	Tue Oct 26 17:04:03 2004
@@ -19,10 +19,10 @@
  */
 
 #include <stdlib.h>
+#include "widgets/gtkcolorbutton.h"
 #include "giram.h"
 
 #include "giramintl.h"
-#include "widgets/gtkcolorbutton.h"
 #include "widgets/giramfileselection.h"
 
 #include "widgets/giramvectorframe.h"
