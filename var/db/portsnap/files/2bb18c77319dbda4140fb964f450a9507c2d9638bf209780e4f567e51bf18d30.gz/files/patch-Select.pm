--- lib/Senna/OptArg/Select.pm.orig	Wed Oct 18 18:59:04 2006
+++ lib/Senna/OptArg/Select.pm	Wed Oct 18 18:59:15 2006
@@ -35,12 +35,19 @@
 =head1 METHODS
 
 =head2 new
+
 =head2 mode
+
 =head2 similarity_threshold
+
 =head2 max_interval
+
 =head2 weight_vector
+
 =head2 vector_size
+
 =head2 func
+
 =head2 func_arg
 
-=cut
\ No newline at end of file
+=cut
