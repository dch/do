--- lib/Senna/OptArg/Sort.pm.orig	Wed Oct 18 18:58:06 2006
+++ lib/Senna/OptArg/Sort.pm	Wed Oct 18 18:58:22 2006
@@ -26,8 +26,11 @@
 =head1 METHODS
 
 =head2 new
+
 =head2 compar
+
 =head2 compar_arg
+
 =head2 mode
 
 =cut
