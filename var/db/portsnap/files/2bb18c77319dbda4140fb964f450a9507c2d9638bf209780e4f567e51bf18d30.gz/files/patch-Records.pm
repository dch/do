--- lib/Senna/Records.pm.orig	Wed Oct 18 15:16:06 2006
+++ lib/Senna/Records.pm	Wed Oct 18 15:16:26 2006
@@ -37,17 +37,29 @@
 =head1 METHODS
 
 =head2 new
+
 =head2 open
+
 =head2 next
+
 =head2 close
+
 =head2 curr_key
+
 =head2 curr_score
+
 =head2 nhits
+
 =head2 find
+
 =head2 difference
+
 =head2 intersect
+
 =head2 subtract
+
 =head2 union
+
 =head2 rewind
 
 =head1 AUTHOR
