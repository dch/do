--- CimCurl.cpp.orig	2009-03-04 19:10:54.000000000 +0000
+++ CimCurl.cpp
@@ -27,6 +27,7 @@
 #include <string.h>
 #endif
 
+#include <unistd.h>
 #include "CimCurl.h"
 
 extern int useNl;
