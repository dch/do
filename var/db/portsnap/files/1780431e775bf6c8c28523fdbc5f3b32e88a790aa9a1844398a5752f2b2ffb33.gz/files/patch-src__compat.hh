--- ./src/compat.hh.orig	2013-12-27 16:00:53.907143596 +0100
+++ ./src/compat.hh	2013-12-27 16:01:15.205152700 +0100
@@ -20,6 +20,7 @@
 
 #include <string>
 #include <stdio.h>
+#include <stdlib.h>
 #include <unistd-jigdo.h>
 #include <sys/stat.h>
 #include <sys/types.h>
