*** config_local.h.orig	Sun Apr 16 00:50:16 1995
--- config_local.h	Mon Nov 18 18:33:14 1996
***************
*** 61,67 ****
  #define LOCALTIME_PROTO 1
  
  /* Is there a nl_langinfo() call? */
! #define HAVE_NL_LANGINFO 1
  
  /* Is there a working <sys/param.h> */
  #define HAVE_SYS_PARAM_H 1
--- 61,67 ----
  #define LOCALTIME_PROTO 1
  
  /* Is there a nl_langinfo() call? */
! #undef HAVE_NL_LANGINFO
  
  /* Is there a working <sys/param.h> */
  #define HAVE_SYS_PARAM_H 1
