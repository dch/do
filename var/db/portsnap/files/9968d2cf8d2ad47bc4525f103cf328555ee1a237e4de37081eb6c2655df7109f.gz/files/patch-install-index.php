--- install/index.php.orig	2013-11-17 17:49:57.000000000 +0900
+++ install/index.php	2013-11-20 17:11:55.000000000 +0900
@@ -47,7 +47,7 @@
     <p><b>Please read Section on README file or go to <?php echo 'http://' .$forum_url ?> (Forum: TestLink 1.9.4 and greater News,changes, etc)</b> </p>
     <p>Open <a target="_blank" href="../docs/testlink_installation_manual.pdf">Installation manual</a>
     for more information or troubleshooting. You could also look at
-    <a href="../README">README</a> or <a href="../CHANGELOG">Changes Log</a>.
+    <a href="../docs/README">README</a> or <a href="../docs/CHANGELOG">Changes Log</a>.
     You are welcome to visit our <a target="_blank" href="http://forum.testlink.org">
     forum</a> to browse or discuss.
     </p>
@@ -59,4 +59,4 @@
 
 </div>
 </body>
-</html>
\ No newline at end of file
+</html>
