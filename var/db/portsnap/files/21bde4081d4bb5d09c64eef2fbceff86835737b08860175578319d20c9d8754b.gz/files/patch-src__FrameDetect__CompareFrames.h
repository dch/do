--- ./src/FrameDetect/CompareFrames.h.orig	2012-05-30 20:32:02.000000000 +0000
+++ ./src/FrameDetect/CompareFrames.h	2014-05-13 08:15:11.199946861 +0000
@@ -14,6 +14,7 @@
 #define __COMPARE_FRAMES_H
 
 #include <ComicFrame.h>
+#include <cstdlib>
 
 namespace QComicBook
 {
