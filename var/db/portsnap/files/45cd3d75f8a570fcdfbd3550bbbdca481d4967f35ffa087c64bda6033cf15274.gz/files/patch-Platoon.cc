--- Platoon.cc.orig	2007-07-08 09:20:15.000000000 +0400
+++ Platoon.cc	2007-07-08 09:20:35.000000000 +0400
@@ -1,3 +1,5 @@
+#include <assert.h>
+
 #include "Platoon.h"
 #include "dprint.h"
 
