--- inifile.c.orig	Sun May  5 04:09:25 1996
+++ inifile.c	Tue Jul 11 21:14:03 2000
@@ -5,6 +5,8 @@
  * Copyleft  (c) 1994-1996  Software Research Academy                   *
  ************************************************************************/
 #include <stdio.h>
+#include <stdlib.h>
+#include <string.h>
 
 #include "sxsame.h"
 
