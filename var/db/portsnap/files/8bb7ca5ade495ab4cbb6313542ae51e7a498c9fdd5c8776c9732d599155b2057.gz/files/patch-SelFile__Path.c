--- SelFile/Path.c.orig
+++ SelFile/Path.c
@@ -529,6 +529,7 @@
 	return 0;
 }
 
+void
 SFupdatePath()
 {
 	static int	alloc;
