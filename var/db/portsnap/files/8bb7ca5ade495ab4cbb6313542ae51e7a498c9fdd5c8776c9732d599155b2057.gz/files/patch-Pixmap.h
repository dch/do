*** Pixmap.h~	Fri May 13 04:03:29 1994
--- Pixmap.h	Sun Feb 19 03:35:48 1995
***************
*** 69,75 ****
  #include <X11/Xmu/Converters.h>
  #include <X11/Xos.h>
  #include <X11/Xfuncproto.h>
! #include "xpm.h"
  
  /* Resources:
  
--- 69,75 ----
  #include <X11/Xmu/Converters.h>
  #include <X11/Xos.h>
  #include <X11/Xfuncproto.h>
! #include <X11/xpm.h>
  
  /* Resources:
  
