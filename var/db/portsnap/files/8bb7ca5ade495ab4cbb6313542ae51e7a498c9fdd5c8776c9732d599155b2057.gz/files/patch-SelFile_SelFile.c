--- SelFile/SelFile.c.orig	Mon Dec 27 13:14:20 1993
+++ SelFile/SelFile.c	Sat Dec 28 17:03:13 2002
@@ -45,8 +45,8 @@
 #include <errno.h>
 /* BSD 4.3 errno.h does not declare errno */
 extern int errno;
-extern int sys_nerr;
-extern char *sys_errlist[];
+/*extern int sys_nerr;
+ extern char *sys_errlist[];*/
 
 #include <sys/param.h>
 #include <X11/cursorfont.h>
