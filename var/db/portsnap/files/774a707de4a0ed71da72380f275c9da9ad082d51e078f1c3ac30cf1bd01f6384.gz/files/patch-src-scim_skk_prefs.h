--- src/scim_skk_prefs.h.orig  Tue Nov 29 14:22:12 2005
+++ src/scim_skk_prefs.h       Tue Nov 29 15:42:46 2005
@@ -77,7 +77,7 @@
 #define SCIM_SKK_CONFIG_COMPLETION_BACK_KEY_DEFAULT  "period"
 #define SCIM_SKK_CONFIG_SELECTION_STYLE_DEFAULT      "Qwerty"
 
-#define SCIM_SKK_CONFIG_SYSDICT_DEFAULT          "DictFile:/usr/share/skk/SKK-JISYO.L"
+#define SCIM_SKK_CONFIG_SYSDICT_DEFAULT          "DictFile:/usr/local/share/skk/SKK-JISYO.L"
 #define SCIM_SKK_CONFIG_USERDICT_DEFAULT         ".skk-scim-jisyo"
 #define SCIM_SKK_CONFIG_CANDVEC_SIZE_DEFAULT      4
 #define SCIM_SKK_CONFIG_ANNOT_VIEW_DEFAULT    true
