--- cxx_dprog.hh.orig	Tue Apr  6 08:58:45 2004
+++ cxx_dprog.hh	Tue Apr  6 08:59:01 2004
@@ -5,6 +5,7 @@
 
 #include <vector>
 #include <cstdarg>
+#include <cassert>
 
 #include <iostream>
 
