--- codegen_test.cc.orig	Tue Apr  6 08:57:15 2004
+++ codegen_test.cc	Tue Apr  6 08:57:29 2004
@@ -2,6 +2,8 @@
 #include "codegen.hh"
 #include <iostream>
 
+#include <cassert>
+
 using namespace std;
 
 int
