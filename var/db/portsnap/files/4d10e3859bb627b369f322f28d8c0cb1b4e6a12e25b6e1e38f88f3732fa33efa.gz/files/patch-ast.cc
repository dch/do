--- ast.cc.orig	Tue Dec 30 17:40:13 2003
+++ ast.cc	Tue Dec 30 17:40:21 2003
@@ -1,3 +1,4 @@
+#include <cassert>
 
 #include "ast.hh"
 #include "visitor.hh"
