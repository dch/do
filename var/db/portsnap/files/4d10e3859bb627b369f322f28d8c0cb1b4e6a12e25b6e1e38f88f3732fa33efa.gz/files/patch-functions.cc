--- functions.cc.orig	Tue Dec 30 17:42:16 2003
+++ functions.cc	Tue Dec 30 17:42:25 2003
@@ -1,6 +1,7 @@
 
 #include "functions.hh"
 #include <map>
+#include <cassert>
 using namespace std;
 
 // FIXME: this stuff should be read from some configuration file.
