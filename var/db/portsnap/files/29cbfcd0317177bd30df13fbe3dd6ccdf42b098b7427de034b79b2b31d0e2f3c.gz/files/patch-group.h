--- etc/conserver/group.h.orig	Wed Aug  2 11:39:42 2000
+++ etc/conserver/group.h	Thu Nov  8 09:53:10 2001
@@ -29 +29 @@
-#define MAXPSWDLEN	16	/* max length of encrypted password	*/
+#define MAXPSWDLEN	64	/* max length of encrypted password	*/
