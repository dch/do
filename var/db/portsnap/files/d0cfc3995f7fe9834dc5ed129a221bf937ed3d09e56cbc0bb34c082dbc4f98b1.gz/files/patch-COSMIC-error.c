--- COSMIC/error.c.orig	2007-11-26 02:32:21.000000000 +0600
+++ COSMIC/error.c	2007-11-26 02:32:39.000000000 +0600
@@ -1,6 +1,7 @@
 /* error.c: this file contains an error function
  */
 #include <stdio.h>
+#include <stdlib.h>
 #include <ctype.h>
 #include "sockets.h"
 
