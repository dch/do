--- ./src/priv_client.cc.orig	2003-04-09 19:34:42.000000000 -0500
+++ ./src/priv_client.cc	2013-10-09 07:01:32.607128340 -0500
@@ -10,6 +10,7 @@
  */
 
 #include "../config.h"
+#include <limits.h>
 #include <stdarg.h>
 #include <stdlib.h>
 #include <stdio.h>
