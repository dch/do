--- src/numeric.c.orig	2012-04-26 16:10:18.000000000 -0500
+++ src/numeric.c
@@ -30,6 +30,7 @@
 
 #include <stdlib.h>
 #include <string.h>
+#include <ctype.h>
 
 #include "decimal.h"
 
