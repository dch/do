--- src/Music.cxx.orig	2007-05-27 19:04:33.000000000 +0400
+++ src/Music.cxx	2013-09-13 22:00:04.632230761 +0400
@@ -22,6 +22,7 @@
 #include <assert.h>
 #include <SDL_mixer.h>
 #include <stdexcept>
+#include <string>
 #include "Music.h"
 #include "System.h"
 
