--- draw.c.orig	Sat Mar 29 21:26:19 2003
+++ draw.c	Sat Mar 29 21:26:26 2003
@@ -21,7 +21,7 @@
 #include <string.h>
 #include <X11/Xlib.h>
 
-#include "cpu_linux.h"
+#include "cpu_freebsd.h"
 #include "dockapp.h"
 #include "options.h"
 
