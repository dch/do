--- tcpslice.c.orig	Tue Oct 28 02:14:35 2003
+++ tcpslice.c	Tue Oct 28 02:16:29 2003
@@ -36,7 +36,6 @@
 #include <sys/time.h>
 #include <sys/timeb.h>
 #include <netinet/in.h>
-#include <varargs.h>
 
 #include "savefile.h"
 #include "version.h"
