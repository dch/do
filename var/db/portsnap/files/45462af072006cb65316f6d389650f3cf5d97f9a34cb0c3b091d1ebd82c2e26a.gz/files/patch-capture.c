--- capture.c.orig	Tue Oct 28 02:13:49 2003
+++ capture.c	Tue Oct 28 02:15:57 2003
@@ -37,7 +37,6 @@
 #endif
 
 #include <stdio.h>
-#include <varargs.h>
 #include <sys/types.h>
 #include <sys/time.h>
 #include <sys/wait.h>
