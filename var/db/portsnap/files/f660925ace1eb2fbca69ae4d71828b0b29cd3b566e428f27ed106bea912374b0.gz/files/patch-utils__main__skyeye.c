--- utils/main/skyeye.c.orig
+++ utils/main/skyeye.c
@@ -46,6 +46,7 @@
 
 #include <setjmp.h>
 #include "code_cov.h"
+#include "symbol.h"
 
 /**
  * A global variable , point to the current archtecture
