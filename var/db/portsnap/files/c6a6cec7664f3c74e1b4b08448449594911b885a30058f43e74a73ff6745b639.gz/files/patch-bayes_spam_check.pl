--- bayes_spam_check.pl.orig	Sun Sep  8 17:06:34 2002
+++ bayes_spam_check.pl	Sun Sep  8 17:06:40 2002
@@ -144,7 +144,7 @@
  -h, --help          : this (help) message
  -r, --rating        : corpus rating file to use
 
-example: $0 --rating -o bayes_rating.dat
+example: $0 --rating bayes_rating.dat
 
 EOF
-}
+}
