--- vram.c.orig	Mon Apr 16 22:12:03 2001
+++ vram.c	Mon Apr 16 22:12:08 2001
@@ -31,7 +31,6 @@
 #include "cpu.h"
 #include "data.h"
 #include "x11.h"
-#include "svga.h"
 #include "win32.h"
 #include "joypad.h"
 
