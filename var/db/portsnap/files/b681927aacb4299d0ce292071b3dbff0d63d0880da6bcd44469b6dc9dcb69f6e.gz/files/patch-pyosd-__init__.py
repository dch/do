--- pyosd/__init__.py.orig	Wed Mar  7 16:02:22 2007
+++ pyosd/__init__.py	Wed Mar  7 16:03:00 2007
@@ -44,7 +44,7 @@
 
 error = _pyosd.error
 
-default_font="-*-helvetica-medium-r-normal-*-*-360-*-*-p-*-*-*"
+default_font="-misc-fixed-medium-r-semicondensed--*-*-*-*-c-*-*-*"
 
 class osd:
     """ osd is a class used to create an object which can display messages on
