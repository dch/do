--- testing.c.orig	1998-08-10 18:36:14.000000000 -0700
+++ testing.c	2008-06-04 04:50:08.000000000 -0700
@@ -3,6 +3,7 @@
  */
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <sys/types.h>
 #include <netinet/in.h>
 #include <arpa/inet.h>
