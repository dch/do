--- ./fbreader/src/fbreader/FBView.cpp.orig	2010-04-02 00:14:24.000000000 +1100
+++ ./fbreader/src/fbreader/FBView.cpp	2013-09-12 00:33:47.204357243 +1100
@@ -18,6 +18,7 @@
  */
 
 #include <cmath>
+#include <cstdlib>
 #include <algorithm>
 
 #include <ZLUnicodeUtil.h>
