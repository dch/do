--- ./fbreader/src/fbreader/FBReaderActions.cpp.orig	2010-04-02 00:14:24.000000000 +1100
+++ ./fbreader/src/fbreader/FBReaderActions.cpp	2013-09-12 00:34:03.722065220 +1100
@@ -18,6 +18,7 @@
  */
 
 #include <algorithm>
+#include <cstdlib>
 
 #include <ZLStringUtil.h>
 #include <ZLDialogManager.h>
