--- ./zlibrary/text/src/area/ZLTextAreaStyle.cpp.orig	2010-04-02 00:14:24.000000000 +1100
+++ ./zlibrary/text/src/area/ZLTextAreaStyle.cpp	2013-09-12 00:26:19.181817507 +1100
@@ -18,6 +18,7 @@
  */
 
 #include <algorithm>
+#include <cstdlib>
 
 #include <ZLUnicodeUtil.h>
 #include <ZLPaintContext.h>
