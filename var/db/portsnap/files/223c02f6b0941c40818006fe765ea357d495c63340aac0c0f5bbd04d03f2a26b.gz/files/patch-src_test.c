--- src/test.c.orig	2008-08-26 12:37:37.000000000 +0200
+++ src/test.c	2008-08-26 12:37:45.000000000 +0200
@@ -2,7 +2,6 @@
 #include <stdlib.h>
 
 #include <security/pam_appl.h>
-#include <security/pam_misc.h>
 #include <security/pam_modules.h>
 
 int main(int argc, char **argv)
