*** app_defaults.h	Mon Jan  4 00:05:08 1999
--- app_defaults.h~	Mon Jan  4 00:05:01 1999
***************
*** 1,5 ****
  "Xpostit.geometry:              70x70-0+0",
! "Xpostit.noteDir:               ~/aspostit/",
  "Xpostit.Menu*cursor:           hand1",
  "Xpostit.printCmd:		\"lpr %s\"",
  "Xpostit.calendarCmd:		cal",
--- 1,5 ----
  "Xpostit.geometry:              70x70-0+0",
! "Xpostit.noteDir:               ~/GNUstep/Library/AfterStep/aspostit/",
  "Xpostit.Menu*cursor:           hand1",
  "Xpostit.printCmd:		\"lpr %s\"",
  "Xpostit.calendarCmd:		cal",
