--- humanzip.cpp.orig
+++ humanzip.cpp
@@ -24,6 +24,7 @@
 #include <getopt.h>
 #include <vector>
 #include <iomanip>
+#include <unistd.h>
 #include <sys/stat.h>
 #include "humanzip.h"
