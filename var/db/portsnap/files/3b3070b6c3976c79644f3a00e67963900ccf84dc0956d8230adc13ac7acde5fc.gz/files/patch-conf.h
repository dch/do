--- src/conf.h.orig	Thu Mar 30 10:24:59 2000
+++ src/conf.h	Wed May  3 18:37:57 2000
@@ -1,6 +1,6 @@
 /* Default Database File Names */
 
-#define RADIUS_DIR		"/etc/raddb"
+#define RADIUS_DIR		PREFIX "/etc/raddb"
 #define RADLOG_DIR		"/var/log"
 
 #ifdef aix
