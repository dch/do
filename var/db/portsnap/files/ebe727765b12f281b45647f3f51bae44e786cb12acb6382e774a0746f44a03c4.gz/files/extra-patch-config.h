--- config.h.orig	Wed Jun 29 19:53:18 2005
+++ config.h	Sun Jun 17 20:05:51 2007
@@ -389,4 +389,6 @@
 */
 #define MIN_WOULDBLOCK_DELAY 100L
 
+#define USE_SENDFILE
+
 #endif /* _CONFIG_H_ */
