*** src/charset.c.orig	Thu Aug  9 22:19:27 2001
--- src/charset.c	Sun Dec 17 09:19:26 2006
***************
*** 10,15 ****
--- 10,16 ----
  
  
  #include <stdio.h>
+ #include <stdlib.h>
  #include <string.h>
  #include <sys/types.h>
  #ifdef NCURSES
