*** src/global.h.orig	Thu Aug  9 22:19:27 2001
--- src/global.h	Sun Dec 17 09:19:18 2006
***************
*** 1,3 ****
--- 1,4 ----
+ #include <stdlib.h>
  
  
  #define SYMBOL "-"
