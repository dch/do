--- source/lgrind.c.orig	Fri Mar 28 10:08:41 2003
+++ source/lgrind.c	Fri Mar 28 10:09:12 2003
@@ -94,7 +94,7 @@
 #include <stdlib.h>
 #include <ctype.h>
 #include <string.h>
-#include <malloc.h>
+/*#include <malloc.h> */
 #include <time.h>
 /* One of the following two (depending on your system) */
 #include <unistd.h>
