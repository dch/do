*** all.h.orig	Thu Jun 23 21:14:39 1994
--- all.h	Thu Dec  9 05:32:18 1999
***************
*** 22,28 ****
  #define ALL_H
  
  typedef float		real;		// float should be enough
! typedef short		bool;
  typedef unsigned	uint32;		// 32 Bit unsigned integer
  	// some compilers may need "typedef unsigned long uint32" instead
  typedef int		int32;		// 32 Bit signed integer
--- 22,28 ----
  #define ALL_H
  
  typedef float		real;		// float should be enough
! typedef short		boolean;
  typedef unsigned	uint32;		// 32 Bit unsigned integer
  	// some compilers may need "typedef unsigned long uint32" instead
  typedef int		int32;		// 32 Bit signed integer
