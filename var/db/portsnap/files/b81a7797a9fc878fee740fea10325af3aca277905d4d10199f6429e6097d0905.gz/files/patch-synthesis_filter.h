--- synthesis_filter.h.orig	Thu Nov 21 16:36:03 2002
+++ synthesis_filter.h	Thu Nov 21 16:36:10 2002
@@ -21,7 +21,7 @@
 #ifndef SYNTHESIS_FILTER_H
 #define SYNTHESIS_FILTER_H
 
-#include <iostream.h>
+#include <iostream>
 #include "all.h"
 #include "obuffer.h"
 
