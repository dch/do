--- src/tw/fcoreport.h.orig	2005-09-15 20:12:37.000000000 -0700
+++ src/tw/fcoreport.h	2007-10-09 23:53:39.000000000 -0700
@@ -74,6 +74,7 @@
 class cFCOName;
 class cFCOReport_i;
 class cFCOReportGenreIter_i;
+class cFCOReportSpecIter;
 class cFCOReportSpecIter_i;
 class cFCOReportChangeIter_i;
 class iFCOSpec;
