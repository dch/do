--- setup.py.orig	Wed Nov 21 14:25:46 2007
+++ setup.py	Tue Jan 22 11:28:34 2008
@@ -1,8 +1,6 @@
 #!/usr/bin/env python
 """Distutils setup file"""
 
-import ez_setup
-ez_setup.use_setuptools()
 from setuptools import setup
 
 # Metadata
