--- matchline.c.orig	Sun Feb 27 21:54:53 2005
+++ matchline.c	Tue Jun 21 10:25:59 2005
@@ -1,8 +1,8 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
-#include <regex.h>
 #include <sys/types.h>
+#include <regex.h>
 #include <time.h>
 #include "oak.h"
 
