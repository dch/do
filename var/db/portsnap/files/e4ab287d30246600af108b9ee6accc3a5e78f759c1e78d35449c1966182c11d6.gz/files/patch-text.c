--- text.c.orig	Sun Feb 27 21:54:53 2005
+++ text.c	Tue Jun 21 10:26:41 2005
@@ -1,6 +1,7 @@
 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
+#include <sys/types.h>
 #include <regex.h>
 #include <ctype.h>
 #include "oak.h"
