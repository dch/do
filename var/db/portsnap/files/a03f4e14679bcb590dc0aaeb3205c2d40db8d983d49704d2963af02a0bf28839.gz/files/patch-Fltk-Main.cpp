--- Fltk/Main.cpp.orig
+++ Fltk/Main.cpp
@@ -3,7 +3,7 @@
 // See the LICENSE.txt file for license information. Please report all
 // bugs and problems to the public mailing list <gmsh@geuz.org>.
 
-#include <stdlib.h>
+#include <cstdlib>
 #include <string>
 #include "Gmsh.h"
 #include "GmshMessage.h"
