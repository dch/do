--- Geo/CustomContainer.h.orig	2010-10-15 09:35:00.000000000 -0400
+++ Geo/CustomContainer.h	2011-08-09 05:12:35.000000000 -0400
@@ -8,6 +8,7 @@
 #ifndef _CUSTOMCONTAINER_H_
 #define _CUSTOMCONTAINER_H_
 
+#include <cstddef>
 #include <cstdlib>
 #include <cstring>
 
