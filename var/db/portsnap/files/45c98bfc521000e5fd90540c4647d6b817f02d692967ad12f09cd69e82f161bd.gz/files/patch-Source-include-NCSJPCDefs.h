--- Source/include/NCSJPCDefs.h.orig	2006-07-02 20:15:24.000000000 -0500
+++ Source/include/NCSJPCDefs.h	2009-03-16 14:00:27.000000000 -0500
@@ -59,7 +59,7 @@
 // Use LCMS for ICC->RGB conversions, supports both
 // restricted and full ICC profiles.
 //
-#define NCSJPC_USE_LCMS
+//#define NCSJPC_USE_LCMS
 
 //
 // Use TinyXML for XML DOM Parsing
