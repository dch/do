--- Source/C/NCSnet/NCScnet3/NCSProxy.h.orig	2013-12-20 19:22:52.000000000 +0100
+++ Source/C/NCSnet/NCScnet3/NCSProxy.h	2013-12-20 19:23:26.000000000 +0100
@@ -35,6 +35,7 @@
 //#include <streambuf>
 #include <iostream>
 #include <sstream>
+#include <unistd.h>
 #include <ctype.h>
 #include <assert.h>
 #include <string>

