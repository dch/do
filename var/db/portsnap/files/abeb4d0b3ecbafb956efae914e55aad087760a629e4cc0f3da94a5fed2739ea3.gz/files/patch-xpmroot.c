--- ./xpmroot/xpmroot.c.orig	1994-11-15 14:06:38.000000000 +0000
+++ ./xpmroot/xpmroot.c	2009-03-11 09:42:51.000000000 +0000
@@ -11,6 +11,7 @@
 #include <stdio.h>
 #include <signal.h>
 #include <string.h>
+#include <stdlib.h>
 #include <X11/Xos.h>
 #include <X11/Xatom.h>
 #include <X11/xpm.h>
