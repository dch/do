--- ./modules/FvwmBacker/root_bits.c.orig	1994-09-16 12:36:23.000000000 +0000
+++ ./modules/FvwmBacker/root_bits.c	2009-03-11 09:42:51.000000000 +0000
@@ -38,6 +38,7 @@
 #include <X11/Xutil.h>
 #include <X11/Xatom.h>
 #include <stdio.h>
+#include <stdlib.h>
 #include "X11/bitmaps/gray"
 
 char *index();
