--- src/util.cc-orig	2014-07-18 09:55:37.000000000 +0200
+++ src/util.cc	2014-07-18 09:56:11.000000000 +0200
@@ -22,6 +22,7 @@
 #include "util.h"
 #include <stdio.h>
 #include <cstring>
+#include <string>
 #include "headers.h"
 #ifdef HAVE_HASH_MAP
 # include <hash_map>
