--- alphabeta.cc.orig	Mon May  3 15:05:35 2004
+++ alphabeta.cc	Wed May  5 04:07:31 2004
@@ -18,6 +18,8 @@
 	Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
 
+#include <string>
+#include <iostream>
 #include "boardio.h"
 #include "hash.h"
 #include "alphabeta.h"
