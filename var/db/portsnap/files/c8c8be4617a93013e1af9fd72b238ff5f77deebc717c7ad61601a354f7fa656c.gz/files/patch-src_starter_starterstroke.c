--- src/starter/starterstroke.c.orig	2015-06-09 09:46:26 UTC
+++ src/starter/starterstroke.c
@@ -16,6 +16,7 @@
 
 #include <unistd.h>
 #include <stdlib.h>
+#include <stdint.h>
 #include <string.h>
 
 #include <credentials/auth_cfg.h>
