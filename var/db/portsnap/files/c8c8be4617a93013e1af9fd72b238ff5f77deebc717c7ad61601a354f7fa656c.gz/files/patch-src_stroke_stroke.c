--- src/stroke/stroke.c.orig	2015-06-09 09:46:03 UTC
+++ src/stroke/stroke.c
@@ -17,6 +17,7 @@
 #include <stdlib.h>
 #include <unistd.h>
 #include <stdio.h>
+#include <stdint.h>
 #include <string.h>
 #include <getopt.h>
 
