--- shot.c.orig	Thu Jun  5 19:55:39 2003
+++ shot.c	Thu Jun  5 19:56:34 2003
@@ -47,6 +47,7 @@
   "/usr/games/glmaze/",
   "/usr/local/games/glMaze/",
   "/usr/local/games/glmaze/",
+  "%%PREFIX%%/share/glmaze/",
   "./", 
   ""
 };
