--- ./makegdbm/options.h.orig	2013-01-08 16:04:27.000000000 -0500
+++ ./makegdbm/options.h	2013-01-08 16:04:51.000000000 -0500
@@ -39,7 +39,6 @@
 #endif
 
 extern gdbm_error gdbm_errno;
-extern char *gdbm_version;
 
 #define COPYRIGHT \
   "(c) 1999 Horms <horms@verge.net.au>\nReleased under the GNU GPL\n"
