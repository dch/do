--- ./src/global.cpp.orig	2014-01-13 00:20:08.000000000 +0100
+++ ./src/global.cpp	2014-01-13 00:20:08.000000000 +0100
@@ -9,6 +9,7 @@
 
 #include "Global.h"
 #include "unixutils.h"
+#include <limits.h>
 
 
 
