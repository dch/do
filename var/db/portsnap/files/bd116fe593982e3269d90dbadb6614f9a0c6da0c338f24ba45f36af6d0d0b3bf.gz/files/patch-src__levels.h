--- ./src/levels.h.orig	2014-01-13 00:20:08.000000000 +0100
+++ ./src/levels.h	2014-01-13 00:20:08.000000000 +0100
@@ -8,7 +8,7 @@
 
 #ifndef __LEVELS_H__
 #define __LEVELS_H__
-
+#include <limits.h>
 
 class cScene
 {
