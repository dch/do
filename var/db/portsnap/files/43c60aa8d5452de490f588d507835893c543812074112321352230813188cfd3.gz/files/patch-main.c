--- main.c.orig	Tue Mar 28 17:01:17 2000
+++ main.c	Thu Mar 30 02:43:08 2000
@@ -154,7 +154,7 @@
 			case 'h':
 				printf("Usage: rmap [--zoom=VALUE] [--xrot=VALUE] [--yrot=VALUE] [--zrot=VALUE]\n");
 				printf("            [--datafile=FILENAME] [--continent=LIST] [--category=LIST]\n");
-				printf("            [--outfile=FILENAME] [--height=PIXLES] [--width=PIXLES]\n");
+				printf("            [--outfile=FILENAME] [--height=PIXELS] [--width=PIXELS]\n");
 				printf("            [--colorfile=FILENAME] [--nogridlines] [--cities] [-h] [-v]\n");
 				printf("\n");	
 				printf("\t--zoom=<value>             Zoom Value, 1=whole earth\n");
