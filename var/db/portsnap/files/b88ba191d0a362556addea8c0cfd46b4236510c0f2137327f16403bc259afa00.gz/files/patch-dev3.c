--- t_coffee_source/dev3.c.orig	2012-07-13 02:06:31.000000000 +0900
+++ t_coffee_source/dev3.c	2012-10-04 22:14:10.000000000 +0900
@@ -3,6 +3,7 @@
 #include <math.h>
 #include <stdarg.h>
 #include <string.h>
+#include <sys/types.h>
 #include <sys/sysctl.h>
 #include "dev3_lib_header.h"
 /******************************COPYRIGHT NOTICE*******************************/
