--- ./uufilter.c.orig
+++ ./uufilter.c
@@ -11,6 +11,7 @@
  */
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <string.h>
 
 int main(argc, argv)
