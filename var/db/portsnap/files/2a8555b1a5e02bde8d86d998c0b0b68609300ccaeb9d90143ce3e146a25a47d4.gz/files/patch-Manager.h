--- Manager.h.orig	Tue Jan 28 17:41:36 2003
+++ Manager.h	Tue Jan 28 17:41:46 2003
@@ -85,7 +85,7 @@
 
     static Boolean m_initialising;
     static int errorHandler(Display *, XErrorEvent *);
-    static void sigHandler();
+    static void sigHandler(int);
     static int m_signalled;
 
     void initialiseScreen();
