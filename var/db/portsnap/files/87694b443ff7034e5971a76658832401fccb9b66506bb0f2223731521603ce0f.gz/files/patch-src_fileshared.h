--- src/fileshared.h.orig	2011-10-06 14:50:48.000000000 +0200
+++ src/fileshared.h	2013-12-16 00:09:23.000000000 +0100
@@ -23,7 +23,7 @@
 
 #include "sharedptr.h"
 
-#include <gtkmm/textbuffer.h>
+#include <gtkmm.h>
 #include <functional>
 #include <utility>
 #include <vector>
