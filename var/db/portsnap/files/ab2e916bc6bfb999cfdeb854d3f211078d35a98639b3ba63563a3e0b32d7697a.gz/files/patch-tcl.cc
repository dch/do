--- tcl.cc.orig	Thu May 22 14:09:11 2003
+++ tcl.cc	Thu May 22 14:09:21 2003
@@ -1,3 +1,4 @@
+#include <ctype.h>
 #include <sys/time.h>
 #include <unistd.h>
 #include <sys/socket.h>
