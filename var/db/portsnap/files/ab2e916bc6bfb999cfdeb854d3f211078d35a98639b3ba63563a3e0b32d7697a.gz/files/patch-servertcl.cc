--- servertcl.cc.orig	Thu May 22 14:12:56 2003
+++ servertcl.cc	Thu May 22 14:13:04 2003
@@ -1,3 +1,4 @@
+#include <ctype.h>
 #include <sys/types.h>
 #include <netinet/in.h>
 #include <arpa/inet.h>
