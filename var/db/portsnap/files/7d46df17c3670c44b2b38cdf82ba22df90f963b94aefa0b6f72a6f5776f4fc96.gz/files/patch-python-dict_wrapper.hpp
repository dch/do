--- python/dict_wrapper.hpp.orig	2012-11-12 17:57:40.000000000 +0400
+++ python/dict_wrapper.hpp	2012-11-12 18:32:21.000000000 +0400
@@ -18,7 +18,6 @@
 #ifndef UATRAITS_PYTHON_DICT_WRAPPER_HPP_INCLUDED
 #define UATRAITS_PYTHON_DICT_WRAPPER_HPP_INCLUDED
 
-#include <string>
 #include <boost/python.hpp>
 
 #include "uatraits/config.hpp"
