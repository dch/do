--- src/message.h.orig	2010-01-02 21:53:36.000000000 +0100
+++ src/message.h	2014-01-19 16:59:54.616726275 +0100
@@ -25,6 +25,7 @@
 #define _PMS_MESSAGE_H_
 
 #include <string>
+#include <ctime>
 
 using namespace std;
 
