--- supertone_tests.c.orig	2012-06-26 18:03:25.000000000 +0700
+++ supertone_tests.c	2012-06-26 18:03:38.000000000 +0700
@@ -50,6 +50,7 @@
 #include <audiofile.h>
 #endif
 #include <spandsp.h>
+#include <spandsp/expose.h>
 
 #include "libsupertone.h"
 
