--- supertone.c.orig	2012-06-26 18:01:41.000000000 +0700
+++ supertone.c	2012-06-26 18:01:54.000000000 +0700
@@ -53,6 +53,7 @@
 #include <libxml/xinclude.h>
 
 #include <spandsp.h>
+#include <spandsp/expose.h>
 
 #include "supertone.h"
 #include "libsupertone.h"
