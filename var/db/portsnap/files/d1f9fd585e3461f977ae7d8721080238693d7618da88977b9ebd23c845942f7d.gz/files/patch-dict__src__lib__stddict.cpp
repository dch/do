--- ./dict/src/lib/stddict.cpp.orig	2012-02-17 08:58:47.000000000 +0000
+++ ./dict/src/lib/stddict.cpp	2013-10-09 16:16:36.938640507 +0000
@@ -32,6 +32,7 @@
 #include <glib.h>
 #include <glib/gi18n.h>
 #include <glib/gstdio.h>
+#include <stdlib.h>
 #include <algorithm>
 #include <memory>
 
