--- ./dict/src/stardict-application-server.cpp.orig	2011-07-03 06:58:40.000000000 +0000
+++ ./dict/src/stardict-application-server.cpp	2011-10-20 21:26:45.868162214 +0000
@@ -138,4 +138,4 @@
         StardictApplicationServer,                    
         GNOME_Stardict_Application, 
         BONOBO_TYPE_OBJECT,           
-        stardict_application_server);
+        stardict_application_server)
