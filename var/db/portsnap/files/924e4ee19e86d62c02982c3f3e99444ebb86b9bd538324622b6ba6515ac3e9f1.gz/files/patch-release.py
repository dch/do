--- release.py.orig	2015-05-27 06:43:45 UTC
+++ release.py
@@ -161,3 +161,8 @@ install_requires = [
 
 setup_requires = [
 ]
+
+tests_require = [
+]
+
+test_suite = 'netaddr.tests.test_suite_all'
