--- ./library/dialect/swi/fli/blobs.c.orig	2013-01-19 07:33:19.000000000 -0200
+++ ./library/dialect/swi/fli/blobs.c	2013-11-03 01:59:03.000000000 -0200
@@ -18,6 +18,7 @@
 #include	<Yap.h>
 #include	<Yatom.h>
 
+#include <stdio.h>
 #include <string.h>
 
 /* for freeBSD9.1 */
