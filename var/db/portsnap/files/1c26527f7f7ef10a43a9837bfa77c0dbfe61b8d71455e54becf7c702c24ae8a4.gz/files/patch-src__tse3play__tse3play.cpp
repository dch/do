--- src/tse3play/tse3play.cpp.orig	2005-08-23 21:58:35.000000000 +0900
+++ src/tse3play/tse3play.cpp	2009-04-02 13:01:31.000000000 +0900
@@ -32,6 +32,7 @@
 #include "tse3/Error.h"
 #include "tse3/Metronome.h"
 #include <fstream>
+#include <cstdlib>
 
 #ifdef HAVE_CONFIG_H
 #include "config.h"
