--- src/tse3/Serializable.h.orig	2005-07-25 20:23:00.000000000 +0900
+++ src/tse3/Serializable.h	2009-04-02 13:01:31.000000000 +0900
@@ -20,6 +20,7 @@
 #include <iosfwd>
 #include <iomanip>
 #include <cstddef>
+#include <iostream>
 
 namespace TSE3
 {
