--- src/tse3/MidiFile.cpp.orig	2005-07-25 20:23:00.000000000 +0900
+++ src/tse3/MidiFile.cpp	2009-04-02 13:01:31.000000000 +0900
@@ -32,6 +32,7 @@
 #include <string>
 #include <queue>
 #include <math.h>
+#include <cstring>
 
 using namespace TSE3;
 
