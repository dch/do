--- src/examples/recording/recording.cpp.orig	2005-07-25 20:22:31.000000000 +0900
+++ src/examples/recording/recording.cpp	2009-04-02 13:23:23.000000000 +0900
@@ -27,6 +27,7 @@
      **************************************************************/
 
 #include <iostream>
+#include <cstdlib>
 
 // Used in step 1
 #include "tse3/Metronome.h"
