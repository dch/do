--- src/tse3/cmd/Phrase.h.orig	2005-07-25 20:22:38.000000000 +0900
+++ src/tse3/cmd/Phrase.h	2009-04-02 13:01:31.000000000 +0900
@@ -29,6 +29,7 @@
     class Phrase;
     class Song;
     class Part;
+    class PhraseEdit;
 
     namespace Cmd
     {
