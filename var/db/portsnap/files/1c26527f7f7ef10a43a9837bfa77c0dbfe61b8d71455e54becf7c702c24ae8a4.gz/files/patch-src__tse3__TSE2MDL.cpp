--- src/tse3/TSE2MDL.cpp.orig	2005-07-25 20:23:00.000000000 +0900
+++ src/tse3/TSE2MDL.cpp	2009-04-02 13:01:31.000000000 +0900
@@ -38,6 +38,7 @@
 #include "tse3/Progress.h"
 
 #include <fstream>
+#include <cstring>
 
 using namespace TSE3;
 
