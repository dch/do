--- compile_world.c.orig	2009-03-27 17:51:01.000000000 +0100
+++ compile_world.c	2009-03-27 17:51:15.000000000 +0100
@@ -33,6 +33,7 @@
 #include <sys/types.h>
 #include <sys/mman.h>
 #include <stdio.h>
+#include <stdlib.h>
 #include "Sphere.h"
 #include "SphereDim.h"
 
