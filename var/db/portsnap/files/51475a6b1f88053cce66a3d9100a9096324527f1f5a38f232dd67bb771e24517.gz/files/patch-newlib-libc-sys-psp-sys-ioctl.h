--- ./newlib/libc/sys/psp/sys/ioctl.h.orig	2012-01-25 19:33:12.000000000 +0000
+++ ./newlib/libc/sys/psp/sys/ioctl.h	2012-01-25 19:33:12.000000000 +0000
@@ -0,0 +1 @@
+/* Empty file, here for compatibility */
