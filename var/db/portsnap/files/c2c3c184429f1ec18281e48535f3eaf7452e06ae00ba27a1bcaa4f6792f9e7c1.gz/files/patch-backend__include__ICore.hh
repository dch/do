--- backend/include/ICore.hh.orig	2010-12-05 21:01:31.000000000 +0300
+++ backend/include/ICore.hh	2014-05-17 03:18:53.674936521 +0400
@@ -21,6 +21,7 @@
 #define ICORE_HH
 
 #include <string>
+#include <ctime>
 
 #include "enum.h"
 
