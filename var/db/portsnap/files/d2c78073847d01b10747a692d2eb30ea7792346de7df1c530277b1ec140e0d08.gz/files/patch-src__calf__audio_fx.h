--- src/calf/audio_fx.h.orig
+++ src/calf/audio_fx.h
@@ -27,6 +27,7 @@
 #include "inertia.h"
 #include "giface.h"
 #include "onepole.h"
+#include <sys/types.h>
 #include <complex>
 
 namespace calf_plugins {
