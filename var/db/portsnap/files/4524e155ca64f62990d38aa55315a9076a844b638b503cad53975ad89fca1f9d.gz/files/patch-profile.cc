--- profile.cc.orig	2013-10-03 17:16:53.000000000 -0300
+++ profile.cc	2013-10-03 17:17:01.000000000 -0300
@@ -18,6 +18,7 @@
 
 #include <algorithm>
 #include <cstdio>
+#include <cstdlib>
 #include <vector>
 #include <stdint.h>
 
