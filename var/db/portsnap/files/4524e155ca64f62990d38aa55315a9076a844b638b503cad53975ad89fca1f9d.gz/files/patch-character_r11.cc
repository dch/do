--- character_r11.cc.orig	2013-10-03 17:20:43.000000000 -0300
+++ character_r11.cc	2013-10-03 17:20:54.000000000 -0300
@@ -18,6 +18,7 @@
 
 #include <algorithm>
 #include <cstdio>
+#include <cstdlib>
 #include <vector>
 #include <stdint.h>
 
