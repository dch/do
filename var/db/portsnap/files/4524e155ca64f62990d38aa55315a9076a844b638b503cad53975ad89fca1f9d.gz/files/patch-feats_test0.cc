--- feats_test0.cc.orig	2013-10-03 17:19:50.000000000 -0300
+++ feats_test0.cc	2013-10-03 17:20:00.000000000 -0300
@@ -18,6 +18,7 @@
 
 #include <algorithm>
 #include <cstdio>
+#include <cstdlib>
 #include <vector>
 #include <stdint.h>
 
