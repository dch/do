--- compiler.c.orig	2008-05-29 20:46:19.000000000 +0200
+++ compiler.c	2008-05-29 20:46:32.000000000 +0200
@@ -1,4 +1,5 @@
 #include <stdio.h>
+#include <stdlib.h>
 #include <unistd.h>
 #include <string.h>
 #include "bf.h"
