--- h/epath.h.orig	Sun Nov 19 03:09:52 1995
+++ h/epath.h	Wed Mar 25 13:57:22 1998
@@ -68,7 +68,8 @@
 {
 	".emacsrc",
 	"emacs.hlp",
-	"/usr/local/",
+	"/usr/local/share/uemacs/",
+	"/usr/local/lib/uemacs/",
 	"/usr/lib/",
 	""
 };
