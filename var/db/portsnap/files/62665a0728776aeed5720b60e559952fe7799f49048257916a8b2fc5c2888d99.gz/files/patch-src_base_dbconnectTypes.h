--- src/base/dbconnectTypes.h.orig	2003-08-18 19:17:35.000000000 +0200
+++ src/base/dbconnectTypes.h	2014-05-08 01:40:11.776003075 +0200
@@ -23,6 +23,7 @@
 #define __DBCONN_TYPES_H__
 
 #include <string>
+#include <stdlib.h>
 
 #include "dbconnectExceptions.h"
 
