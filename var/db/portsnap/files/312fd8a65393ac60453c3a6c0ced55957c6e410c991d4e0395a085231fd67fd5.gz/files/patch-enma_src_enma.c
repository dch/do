--- ./enma/src/enma.c.orig	2011-11-07 12:18:02.000000000 +0900
+++ ./enma/src/enma.c	2012-02-25 14:52:45.000000000 +0900
@@ -15,6 +15,7 @@
 #include <stdio.h>
 #include <assert.h>
 #include <sysexits.h>
+#include <stdbool.h>
 #include <stdlib.h>
 #include <syslog.h>

