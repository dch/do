--- parse.h-orig	2009-10-10 20:22:14.000000000 +0200
+++ parse.h	2009-10-10 20:22:13.000000000 +0200
@@ -102,6 +102,7 @@
 #define F_CONSTRAINEDMOVE	55
 #define F_OPAQUEMOVE		56
 #define F_DELETEORDESTROY	57
+#define F_DUMPSTATE		58
 
 #define F_MENU			101	/* string */
 #define F_WARPTO		102	/* string */
