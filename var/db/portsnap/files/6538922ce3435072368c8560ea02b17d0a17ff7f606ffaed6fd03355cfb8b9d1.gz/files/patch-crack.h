--- crack.h.orig	2000-06-18 23:19:07 UTC
+++ crack.h
@@ -24,7 +24,6 @@ extern u8 bf_next[256];
 extern u8 bf_last;
 
 extern int verbosity;
-extern int use_unzip;
 
 #define FILE_SIZE	12
 #define CRC_SIZE	2
