--- IMB_declare.h.orig	Sun Nov 19 13:48:20 2006
+++ IMB_declare.h	Sun Nov 19 13:48:36 2006
@@ -69,7 +69,6 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
-#include <malloc.h>
 #include <stddef.h>
 #include "IMB_appl_errors.h"
 #include "IMB_err_check.h"
