--- logtool/includes.h.orig	Wed Jan 10 04:18:00 2001
+++ src/includes.h	Wed Jan 10 04:20:00 2001
@@ -22,6 +22,7 @@
 #include<stdio.h>
 #include<stdlib.h>
 #include<string.h>
+#include<unistd.h>
 #include<regex.h>
 #include<errno.h>
 
