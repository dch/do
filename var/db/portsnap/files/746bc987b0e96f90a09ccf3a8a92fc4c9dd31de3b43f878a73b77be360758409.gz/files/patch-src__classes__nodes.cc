--- src/classes/nodes.cc.orig	2013-12-10 00:22:15.000000000 +0900
+++ src/classes/nodes.cc	2013-12-10 00:22:39.000000000 +0900
@@ -1,4 +1,5 @@
-#include <stdio.h>
+#include <cstdio>
+#include <cstdlib>
 #include "nodes.h"
 
 
