--- xskyroot.c-	Thu May 29 08:56:15 1997
+++ xskyroot.c	Thu May 29 08:52:51 1997
@@ -1,4 +1,4 @@
-
+#include <stdlib.h>
 #include <stdio.h>
 #include <time.h>
 #include <X11/Xlib.h>
