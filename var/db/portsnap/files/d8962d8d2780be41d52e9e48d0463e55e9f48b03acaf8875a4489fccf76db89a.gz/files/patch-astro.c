--- astro.c.orig	Mon May 31 09:06:03 1999
+++ astro.c	Mon May 31 09:06:18 1999
@@ -7,7 +7,7 @@
 #include <math.h>
 #include "mathlocal.h"
 
-long		time();
+time_t		time();
 long		jdate();
 double		jtime();
 double		gmst();
