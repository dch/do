--- ./astro.h.orig	2003-01-28 01:55:32.000000000 +0100
+++ ./astro.h	2014-02-12 22:38:52.437019902 +0100
@@ -43,4 +43,4 @@
  */
 extern double phase( double pdate, double* pphase, double* mage, double* dist, double* angdia, double* sudist, double* suangdia );
 
-#endif _ASTRO_H_
+#endif
