--- include/arlutil.h.orig	Thu Jul 31 22:32:42 1997
+++ include/arlutil.h	Mon Oct 20 00:09:43 2003
@@ -12,7 +12,7 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
-#include <malloc.h>
+#include <stdlib.h>
 #include <assert.h>
 
 /* Macros */
