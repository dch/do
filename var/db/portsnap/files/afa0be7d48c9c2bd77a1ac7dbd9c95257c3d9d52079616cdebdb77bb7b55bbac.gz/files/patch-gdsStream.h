--- gdsStream.h.orig	Sun Apr 29 15:45:42 2007
+++ gdsStream.h	Sun Apr 29 15:45:54 2007
@@ -3,8 +3,7 @@
 #define _gdsStream__
 
 #include <stdio.h>
-#include <malloc.h>
-#include <stdio.h>
+#include <stdlib.h>
 #include <time.h>
 #include <kvstypes.h>
 
