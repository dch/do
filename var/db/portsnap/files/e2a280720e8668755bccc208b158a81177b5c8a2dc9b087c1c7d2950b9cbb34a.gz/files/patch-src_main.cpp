--- src/main.cpp.orig	Sat May  3 18:46:15 2003
+++ src/main.cpp	Sat Jul 12 03:40:03 2003
@@ -27,7 +27,7 @@
 
 //ʸ����
 #ifdef __FreeBSD__
-#define LANG "ja_JP.EUC"
+#define LANG "ja_JP.eucJP"
 #else
 #define LANG "ja_JP"
 #endif
