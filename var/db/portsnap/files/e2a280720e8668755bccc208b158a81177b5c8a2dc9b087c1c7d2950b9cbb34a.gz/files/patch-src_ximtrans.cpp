--- src/ximtrans.cpp.orig	2014-06-28 22:11:37.000000000 +0900
+++ src/ximtrans.cpp	2014-06-28 22:11:54.000000000 +0900
@@ -6,6 +6,7 @@
 #endif
 
 #include <stdio.h>
+#include <stdlib.h>
 #include "xim.h"
 
 #ifndef __GNUC__
