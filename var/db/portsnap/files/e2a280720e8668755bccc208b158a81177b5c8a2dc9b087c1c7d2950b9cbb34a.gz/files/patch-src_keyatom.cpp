--- src/keyatom.cpp.orig	2014-06-28 22:19:00.000000000 +0900
+++ src/keyatom.cpp	2014-06-28 22:19:19.000000000 +0900
@@ -9,6 +9,7 @@
 #  include <alloca.h>
 # endif
 #endif
+#include <stdlib.h>
 
 #include "jmode.h"
 
