--- src/dispatch.cpp.orig	2014-06-28 22:10:26.000000000 +0900
+++ src/dispatch.cpp	2014-06-28 22:10:45.000000000 +0900
@@ -16,6 +16,7 @@
 #include <X11/Xatom.h>
 #include <unistd.h>
 #include <stdio.h>
+#include <stdlib.h>
 #include <map>
 
 #include "jmode.h"
