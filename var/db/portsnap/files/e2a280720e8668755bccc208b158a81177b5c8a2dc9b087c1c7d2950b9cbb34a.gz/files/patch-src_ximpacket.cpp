--- src/ximpacket.cpp.orig	2014-06-28 22:17:36.000000000 +0900
+++ src/ximpacket.cpp	2014-06-28 22:18:08.000000000 +0900
@@ -3,6 +3,7 @@
 #endif
 
 #include <list>
+#include <stdlib.h>
 #include "xim.h"
 
 //
