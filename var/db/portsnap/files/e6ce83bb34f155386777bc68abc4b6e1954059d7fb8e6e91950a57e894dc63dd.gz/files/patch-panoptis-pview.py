--- panoptis/pview.py.orig	Tue Nov 28 14:57:01 2006
+++ panoptis/pview.py	Tue Nov 28 14:57:10 2006
@@ -1,4 +1,4 @@
-#!/usr/bin/python
+#!/usr/bin/env python
 
 # This CGI script connects to Panoptis' web port, makes a request,
 # accepts data and formats it to show it to the user.
