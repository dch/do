--- abclock.c.orig	Tue Aug 15 11:25:10 2000
+++ abclock.c	Tue Aug 15 11:43:06 2000
@@ -29,7 +29,7 @@
 #include <time.h>
 #include <sys/time.h>
 #include <unistd.h>
-#include <values.h>
+#include <float.h>
 #include <X11/Xlib.h>
 #include <X11/Xutil.h>
 
