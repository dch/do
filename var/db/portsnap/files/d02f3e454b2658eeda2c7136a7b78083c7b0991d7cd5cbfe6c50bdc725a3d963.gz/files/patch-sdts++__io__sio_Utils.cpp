--- sdts++/io/sio_Utils.cpp.orig	2002-10-08 05:44:24.000000000 +0900
+++ sdts++/io/sio_Utils.cpp	2012-09-12 16:50:32.000000000 +0900
@@ -15,6 +15,7 @@
 #endif
 
 #include <cstdlib>
+#include <cstring>
 
 
 
