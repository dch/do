--- sdts++/io/sio_8211DDRField.cpp.orig	2002-11-25 07:07:43.000000000 +0900
+++ sdts++/io/sio_8211DDRField.cpp	2012-09-12 16:48:13.000000000 +0900
@@ -18,6 +18,7 @@
 #endif
 
 #include <strstream>
+#include <cstring>
 
 
 
