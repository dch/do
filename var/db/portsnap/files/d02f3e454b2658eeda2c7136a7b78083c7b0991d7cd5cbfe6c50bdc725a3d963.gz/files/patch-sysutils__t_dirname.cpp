--- sysutils/t_dirname.cpp.orig	2002-11-27 09:21:34.000000000 +0900
+++ sysutils/t_dirname.cpp	2012-09-12 16:54:58.000000000 +0900
@@ -3,6 +3,7 @@
 //
 
 #include <iostream>
+#include <cstdlib>
 
 #include "fileutils.h"
 
