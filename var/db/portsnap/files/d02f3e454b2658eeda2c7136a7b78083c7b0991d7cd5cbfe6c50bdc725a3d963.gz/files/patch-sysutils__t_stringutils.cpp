--- sysutils/t_stringutils.cpp.orig	2001-07-18 05:50:15.000000000 +0900
+++ sysutils/t_stringutils.cpp	2012-09-12 16:44:29.000000000 +0900
@@ -5,6 +5,7 @@
 #include <iostream>
 #include <string>
 #include <cassert>
+#include <cstdlib>
 
 using namespace std;
