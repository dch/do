--- sdts++/io/sio_8211Converter.cpp.orig	2002-11-25 07:07:43.000000000 +0900
+++ sdts++/io/sio_8211Converter.cpp	2012-09-12 16:47:10.000000000 +0900
@@ -16,6 +16,7 @@
 
 #include <strstream>
 #include <iomanip>
+#include <cstring>
 
 #include <algorithm>
 
