--- pes.c.orig	Sun Dec 28 17:57:19 2003
+++ pes.c	Tue Jan 20 05:15:09 2004
@@ -26,6 +26,7 @@
 
 #include <stdlib.h>
 #include <stdio.h>
+#include <sys/types.h>
 #include <netinet/in.h>
 #include <string.h>
 
