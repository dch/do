--- src/pugiconfig.hpp.orig	2015-08-18 17:07:06 UTC
+++ src/pugiconfig.hpp
@@ -41,7 +41,7 @@
 // #define PUGIXML_HEADER_ONLY
 
 // Uncomment this to enable long long support
-// #define PUGIXML_HAS_LONG_LONG
+#define PUGIXML_HAS_LONG_LONG
 
 #endif
 
