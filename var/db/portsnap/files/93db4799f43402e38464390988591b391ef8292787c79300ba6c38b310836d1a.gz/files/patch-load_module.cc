--- load_module.cc.orig	Thu Jul 17 20:49:38 2003
+++ load_module.cc	Thu Jul 17 20:49:51 2003
@@ -24,6 +24,7 @@
 # include  "util.h"
 # include  "parse_api.h"
 # include  "compiler.h"
+# include  <assert.h>
 # include  <iostream>
 # include  <map>
 # include  <string>
