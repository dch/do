--- src/plugins/modplug/modplug.c.orig	2011-10-20 21:26:08.000000000 +0200
+++ src/plugins/modplug/modplug.c	2014-04-09 15:05:29.232679291 +0200
@@ -9,7 +9,7 @@
 #include "xmms/xmms_sample.h"
 #include "xmms/xmms_medialib.h"
 #include "xmms/xmms_log.h"
-#include <modplug.h>
+#include <libmodplug/modplug.h>
 
 #include <glib.h>
 #include <string.h>
