--- build/src/shiori/kawari_shiori.cpp.orig
+++ build/src/shiori/kawari_shiori.cpp
@@ -75,6 +75,7 @@
 #include <cstdlib>
 #include <ctime>
 #include <cctype>
+#include <cstring>
 using namespace std;
 //---------------------------------------------------------------------------
 #include "shiori/kawari_shiori.h"
