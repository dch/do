--- build/src/libkawari/kawari_dict.cpp.orig
+++ build/src/libkawari/kawari_dict.cpp
@@ -32,6 +32,7 @@
 using namespace kawari_log;
 //---------------------------------------------------------------------------
 #include <iostream>
+#include <climits>
 using namespace std;
 //---------------------------------------------------------------------------
 // �ϰϳ��Υ���ǥå���
