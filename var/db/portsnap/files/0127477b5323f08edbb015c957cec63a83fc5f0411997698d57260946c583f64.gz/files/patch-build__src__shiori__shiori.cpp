--- build/src/shiori/shiori.cpp.orig
+++ build/src/shiori/shiori.cpp
@@ -24,6 +24,7 @@
 #include "include/shiori.h"
 //---------------------------------------------------------------------------
 #include <string>
+#include <cstring>
 using namespace std;
 //---------------------------------------------------------------------------
 namespace {
