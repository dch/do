--- src/include/refcount_ptr.h	2010-02-14 02:33:54.000000000 -0700
+++ src/include/refcount_ptr.h	2014-02-24 03:48:14.000000000 -0700
@@ -28,6 +28,8 @@
  *  SUCH DAMAGE.
  */
 
+#include <stddef.h>
+
 /**
  * \brief Base class for reference countable objects.
  *
