--- src/utility.h.orig	2006-02-14 07:57:01.000000000 +0300
+++ src/utility.h	2013-09-12 07:09:46.054424472 +0400
@@ -10,6 +10,7 @@
 #include <map>
 #include <string>
 #include <utility>
+#include <cstdlib>
 #include "audiere.h"
 #include "types.h"
 
