--- src/engine/log.h.orig	2012-01-04 13:48:11.224976420 +0100
+++ src/engine/log.h	2012-01-04 14:01:30.113974000 +0100
@@ -21,6 +21,7 @@
 
 #include "engine_defs.h"
 #include "game_defs.h"
+#include <string>
 
 struct sqlite3;
 
