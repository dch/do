--- image/rlelib.c.bak	2007-05-18 01:47:33.000000000 +0900
+++ image/rlelib.c	2008-11-06 23:38:04.000000000 +0900
@@ -13,7 +13,7 @@
 #include <stdio.h>
 #include <math.h>
 #if 0
-#include <varargs.h>
+#include <stdarg.h>
 #endif
 #include <ctype.h>
 
