--- ctlwords.c.orig	1999-02-15 00:02:25.000000000 +0100
+++ ctlwords.c	2013-11-08 09:05:06.000000000 +0100
@@ -24,6 +24,7 @@
 
 #include <stdio.h>
 #include <string.h>
+#include <stdlib.h>
 
 main(int argc, char *argv[])
 {
