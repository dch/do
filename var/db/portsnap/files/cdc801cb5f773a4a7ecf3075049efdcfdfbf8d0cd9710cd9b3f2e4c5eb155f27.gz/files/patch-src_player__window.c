--- src/player_window.c.orig	2014-05-10 14:48:57 UTC
+++ src/player_window.c
@@ -36,6 +36,7 @@
  * this file is used for the player control tab
  **********************************************************/
 
+#include <time.h>
 #include <sys/timeb.h>
 
 #include "player_window.h"
