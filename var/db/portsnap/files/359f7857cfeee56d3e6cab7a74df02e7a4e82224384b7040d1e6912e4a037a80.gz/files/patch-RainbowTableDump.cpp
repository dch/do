--- RainbowTableDump.cpp.orig	2014-07-31 12:22:38.000000000 -0400
+++ RainbowTableDump.cpp	2014-07-31 12:22:51.000000000 -0400
@@ -5,6 +5,7 @@
 */
 
 #include "ChainWalkContext.h"
+#include <stdlib.h>
 
 int main(int argc, char* argv[])
 {
