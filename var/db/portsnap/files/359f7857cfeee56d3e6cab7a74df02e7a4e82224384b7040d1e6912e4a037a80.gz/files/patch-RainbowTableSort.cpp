--- RainbowTableSort.cpp.orig	2014-07-31 12:23:47.000000000 -0400
+++ RainbowTableSort.cpp	2014-07-31 12:23:58.000000000 -0400
@@ -5,6 +5,7 @@
 */
 
 #include "Public.h"
+#include <stdlib.h>
 
 #define ASSUMED_MIN_MEMORY 32 * 1024 * 1024
 
