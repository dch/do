--- RainbowTableGenerate.cpp.orig	2014-07-31 12:14:05.000000000 -0400
+++ RainbowTableGenerate.cpp	2014-07-31 12:14:24.000000000 -0400
@@ -14,6 +14,7 @@
 	#include <unistd.h>
 #endif
 #include <time.h>
+#include <stdlib.h>
 
 #include "ChainWalkContext.h"
 
