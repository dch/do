--- Public.h.orig	2014-07-31 12:15:30.000000000 -0400
+++ Public.h	2014-07-31 12:15:56.000000000 -0400
@@ -12,6 +12,8 @@
 #include <string>
 #include <vector>
 #include <list>
+#include <sys/types.h>
+
 using namespace std;
 
 #ifdef _WIN32
