--- misc.c.orig	Thu Mar 16 19:54:45 2000
+++ src/misc.c	Wed Apr 18 12:45:21 2001
@@ -8,6 +8,7 @@
 #include <stdlib.h>
 #include <stdio.h>
 #include <time.h>
+#include <sys/types.h>
 #include <sys/stat.h>
 
 #include "wmpinboard.h"
