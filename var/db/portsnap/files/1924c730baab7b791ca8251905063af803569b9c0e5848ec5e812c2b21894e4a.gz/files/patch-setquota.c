--- setquota.c.orig	Sun Oct 20 14:27:31 2002
+++ setquota.c	Sun Oct 20 14:27:41 2002
@@ -62,7 +62,7 @@
 			qm->dq_dqb.dqb_bhardlimit = v_bh;
 		if (f_bs)
 			qm->dq_dqb.dqb_bsoftlimit = v_bs;
-#ifdef 0
+#if 0
 		if (f_bg)
 			qm->dq_dqb.dqb_btime = v_bg;
 #endif
@@ -70,7 +70,7 @@
 			qm->dq_dqb.dqb_ihardlimit = v_ih;
 		if (f_is)
 			qm->dq_dqb.dqb_isoftlimit = v_is;
-#ifdef 0
+#if 0
 		if (f_ig)
 			qm->dq_dqb.dqb_itime = v_ig;
 #endif
