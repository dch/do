--- printquota.c.orig	Sun Oct 20 14:27:13 2002
+++ printquota.c	Sun Oct 20 14:27:21 2002
@@ -109,7 +109,7 @@
 
 	if (now == 0)
 		time(&now);
-#ifdef 0
+#if 0
 	if (now > seconds)
 		return("none");
 	seconds -= now;
