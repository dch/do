--- BlockOut/GLApp/GLSprite.cpp.orig	2009-08-06 15:17:24.000000000 +0700
+++ BlockOut/GLApp/GLSprite.cpp	2009-08-06 15:17:46.000000000 +0700
@@ -3,7 +3,7 @@
 // -----------------------------------------------
 #include "GLSprite.h"
 #include <CImage.h>
-#include <malloc.h>
+#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
