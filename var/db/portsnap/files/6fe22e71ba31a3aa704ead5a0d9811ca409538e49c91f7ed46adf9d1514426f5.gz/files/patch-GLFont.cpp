--- BlockOut/GLApp/GLFont.cpp.orig	2009-08-06 15:16:50.000000000 +0700
+++ BlockOut/GLApp/GLFont.cpp	2009-08-06 15:16:58.000000000 +0700
@@ -3,7 +3,7 @@
 // -----------------------------------------------
 #include "GLFont.h"
 #include <CImage.h>
-#include <malloc.h>
+#include <stdlib.h>
 #include <stdio.h>
 #include <string.h>
 
