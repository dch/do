--- ImageLib/src/png/hpng.c.orig	2009-08-06 15:35:01.000000000 +0700
+++ ImageLib/src/png/hpng.c	2009-08-06 15:35:10.000000000 +0700
@@ -1,4 +1,4 @@
-#include <malloc.h>
+#include <stdlib.h>
 #include <math.h>
 #include "png/png.h"
 #include "hpng.h"
