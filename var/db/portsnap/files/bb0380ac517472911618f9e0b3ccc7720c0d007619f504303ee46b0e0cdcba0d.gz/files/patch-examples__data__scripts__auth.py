--- examples/data/scripts/auth.py.orig	2010-04-09 13:34:30.000000000 +0200
+++ examples/data/scripts/auth.py	2010-04-09 13:35:05.000000000 +0200
@@ -1,4 +1,5 @@
-#!/usr/bin/python
+#!/usr/bin/env python
+
 
 import gtk
 import sys
