--- ./src/types.h.orig	2010-04-12 13:54:32.000000000 +0400
+++ ./src/types.h	2010-09-25 23:50:53.953634766 +0400
@@ -78,6 +78,4 @@
 const gchar *custom_signal_0;
 const gchar *custom_signal_1;
 
-extern int PAGE_SIZE;
-
 #endif
