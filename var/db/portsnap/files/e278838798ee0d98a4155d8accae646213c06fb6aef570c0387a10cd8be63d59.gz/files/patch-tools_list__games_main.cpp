--- tools/list_games/main.cpp.orig	2011-04-28 19:03:12.000000000 +0000
+++ tools/list_games/main.cpp
@@ -1,4 +1,5 @@
 #include <stdio.h>
+#include <unistd.h>
 #include <WARMUX_types.h>
 #include <WARMUX_network.h>
 #include <WARMUX_index_server.h>
