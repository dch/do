--- src/control/defaults.h.orig
+++ src/control/defaults.h
@@ -3,6 +3,7 @@
 #ifndef DEFAULTS_H
 #define DEFAULTS_H
 
+#include <ctime>
 #include <string>
 #include "constants.h"
 #include "local_build.h"
