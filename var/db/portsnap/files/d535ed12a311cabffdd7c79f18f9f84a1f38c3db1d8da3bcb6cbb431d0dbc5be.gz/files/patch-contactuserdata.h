--- src/contactlist/contactuserdata.h.orig	2013-08-25 11:45:17.000000000 +0200
+++ src/contactlist/contactuserdata.h	2014-02-13 21:44:51.000000000 +0100
@@ -20,6 +20,8 @@
 #ifndef CONTACTUSERDATA_H
 #define CONTACTUSERDATA_H
 
+#include <time.h>
+
 #include <QList>
 #include <QString>
 #include <QTimer>
