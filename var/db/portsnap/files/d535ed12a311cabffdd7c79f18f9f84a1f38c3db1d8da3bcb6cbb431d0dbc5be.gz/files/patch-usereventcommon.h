--- src/userevents/usereventcommon.h.orig	2013-08-25 11:45:17.000000000 +0200
+++ src/userevents/usereventcommon.h	2014-02-13 21:45:16.000000000 +0100
@@ -20,6 +20,8 @@
 #ifndef USEREVENTCOMMON_H
 #define USEREVENTCOMMON_H
 
+#include <time.h>
+
 #include <QWidget>
 
 #include <list>
