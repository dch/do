--- ../generic/dom.h	2007-08-08 11:52:38.000000000 -0400
+++ ../generic/dom.h	2008-02-14 14:27:46.000000000 -0500
@@ -41,5 +41,4 @@
 #include <expat.h>
 #include <utf8conv.h>
-#include <domalloc.h>
 
 /*
