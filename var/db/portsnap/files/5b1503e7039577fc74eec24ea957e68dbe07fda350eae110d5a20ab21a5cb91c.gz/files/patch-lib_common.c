--- lib/common.c.orig	2011-03-12 21:28:20.000000000 +0100
+++ lib/common.c	2011-03-12 21:28:30.000000000 +0100
@@ -1,5 +1,6 @@
 #include <stdio.h>
 #include <stdlib.h>
+#include <string.h>
 #include <jpeglib.h>
 #include <setjmp.h>
 #include "common.h"
