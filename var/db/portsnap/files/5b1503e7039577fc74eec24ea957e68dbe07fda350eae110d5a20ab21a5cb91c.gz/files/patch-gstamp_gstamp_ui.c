--- gstamp/gstamp_ui.c.orig	2011-03-12 21:31:56.000000000 +0100
+++ gstamp/gstamp_ui.c	2011-03-12 21:32:20.000000000 +0100
@@ -1,3 +1,4 @@
+#include <string.h>
 #include <gtk/gtk.h>
 #include "gstamp.h"
 
