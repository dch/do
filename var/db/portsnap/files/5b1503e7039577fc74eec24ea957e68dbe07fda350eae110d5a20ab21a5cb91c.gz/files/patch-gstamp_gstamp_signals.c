--- gstamp/gstamp_signals.c.orig	2011-03-12 21:31:32.000000000 +0100
+++ gstamp/gstamp_signals.c	2011-03-12 21:31:44.000000000 +0100
@@ -3,6 +3,7 @@
    ebw@city-net.com
 */
 #include <gtk/gtk.h>
+#include <stdlib.h>
 #include <string.h>
 #include "gstamp.h"
 #include "../lib/rcfile.h"
