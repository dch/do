--- gstamp/gstamp.c.orig	2011-03-12 21:29:21.000000000 +0100
+++ gstamp/gstamp.c	2011-03-12 21:29:42.000000000 +0100
@@ -7,6 +7,7 @@
 
 #include <gtk/gtk.h>
 #include <stdio.h>
+#include <stdlib.h>
 #include <string.h>
 #include <getopt.h>
 #include "gstamp.h"
