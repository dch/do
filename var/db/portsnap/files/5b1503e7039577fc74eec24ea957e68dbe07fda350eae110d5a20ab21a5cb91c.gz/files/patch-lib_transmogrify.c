--- lib/transmogrify.c.orig	2011-03-12 21:28:42.000000000 +0100
+++ lib/transmogrify.c	2011-03-12 21:28:55.000000000 +0100
@@ -1,5 +1,6 @@
 #include <stdio.h>
 #include <stdlib.h>
+#include <string.h>
 #include <jpeglib.h>
 #include "../lib/common.h"
 
