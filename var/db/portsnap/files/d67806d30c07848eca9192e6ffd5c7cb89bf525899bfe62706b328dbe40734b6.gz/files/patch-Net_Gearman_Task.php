--- Net/Gearman/Task.php.orig	1970-01-01 09:13:08 UTC
+++ Net/Gearman/Task.php
@@ -144,7 +144,7 @@ class Net_Gearman_Task
      *
      * @var integer JOB_HIGH
      */
-    const JOB_HIGH = 2;
+    const JOB_HIGH = 3;
 
     /**
      * Callback of type complete
