--- topaz/topaz.cc.orig	Wed Dec  4 23:02:28 2002
+++ topaz/topaz.cc	Fri Dec 27 04:29:01 2002
@@ -30,7 +30,7 @@
 #include <dirent.h>
 #include <sys/stat.h>
 #include <signal.h>
-#include <getopt.h>
+//#include <getopt.h>
 //char *optarg;
 #include "script.h"
 #include "frame.h"
