--- calendar.h.orig	2009-01-26 18:35:48.000000000 +0100
+++ calendar.h	2009-01-26 18:36:03.000000000 +0100
@@ -1,4 +1,4 @@
-#include <ical.h>
+#include <libical/ical.h>
 #include <stdlib.h>
 #include <gtk/gtk.h>
 #include <string.h>
