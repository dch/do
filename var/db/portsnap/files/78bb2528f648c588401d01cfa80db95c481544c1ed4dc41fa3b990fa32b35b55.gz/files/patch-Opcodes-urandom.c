--- Opcodes/urandom.c.orig	2015-04-25 19:06:23 UTC
+++ Opcodes/urandom.c
@@ -22,7 +22,6 @@
 */
 
 #include "csdl.h"
-#include <ieee754.h>
 
 typedef struct {
     OPDS    h;
