--- Xvnc/include/Xos.h.orig	Thu Apr 13 02:18:22 2000
+++ Xvnc/include/Xos.h	Wed Nov 20 20:42:00 2002
@@ -151,7 +151,6 @@
 #endif /* X_NOT_POSIX else */
 
 #ifdef CSRG_BASED
-#include <stdlib.h>
 #include <unistd.h>
 #endif /* CSRG_BASED */
 
