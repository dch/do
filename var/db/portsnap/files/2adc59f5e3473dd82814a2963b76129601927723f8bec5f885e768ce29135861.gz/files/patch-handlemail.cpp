--- handlemail.cpp.orig	Tue Jan 24 06:32:46 2006
+++ handlemail.cpp	Sun Jul  9 23:38:50 2006
@@ -9,6 +9,7 @@
 #include <dirent.h>
 #include <errno.h>
 #include <string.h>
+#include <limits.h>
 }
 
 #include "headers.h"
