--- main.cpp.orig	Tue Jan 24 03:04:56 2006
+++ main.cpp	Sun Jul  9 23:38:13 2006
@@ -1,6 +1,7 @@
 
 /* This is the main body of my C++ mailer */
 
+#include <limits.h>
 #include <time.h>
 
 /* Include all of the standard headers that we need */
