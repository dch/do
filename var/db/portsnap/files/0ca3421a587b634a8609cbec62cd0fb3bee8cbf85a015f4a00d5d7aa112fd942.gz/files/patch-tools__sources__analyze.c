--- tools/sources/analyze.c.orig	2008-04-21 16:56:06.000000000 +0900
+++ tools/sources/analyze.c	2012-10-24 04:58:13.000000000 +0900
@@ -21,6 +21,7 @@
 #include <stdio.h>
 #include <stdlib.h>
 #include <string.h>
+#include <unistd.h>
 
 /*****************************************************************************/
 /* constants                                                                 */
