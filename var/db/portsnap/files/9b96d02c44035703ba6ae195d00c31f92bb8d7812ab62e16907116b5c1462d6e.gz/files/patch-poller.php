--- poller.php.orig	2015-05-27 15:48:33 UTC
+++ poller.php
@@ -1,4 +1,4 @@
-#!/usr/bin/env php
+#!%%LOCALBASE%%/bin/php
 <?php
 
 /**
