--- src/kbddef.h.orig	Mon Mar 19 01:51:24 2001
+++ src/kbddef.h	Sun May 11 16:01:17 2003
@@ -55,6 +55,9 @@
     myComputerKey,
     favoritesKey,
     calculatorKey,
+    messengerKey,
+    webcamKey,
+    mediaKey,
     newsReaderKey,
     iNewsKey,
     rewindKey,
