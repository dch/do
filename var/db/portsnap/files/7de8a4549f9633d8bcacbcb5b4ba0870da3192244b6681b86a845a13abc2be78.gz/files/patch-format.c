--- src/common/format.c.orig	2014-04-24 11:16:10.068089322 -0700
+++ src/common/format.c	2014-04-24 11:17:12.226546612 -0700
@@ -249,6 +249,7 @@
 					break;

 				default:
+					break;
 			}

 			fmt++;
