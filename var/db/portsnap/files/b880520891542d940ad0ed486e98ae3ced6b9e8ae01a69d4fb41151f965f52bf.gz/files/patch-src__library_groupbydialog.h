--- ./src/library/groupbydialog.h.orig	2014-05-25 10:38:37.378768447 -0700
+++ ./src/library/groupbydialog.h	2014-05-25 10:39:12.641759778 -0700
@@ -22,6 +22,8 @@
 
 #include <memory>
 
+#include <functional>
+
 using std::placeholders::_1;
 using std::placeholders::_2;
 
