--- xcalendar.h.orig	Sun Oct  1 12:21:42 1995
+++ xcalendar.h	Mon Mar 12 20:54:02 2001
@@ -75,7 +75,7 @@
 #include <X11/Xaw/Xawi18n.h>
 #endif
 
-#if defined(SYSV) || defined(__osf__) || defined(SVR4)
+#if defined(SYSV) || defined(__osf__) || defined(SVR4) || defined(HAVE_DIRENT_H)
 #include <dirent.h>
 #else
 #include <sys/dir.h>
