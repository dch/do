--- conffile.hh.orig	Wed May 22 11:03:47 2002
+++ conffile.hh	Wed May 22 11:04:20 2002
@@ -55,7 +55,7 @@
 
 
 #ifndef DEFAULT_SQUID_CONF
-#define DEFAULT_SQUID_CONF "/usr/local/squid/etc/squid.conf"
+#define DEFAULT_SQUID_CONF "/usr/local/etc/squid/squid.conf"
 #endif // DEFAULT_SQUID_CONF
 
 #include <stdio.h>      // FILE*
