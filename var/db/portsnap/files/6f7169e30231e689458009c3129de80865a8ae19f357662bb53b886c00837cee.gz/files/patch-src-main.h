--- src/main.h.orig	Sat Jun  7 20:04:37 2003
+++ src/main.h	Thu Nov  1 02:12:04 2007
@@ -459,7 +459,6 @@
 #endif
 extern struct HiScore		highscore[];
 extern struct TapeInfo		tape;
-extern struct JoystickInfo	joystick[];
 extern struct SetupInfo		setup;
 extern struct GameInfo		game;
 extern struct LaserInfo		laser;
