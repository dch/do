--- ./docs/source/conf.py.orig	2012-09-11 15:54:40.000000000 +0200
+++ ./docs/source/conf.py	2012-09-11 15:54:44.000000000 +0200
@@ -104,7 +104,7 @@
 
 # The theme to use for HTML and HTML Help pages.  See the documentation for
 # a list of builtin themes.
-html_theme = 'flask'
+html_theme = 'default'
 
 # Theme options are theme-specific and customize the look and feel of a theme
 # further.  For a list of options available for each theme, see the
