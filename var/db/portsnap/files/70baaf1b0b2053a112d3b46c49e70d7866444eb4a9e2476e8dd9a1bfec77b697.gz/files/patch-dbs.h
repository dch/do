--- dbs.h.orig	Sun Jul 20 19:16:32 2003
+++ dbs.h	Sun Jul 20 19:16:48 2003
@@ -1,3 +1,4 @@
+#include <unistd.h>
 #include <regex.h>
 
 extern regex_t *a_ip[];
