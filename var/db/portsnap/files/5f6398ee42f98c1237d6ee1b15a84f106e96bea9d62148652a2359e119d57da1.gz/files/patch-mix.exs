--- mix.exs.orig	2015-07-03 14:09:24 UTC
+++ mix.exs
@@ -34,7 +34,6 @@ defmodule ExActor.Mixfile do
 
   defp deps do
     [
-      {:ex_doc, "~> 0.7.0", only: :docs}
     ]
   end
 end
