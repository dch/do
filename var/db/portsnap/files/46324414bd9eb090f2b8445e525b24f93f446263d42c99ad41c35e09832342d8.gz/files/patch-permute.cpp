--- permute.cpp.orig	Fri Jul 14 14:51:01 2000
+++ permute.cpp	Thu Sep  8 07:07:31 2005
@@ -18,8 +18,10 @@
  *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
  */
 #include <assert.h>
-#include <iostream.h>
-#include <string.h>
+#include <iostream>
+#include <string>
+
+using namespace std;
 
 //=============================================================================
 //
