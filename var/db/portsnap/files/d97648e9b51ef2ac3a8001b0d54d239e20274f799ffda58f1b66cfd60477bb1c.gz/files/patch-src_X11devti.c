--- 1.1	1995/02/18 17:50:34
+++ src/X11devti.c	1995/02/18 17:50:48
@@ -111,7 +111,7 @@
 
 #ifdef X11 
 
-#include <X11/Xos.h>
+/*#include <X11/Xos.h>*/
 #include <X11/Xlib.h>
 #include <X11/Xutil.h>
 #include <X11/cursorfont.h>
