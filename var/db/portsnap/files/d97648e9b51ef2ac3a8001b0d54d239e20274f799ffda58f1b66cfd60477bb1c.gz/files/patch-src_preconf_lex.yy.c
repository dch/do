--- 1.1	1995/02/18 17:09:45
+++ src/preconf/lex.yy.c	1995/02/18 17:21:39
@@ -1665,7 +1665,7 @@
 
 #ifndef YY_MALLOC_DECL
 #define YY_MALLOC_DECL
-#include <malloc.h>
+#include <stdlib.h>
 #endif
  
 #undef YYVALGLOBAL
@@ -5256,7 +5256,7 @@
 
 #include <stdio.h>
 #include <string.h>
-#include <malloc.h>
+#include <stdlib.h>
 
 /* Global Variables */
 /*------------------*/
