--- 1.1	1995/02/18 17:49:27
+++ src/X11devfs.c	1995/02/18 18:03:42
@@ -107,7 +107,7 @@
 
 #ifdef X11 
 
-#include <X11/Xos.h>
+/*#include <X11/Xos.h>*/
 #include <X11/Xlib.h>
 #include <X11/Xutil.h>
 #include <X11/cursorfont.h>
@@ -128,7 +128,7 @@
 #else
 #include <sys/types.h> 
 #include <sys/stat.h> 
-#include <sys/param.h> 
+/*#include <sys/param.h> */
 #include <dirent.h> 
 #include <grp.h> 
 #include <pwd.h> 
