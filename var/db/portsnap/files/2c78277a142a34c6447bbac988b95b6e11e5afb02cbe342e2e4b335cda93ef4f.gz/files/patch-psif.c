--- psif.c.orig	2013-04-27 22:58:26.000000000 +0900
+++ psif.c	2013-04-27 22:58:42.000000000 +0900
@@ -5,6 +5,7 @@
 #endif
 
 #include <stdio.h>
+#include <stdlib.h>
 #include <sys/types.h>
 #include <sys/stat.h>
 
