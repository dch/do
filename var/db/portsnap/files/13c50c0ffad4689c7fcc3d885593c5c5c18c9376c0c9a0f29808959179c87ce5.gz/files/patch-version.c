*** version.c.orig	Wed Apr 23 12:38:55 1997
--- version.c	Wed Apr 23 12:39:29 1997
***************
*** 214,220 ****
  "Jupiter's moons based on information in \"Astronomical Formulae for",
  "Calculators\" by Jean Meeus.  Richmond, Va., U.S.A., Willmann-Bell, (c) 1982.",
  */
! "See the manual (Man.txt) for a list of references.",
  "",
  "type any key to continue..."
  };
--- 214,220 ----
  "Jupiter's moons based on information in \"Astronomical Formulae for",
  "Calculators\" by Jean Meeus.  Richmond, Va., U.S.A., Willmann-Bell, (c) 1982.",
  */
! "See the manual (" PREFIX "/share/ephem/Man.txt) for a list of references.",
  "",
  "type any key to continue..."
  };
