*** formats.c.orig	Tue Apr 15 01:07:37 1997
--- formats.c	Tue Apr 15 01:33:15 1997
***************
*** 5,11 ****
  #include <stdio.h>
  #include <math.h>
  #include <ctype.h>
! #ifdef VMS
  #include <stdlib.h>
  #endif
  #include "astro.h"
--- 5,11 ----
  #include <stdio.h>
  #include <math.h>
  #include <ctype.h>
! #if defined(VMS) || defined(unix)
  #include <stdlib.h>
  #endif
  #include "astro.h"
