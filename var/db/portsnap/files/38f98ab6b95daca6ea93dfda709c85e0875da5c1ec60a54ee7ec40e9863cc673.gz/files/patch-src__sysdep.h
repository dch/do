--- src/sysdep.h.orig	Sun Apr 13 14:43:59 2003
+++ src/sysdep.h	Sun Apr 13 13:54:17 2003
@@ -38,6 +38,7 @@
     !defined(IRIX) && \
     !defined(SCO) && \
     !defined(SUNOS) && \
+    !defined(FREEBSD) && \
     !defined(NCR)
 #    error Target not supported.
 #endif
