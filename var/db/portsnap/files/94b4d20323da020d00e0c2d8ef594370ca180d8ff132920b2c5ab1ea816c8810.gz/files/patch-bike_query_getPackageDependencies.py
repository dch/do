--- bike/query/getPackageDependencies.py.orig	Wed Jul 20 01:00:38 2005
+++ bike/query/getPackageDependencies.py	Wed Jul 20 01:00:51 2005
@@ -2,5 +2,4 @@
 
 # fileInPackage is the filename of a file in the package hierarchy
 def getPackageDependencies(fileInPackage):
-    
-
+	pass
