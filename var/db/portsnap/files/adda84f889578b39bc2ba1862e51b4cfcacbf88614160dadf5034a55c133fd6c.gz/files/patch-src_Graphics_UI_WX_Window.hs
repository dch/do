--- src/Graphics/UI/WX/Window.hs.orig	2014-08-11 14:58:24 UTC
+++ src/Graphics/UI/WX/Window.hs
@@ -1,4 +1,4 @@
-{-# LANGUAGE TypeSynonymInstances, FlexibleInstances #-}
+{-# LANGUAGE TypeSynonymInstances, FlexibleInstances, FlexibleContexts #-}
 --------------------------------------------------------------------------------
 {-|	Module      :  Window
 	Copyright   :  (c) Daan Leijen 2003
