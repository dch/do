--- include/RangeMap.h.orig	Sun Aug  1 19:34:55 2004
+++ include/RangeMap.h	Sun Aug  1 19:26:43 2004
@@ -9,6 +9,7 @@
 #include "ISet.h"
 #include "types.h"
 #include <stddef.h>
+#include "constant.h"
 
 #ifdef SP_NAMESPACE
 namespace SP_NAMESPACE {
