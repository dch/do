--- trinokiller.c.orig	Sun Feb 13 19:41:24 2000
+++ trinokiller.c	Sun Feb 13 19:41:48 2000
@@ -12,6 +12,7 @@
  *
  */
 
+#include <sys/types.h>
 #include <stdlib.h>
 #include <stdio.h>
 #include <sys/socket.h>
