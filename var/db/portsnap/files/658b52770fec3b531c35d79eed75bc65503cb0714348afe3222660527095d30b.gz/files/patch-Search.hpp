--- ./Search.hpp.orig	2008-08-23 04:00:12.000000000 -0700
+++ ./Search.hpp	2011-12-30 17:37:16.000000000 -0800
@@ -65,6 +65,7 @@
 #include <queue>
 #include <cstdlib>
 #include <cstdio>
+#include <cstring>
 #include <climits>
 #include <ctime>
 #include <cctype>
